# -*- coding: utf-8 -*-
"""Thèmes de couleurs de l'interface."""

#  THEMES
# ══════════════════════════════════════════════════════════════════════

THEMES = {
    'dark': dict(
        bg='#12121f', bg2='#1a1a2e', bg3='#232340', bg4='#2d2d4f',
        fg='#cdd6f4', fg2='#6c7086', fg3='#45475a',
        accent='#cba6f7', accent2='#b4befe',
        green='#a6e3a1', yellow='#f9e2af', red='#f38ba8',
        blue='#89b4fa', teal='#94e2d5', orange='#fab387',
        editor_bg='#0d0d1a', editor_fg='#cdd6f4',
        sel_bg='#313244', cur_line='#1e1e32',
        line_num='#45475a', border='#313244',
        kw='#cba6f7', string='#a6e3a1', number='#fab387',
        comment='#585b70', func='#89dceb', type_='#f38ba8',
        bool_='#eba0ac', op='#89b4fa',
        status_bg='#1e1e2e', tab_bg='#181825', tab_sel='#313244',
    ),
    'light': dict(
        bg='#eff1f5', bg2='#ffffff', bg3='#e6e9ef', bg4='#dce0e8',
        fg='#4c4f69', fg2='#9ca0b0', fg3='#bcc0cc',
        accent='#7c3aed', accent2='#8839ef',
        green='#40a02b', yellow='#df8e1d', red='#d20f39',
        blue='#1e66f5', teal='#179299', orange='#fe640b',
        editor_bg='#ffffff', editor_fg='#4c4f69',
        sel_bg='#dce0e8', cur_line='#eff1f5',
        line_num='#acafbe', border='#ccd0da',
        kw='#8839ef', string='#40a02b', number='#fe640b',
        comment='#9ca0b0', func='#1e66f5', type_='#d20f39',
        bool_='#e64553', op='#209fb5',
        status_bg='#e6e9ef', tab_bg='#eff1f5', tab_sel='#ccd0da',
    ),
}

# ══════════════════════════════════════════════════════════════════════
#  EXAMPLES
# ══════════════════════════════════════════════════════════════════════

