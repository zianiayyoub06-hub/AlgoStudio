# -*- coding: utf-8 -*-
"""Interpréteur — Exécution de l'AST."""

import math, random, time
from ast_nodes import *

# ══════════════════════════════════════════════════════════════════════
#  ENVIRONMENT
# ══════════════════════════════════════════════════════════════════════

class Env:
    def __init__(self, parent=None, name='global'):
        self._vars = {}; self.parent = parent; self.name = name

    def get(self, key, line=None):
        k = key.lower()
        if k in self._vars: return self._vars[k]
        if self.parent: return self.parent.get(k, line)
        raise AlgoRTError(f"Variable non définie: '{key}'", line)

    def set(self, key, val):
        k = key.lower()
        if k in self._vars: self._vars[k]=val; return
        if self.parent and self.parent._has(k): self.parent.set(k,val); return
        self._vars[k] = val

    def declare(self, key, val=None):
        self._vars[key.lower()] = val

    def _has(self, key):
        k=key.lower()
        if k in self._vars: return True
        if self.parent: return self.parent._has(k)
        return False

    def snapshot(self):
        """Return flat dict of all visible vars for debugger."""
        flat = {}
        if self.parent: flat.update(self.parent.snapshot())
        flat.update(self._vars)
        return flat

class AlgoRTError(Exception):
    def __init__(self, msg, line=None): super().__init__(msg); self.line=line

class ReturnSig(Exception):
    def __init__(self, val): self.val=val

class BreakSig(Exception): pass
class ContinueSig(Exception): pass
class StopSig(Exception): pass

# ══════════════════════════════════════════════════════════════════════
#  INTERPRETER
# ══════════════════════════════════════════════════════════════════════

BUILTIN_FUNCS = {
    'abs','valabs','sqrt','racine','floor','plafond','ceil','entier_inf',
    'entier_sup','entier','reel','chaine','long','longueur','taille',
    'max','min','modulo','mod','random','aleatoire','aleatoire_entier',
    'estvide','est_vide','ord','chr','majuscule','minuscule','arrondi',
    'puissance','pow','log','log2','log10','sin','cos','tan','pi','e',
    'concat','sous_chaine','trouve','remplace','split','trim',
    'finfichier','fin_fichier','eof','fin','pointer',
    'chaine_vers_tableau','str_to_tab','tableau_vers_chaine','tab_to_str',
    'allouer_tableau',
}

class Interpreter:
    MAX_STEPS       = 200_000
    MAX_ARRAY_INDEX = 9_999   # حماية ضد التوسع اللانهائي للمصفوفات

    def __init__(self, output_cb, input_cb, step_cb=None, stopped_cb=None):
        self.output_cb   = output_cb
        self.input_cb    = input_cb
        self.step_cb     = step_cb      # called with (line, env) for debug
        self.stopped_cb  = stopped_cb
        self.funcs       = {}
        self.type_defs   = {}           # name -> [(field, type)] for records
        self.steps       = 0
        self._stop       = False
        self.current_env = None

    def stop(self): self._stop = True

    def run(self, prog):
        self.steps = 0; self._stop = False
        self._start_time = time.time()
        self.type_defs = getattr(prog, 'types', {})
        env = Env(name='global')
        # Charger les constantes dans l'environnement
        for cname, cexpr in getattr(prog, 'consts', {}).items():
            try:
                cval = self._eval(cexpr, env)
            except Exception:
                cval = None
            env.declare(cname, cval)
        for f in prog.funcs:
            self.funcs[f.name.lower()] = f
        self._declare_vars(prog.vars, env)
        self.current_env = env
        self._exec_stmts(prog.body, env)

    def _declare_vars(self, decls, env):
        for d in decls:
            for name in d.names:
                env.declare(name, self._default(d.type))

    def _default(self, t):
        if t == 'entier':   return 0
        if t == 'reel':     return 0.0
        if t == 'booleen':  return False
        if t in ('chaine','caractere'): return ''
        if isinstance(t, tuple):
            if t[0] == 'tableau':
                sizes = t[1]; base = t[2]
                # Tableau De Caractere → traité comme une chaine (str)
                if base == 'caractere':
                    return []   # liste de caractères (mutable)
                return self._make_array(sizes, base)
            if t[0] == 'pointeur': return None
        # User-defined record type
        if isinstance(t, str) and t.lower() in self.type_defs:
            fields = self.type_defs[t.lower()]
            return {fname.lower(): self._default(ftype) for fname, ftype in fields}
        return None

    def _make_array(self, sizes, base):
        # sizes = list of AST Literal/expr nodes
        # For nested (2D): base itself is ('tableau', [...], inner_base)
        # Retourne [] — croissance dynamique à l'accès
        # Pour les tableaux de caractères ou d'enregistrements, on retourne une liste vide
        return []

    def _tick(self, line=None):
        self.steps += 1
        if self._stop: raise StopSig()
        if self.steps > self.MAX_STEPS:
            raise AlgoRTError(
                f"Boucle infinie détectée !\n"
                f"L\'exécution a dépassé {self.MAX_STEPS:,} instructions.\n"
                f"Vérifiez vos conditions de sortie de boucle.",
                line)
        # Vérification temporelle : max 10 secondes
        if self.steps % 5000 == 0:
            elapsed = time.time() - self._start_time
            if elapsed > 10.0:
                raise AlgoRTError(
                    f"Timeout : exécution > 10 secondes (boucle infinie ?).\n"
                    f"Ligne approximative : {line}", line)
        if self.step_cb and line:
            self.step_cb(line, self.current_env)

    def _exec_stmts(self, stmts, env):
        old = self.current_env; self.current_env = env
        try:
            for s in stmts: self._exec(s, env)
        finally:
            self.current_env = old

    def _exec(self, node, env):
        if node is None: return
        t = type(node)
        line = getattr(node,'line',None)
        self._tick(line)

        if t == Assign:
            val = self._eval(node.value, env)
            self._lval_set(node.target, val, env)

        elif t == Ecrire:
            parts = [self._to_str(self._eval(a,env)) for a in node.args]
            # Ecrire(f, val) → écriture dans fichier si 1er arg est un handle
            if node.args and isinstance(parts[0], str):
                fh_raw = self._eval(node.args[0], env)
                if isinstance(fh_raw, dict) and '_file' in fh_raw:
                    try:
                        fh_raw['_file'].write(' '.join(parts[1:]) + '\n')
                    except Exception as ex:
                        raise AlgoRTError(f"Ecrire fichier : {ex}", node.line)
                    return
            self.output_cb(' '.join(parts))

        elif t == Lire:
            targets = node.targets
            # Detecter forme fichier: Lire(f, var) — 1er arg est un handle
            if len(targets) >= 2:
                try:
                    fhandle = self._eval(targets[0], env)
                    if isinstance(fhandle, dict) and '_file' in fhandle:
                        ext = fhandle.get('_ext','dat')
                        for tgt in targets[1:]:
                            try:
                                raw = fhandle['_file'].readline()
                                if raw == '':
                                    fhandle['_eof'] = True
                                    self._lval_set(tgt, '', env)
                                else:
                                    val = raw.rstrip('\n')
                                    if ext=='csv' and ',' in val:
                                        val = val.split(',')[0]
                                    self._lval_set(tgt, self._coerce(val), env)
                            except Exception as ex:
                                raise AlgoRTError(f'Lire fichier: {ex}', node.line)
                        return
                except (Exception,):
                    pass  # pas un handle -> lire depuis stdin
            # Lire depuis stdin (clavier)
            for tgt in targets:
                raw = self.input_cb()
                self._lval_set(tgt, self._coerce(raw), env)

        elif t == If:
            c = self._eval(node.cond, env)
            child = Env(env)
            if c: self._exec_stmts(node.then, child)
            elif node.else_: self._exec_stmts(node.else_, child)

        elif t == While:
            child = Env(env)
            while self._eval(node.cond, env):
                self._tick(node.line)
                try:
                    self._exec_stmts(node.body, child)
                except BreakSig:
                    break
                except ContinueSig:
                    continue

        elif t == For:
            start = int(self._eval(node.start, env))
            end_  = int(self._eval(node.end,   env))
            step  = int(self._eval(node.step,  env)) if node.step else 1
            if step == 0:
                raise AlgoRTError("Le pas de la boucle Pour ne peut pas être zéro", node.line)
            vname = node.var.lower()
            child = Env(env); child.declare(vname, start)
            v = start
            cmp = (lambda a,b: a<=b) if step>0 else (lambda a,b: a>=b)
            while cmp(v, end_):
                self._tick(node.line)
                child.set(vname, v)
                try:
                    self._exec_stmts(node.body, child)
                except BreakSig:
                    break
                except ContinueSig:
                    v += step; continue
                v += step

        elif t == Repeat:
            child = Env(env)
            while True:
                self._tick(node.line)
                try:
                    self._exec_stmts(node.body, child)
                except BreakSig:
                    break
                except ContinueSig:
                    pass
                if self._eval(node.cond, env): break

        elif t == Switch:
            val   = self._eval(node.expr, env)
            child = Env(env)
            matched = False
            for case_val, case_stmts in node.cases:
                if isinstance(case_val, RangeVal):
                    low = self._eval(case_val.low, env)
                    high= self._eval(case_val.high, env)
                    hit = (low <= val <= high) if isinstance(val, (int,float)) else False
                else:
                    cv  = self._eval(case_val, env)
                    hit = (val == cv)
                if hit:
                    self._exec_stmts(case_stmts, child)
                    matched = True
                    break
            if not matched and node.default:
                self._exec_stmts(node.default, child)

        elif t == Break:
            raise BreakSig()

        elif t == Continue:
            raise ContinueSig()

        elif t == Return:
            raise ReturnSig(self._eval(node.value, env))

        elif t == FuncCall:
            nl = node.name.lower()
            # ── Nouveau(p) : alloue un enregistrement → dict ──────────
            if nl == 'nouveau':
                if node.args:
                    tgt = node.args[0]
                    # Detecter si c'est un pointeur vers enregistrement
                    tgt_val = None
                    try:
                        tgt_val = self._eval(tgt, env)
                    except Exception:
                        pass
                    if isinstance(tgt, (Var, FieldAccess, ArrayAccess)):
                        # Si pointeur vers enregistrement connu -> dict
                        # Sinon -> cellule scalaire [None]
                        # Heuristique: si deja un dict ou type_defs contient le nom -> dict
                        ptr_type = None
                        if isinstance(tgt, Var):
                            # chercher le type declare
                            pass
                        # Par defaut: allouer un dict (enregistrement)
                        # Si le pointeur existant est deja une liste -> garder liste
                        if isinstance(tgt_val, list):
                            self._lval_set(tgt, [None], env)
                        else:
                            self._lval_set(tgt, {}, env)
                return
            # ── Allouer(p, n) ou t <- allouer(n*taille(T)) ───────────
            if nl == 'allouer':
                # forme statement : Allouer(p, n)  →  p reçoit une liste de n cases
                if len(node.args) >= 2:
                    tgt   = node.args[0]
                    n_raw = self._eval(node.args[1], env)
                    n_elems = max(1, int(n_raw))
                    self._lval_set(tgt, [None] * n_elems, env)
                return
            # ── Liberer(p) : met le pointeur à NIL ────────────────────
            if nl == 'liberer':
                if node.args:
                    tgt = node.args[0]
                    self._lval_set(tgt, None, env)
                return
            # ── Ouvrir(f, chemin, mode) : assigne le handle à f ───────
            if nl == 'ouvrir':
                if len(node.args) >= 1:
                    tgt    = node.args[0]
                    handle = self._call(node.name, node.args, env, node.line)
                    self._lval_set(tgt, handle, env)
                return
            # ── Fermer(f) : ferme et met f à NIL ─────────────────────
            if nl == 'fermer':
                if node.args:
                    tgt = node.args[0]
                    fh  = self._eval(tgt, env)
                    if isinstance(fh, dict) and '_file' in fh:
                        try: fh['_file'].close()
                        except: pass
                    self._lval_set(tgt, None, env)
                return
            self._call(node.name, node.args, env, node.line)

    def _lval_set(self, target, val, env):
        if isinstance(target, Var):
            k = target.name.lower()
            if not env._has(k): env.declare(k)
            env.set(k, val)
        elif isinstance(target, ArrayAccess):
            # Handle chained: M[i][j]
            # Find the innermost name and collect all indices
            node = target; indices = []
            while isinstance(node, ArrayAccess):
                indices.insert(0, int(self._eval(node.index, env)))
                node = node.name
            # node is now the base variable name (str)
            arr = env.get(node.lower(), target.line)
            if not isinstance(arr, list):
                raise AlgoRTError(f"'{node}' n'est pas un tableau", target.line)
            # Navigate to second-to-last dimension
            for idx in indices[:-1]:
                if idx > self.MAX_ARRAY_INDEX:
                    raise AlgoRTError(
                        f"Indice hors bornes : {idx} (max autorisé : {self.MAX_ARRAY_INDEX}).\n"
                        f"Vérifiez la taille de votre tableau.", target.line)
                while len(arr) <= idx: arr.append(None)
                if arr[idx] is None: arr[idx] = []
                if not isinstance(arr[idx], list):
                    raise AlgoRTError(f"'{node}' n'est pas un tableau 2D", target.line)
                arr = arr[idx]
            last = indices[-1]
            if last > self.MAX_ARRAY_INDEX:
                raise AlgoRTError(
                    f"Indice {last} dépasse la limite ({self.MAX_ARRAY_INDEX})", target.line)
            while len(arr) <= last: arr.append(None)
            arr[last] = val
        elif isinstance(target, Deref):
            # p^ := val — dereference assignment
            ptr = self._eval(target.expr, env)
            if isinstance(ptr, list):
                if len(ptr) == 0: ptr.append(None)
                ptr[0] = val
            elif isinstance(ptr, dict):
                # Pointeur sur enregistrement — stocker directement
                # On ne peut pas modifier le dict en place ici, besoin du Var
                inner = target.expr
                if isinstance(inner, Var):
                    if isinstance(val, dict):
                        ptr.clear(); ptr.update(val)
                    else:
                        # Wrap as cell
                        cell = [val]
                        env.set(inner.name.lower(), cell)
            else:
                # Pointer not yet allocated — auto-create a cell
                cell = [val]
                if isinstance(target.expr, Var):
                    env.set(target.expr.name.lower(), cell)
        elif isinstance(target, FieldAccess):
            obj = self._eval(target.obj, env)
            # Auto-init si None (tableau d'enregistrements)
            if obj is None and isinstance(target.obj, ArrayAccess):
                obj = {}
                self._lval_set(target.obj, obj, env)
            if not isinstance(obj, dict):
                raise AlgoRTError("Accès à un champ sur un non-enregistrement", target.line)
            obj[target.field.lower()] = val

    def _eval(self, node, env):
        self._tick()
        t = type(node)
        if t == Literal:     return node.value
        if t == Var:         return env.get(node.name.lower(), node.line)
        if t == ArrayAccess:
            # Collect all indices for chained access M[i][j]
            nd = node; indices = []
            while isinstance(nd, ArrayAccess):
                indices.insert(0, int(self._eval(nd.index, env)))
                nd = nd.name
            arr = env.get(nd.lower(), node.line)
            for k, idx in enumerate(indices):
                if not isinstance(arr, list):
                    raise AlgoRTError(f"'{nd}' n'est pas un tableau", node.line)
                if idx > self.MAX_ARRAY_INDEX:
                    raise AlgoRTError(
                        f"Indice hors bornes : {idx} (max autorisé : {self.MAX_ARRAY_INDEX}).\n"
                        f"Vérifiez la taille de votre tableau.", node.line)
                while len(arr) <= idx: arr.append(None)
                # Auto-init intermediate dimensions as lists
                if k < len(indices) - 1 and arr[idx] is None:
                    arr[idx] = []
                arr = arr[idx]
            return arr
        if t == Deref:
            # p^ ou p↑ — dereferencement
            ptr = self._eval(node.expr, env)
            if isinstance(ptr, list):
                return ptr[0] if ptr else None
            if isinstance(ptr, dict):
                return ptr  # pointeur sur enregistrement
            return ptr  # fallback
        if t == FieldAccess:
            obj = self._eval(node.obj, env)
            # Auto-init si None (tableau d'enregistrements non initialisé)
            if obj is None and isinstance(node.obj, ArrayAccess):
                obj = {}
                self._lval_set(node.obj, obj, env)
            if isinstance(obj, dict): return obj.get(node.field.lower())
            raise AlgoRTError("Accès à un champ invalide", node.line)
        if t == BinOp:
            l = self._eval(node.left, env)
            r = self._eval(node.right, env)
            op = node.op
            try:
                if op=='+':
                    if isinstance(l,str) or isinstance(r,str):
                        return self._to_str(l)+self._to_str(r)
                    return l+r
                if op=='-': return l-r
                if op=='*': return l*r
                if op == 'div':
                    if r==0: raise AlgoRTError('Division par zero')
                    return int(l)//int(r)
                if op in ('mod','%'):
                    if r==0: raise AlgoRTError('Modulo par zero')
                    return int(l)%int(r)
                if op == '/':
                    if r==0: raise AlgoRTError('Division par zero')
                    return l/r  # division reelle
                if op=='=':  return l==r
                if op=='<>': return l!=r
                if op=='<':  return l<r
                if op=='>':  return l>r
                if op=='<=': return l<=r
                if op=='>=': return l>=r
                if op=='et': return bool(l) and bool(r)
                if op=='ou': return bool(l) or bool(r)
            except TypeError as e:
                raise AlgoRTError(f"Opération invalide: {e}")
        if t == UnaryOp:
            v = self._eval(node.operand, env)
            if node.op=='-': return -v
            if node.op=='non': return not v
        if t == FuncCall:
            return self._call(node.name, node.args, env, node.line)
        return None

    def _call(self, name, arg_nodes, env, line):
        nl = name.lower()
        # Pour taille(): si l'arg est un nom de type (Pile, ElementFile, etc.)
        # l'eval echoue (variable non definie) -> utiliser le nom comme string
        if nl == 'taille' and arg_nodes:
            safe_args = []
            for an in arg_nodes:
                try:
                    safe_args.append(self._eval(an, env))
                except Exception:
                    # Variable non definie = probablement un nom de type
                    if hasattr(an, 'name'):
                        safe_args.append(an.name)  # passer le nom comme string
                    elif hasattr(an, 'value'):
                        safe_args.append(an.value)
                    else:
                        safe_args.append(None)
            args = safe_args
        else:
            args = [self._eval(a, env) for a in arg_nodes]
        # ── User-defined FIRST (priorité sur les builtins) ───────
        if nl in self.funcs:
            f = self.funcs[nl]
            child = Env(name=f'func:{name}')
            ref_backs = []
            for param_info, av, an in zip(f.params, args, arg_nodes):
                pn = param_info[0]
                is_ref = param_info[2] if len(param_info) > 2 else False
                child.declare(pn.lower(), av)
                if is_ref:
                    ref_backs.append((pn.lower(), an))
            self._declare_vars(f.vars, child)
            old = self.current_env; self.current_env = child
            try:
                self._exec_stmts(f.body, child)
            except ReturnSig as rs:
                for pn, an in ref_backs:
                    self._lval_set(an, child._vars.get(pn), env)
                return rs.val
            finally:
                self.current_env = old
            for pn, an in ref_backs:
                try:
                    self._lval_set(an, child._vars.get(pn), env)
                except Exception:
                    pass
            return None


        # ── Builtins ───────────────────────────
        if nl in ('abs','valabs'):          return abs(args[0])
        if nl in ('sqrt','racine'):         return math.sqrt(args[0])
        if nl in ('floor','entier_inf'):    return int(math.floor(args[0]))
        if nl in ('ceil','entier_sup'):     return int(math.ceil(args[0]))
        if nl == 'arrondi':                 return round(args[0], args[1] if len(args)>1 else 0)
        if nl in ('mod','modulo'):          return args[0] % args[1]
        if nl in ('max',):                  return max(args[0], args[1])
        if nl in ('min',):                  return min(args[0], args[1])
        if nl in ('pow','puissance'):       return args[0] ** args[1]
        if nl == 'log':                     return math.log(args[0])
        if nl == 'log2':                    return math.log2(args[0])
        if nl == 'log10':                   return math.log10(args[0])
        if nl == 'sin':                     return math.sin(args[0])
        if nl == 'cos':                     return math.cos(args[0])
        if nl == 'tan':                     return math.tan(args[0])
        if nl == 'pi':                      return math.pi
        if nl == 'e':                       return math.e
        if nl in ('long','longueur','strlen','length'):
            return len(args[0]) if args[0] is not None else 0
        # ── taille : taille en octets OU taille d un tableau ──────────────
        if nl == 'taille':
            # taille peut être appelé de deux façons :
            #   taille(variable)      → taille de la valeur runtime
            #   taille(entier)        → 4 (nom de type en string depuis KW)
            # Gérer d'abord les noms de types passés comme string keyword
            _TYPE_SIZES = {
                'entier':4,'reel':8,'booleen':1,'caractere':1,
                'chaine':256,'pointeur':8,'fichier':8,
            }
            # Si arg est un nom de type keyword (évalué comme string par le parser)
            if args and isinstance(args[0], str):
                k = args[0].lower()
                if k in _TYPE_SIZES: return _TYPE_SIZES[k]
                # Type defini par l'utilisateur (enregistrement)
                if k in self.type_defs:
                    fields = self.type_defs[k]
                    total = sum(4 for _ in fields)  # ~4 bytes/champ
                    return max(total, 8)  # min 8 pour un noeud
                # Sinon taille d une chaîne
                return len(args[0])
            v = args[0] if args else None
            if isinstance(v, bool):   return 1
            if isinstance(v, int):    return 4
            if isinstance(v, float):  return 8
            if isinstance(v, list):   return len(v)
            if isinstance(v, dict):
                # Enregistrement : somme des tailles des champs
                total = 0
                for fv in v.values():
                    if isinstance(fv, bool):   total += 1
                    elif isinstance(fv, int):  total += 4
                    elif isinstance(fv, float):total += 8
                    elif isinstance(fv, list): total += len(fv)*4
                    else:                      total += 8
                return max(total, 1)
            if v is None: return 0
            return _TYPE_SIZES.get(str(v).lower(), 4)
        if nl in ('entier','int'):          return int(args[0])
        if nl in ('reel','float'):          return float(args[0])
        if nl in ('chaine','str'):          return str(args[0])
        if nl == 'ord':                     return ord(args[0])
        if nl == 'chr':                     return chr(int(args[0]))
        if nl == 'majuscule':               return str(args[0]).upper()
        if nl == 'minuscule':               return str(args[0]).lower()
        if nl == 'concat':                  return ''.join(self._to_str(a) for a in args)
        if nl == 'sous_chaine':
            s,start,end=args[0],int(args[1]),int(args[2])
            return s[start:end]
        if nl == 'trouve':                  return args[0].find(args[1])
        if nl == 'remplace':                return args[0].replace(args[1], args[2])
        if nl == 'trim':                    return args[0].strip()
        if nl in ('random','aleatoire'):    return random.random()
        if nl in ('aleatoire_entier','random_int'):
            return random.randint(int(args[0]), int(args[1]))
        if nl in ('estvide','est_vide'):
            v=args[0]; return v is None or v==[] or v==''
        if nl in ('finfichier','fin_fichier','eof','fin'):
            fh = args[0] if args else None
            if isinstance(fh, dict) and '_file' in fh:
                return fh.get('_eof', False)
            return True
        if nl == 'ecrire':
            self.output_cb(' '.join(self._to_str(a) for a in args)); return None
        # ── Tableau De Caractère ────────────────────────────────────────
        if nl in ('chaine_vers_tableau', 'str_to_tab'):
            # chaine_vers_tableau(s) → liste de caractères
            s = str(args[0]) if args else ''
            return list(s)
        if nl in ('tableau_vers_chaine', 'tab_to_str'):
            # tableau_vers_chaine(tab) → chaine
            if isinstance(args[0], list):
                return ''.join(str(c) for c in args[0] if c and c != '')
            return str(args[0]) if args[0] else ''
        # ── Gestion mémoire dynamique ──────────────────────────────────────
        if nl in ('nouveau',):
            # Nouveau(p) — alloue un enregistrement vide (dict)
            return {}
        if nl in ('allouer',):
            # allouer(n * taille(entier))  ou  allouer(n * taille(MonType))
            # On reçoit le résultat de n*taille déjà calculé → entier
            # On retourne une liste de n cases (on ignore la taille unitaire)
            if args:
                raw = args[0]
                if isinstance(raw, (int, float)) and raw > 0:
                    # Cas allouer(n * taille(T)) : raw = n * sizeof(T)
                    # Heuristique : si raw est un multiple de 4, 8, 1 → déduire n
                    # On garde raw comme nb d octets et on alloue raw//min_size cases
                    # Mais pour simplifier : retourner raw cases (max 9999)
                    n_elems = max(1, min(int(raw), 9999))
                    # Si raw ressemble à n*taille (>100), on divise par 4
                    if raw > 100:
                        n_elems = max(1, int(raw) // 4)
                    return [None] * n_elems
                if isinstance(raw, list): return raw
            return []
        if nl in ('allouer_tableau',):
            # allouer_tableau(n) → alloue un tableau dynamique de n éléments
            n_elems = int(args[0]) if args else 0
            return [None] * n_elems
        if nl in ('liberer',):
            return None   # Liberer(p) — libéré (mis à None)
        if nl in ('ouvrir',):
            # ouvrir(chemin, mode) — args[0]=chemin, args[1]=mode
            path_arg = str(args[0]).strip() if len(args) > 0 else ''
            mode_arg = str(args[1]).lower()  if len(args) > 1 else 'lecture'
            is_write  = ('ecriture' in mode_arg or
                        'ecriture' in mode_arg.replace('é','e'))
            is_append = ('mise' in mode_arg or 'ajout' in mode_arg or
                        'mettre' in mode_arg or 'update' in mode_arg)
            # Si pas de chemin fourni -> ouvrir un dialog de fichier
            if not path_arg:
                try:
                    import tkinter.filedialog as _fd
                    ftypes = [('Fichier donnees','*.dat'),('Texte','*.txt'),
                            ('CSV','*.csv'),('Tous','*.*')]
                    if is_write:
                        path_arg = _fd.asksaveasfilename(
                            title='Enregistrer le fichier',
                            filetypes=ftypes, defaultextension='.dat')
                    elif is_append:
                        path_arg = _fd.asksaveasfilename(
                            title='Mise a jour du fichier',
                            filetypes=ftypes, defaultextension='.dat')
                    else:
                        path_arg = _fd.askopenfilename(
                            title='Ouvrir un fichier', filetypes=ftypes)
                except Exception:
                    path_arg = ''
                if not path_arg: return None
            try:
                ext = path_arg.rsplit('.',1)[-1].lower() if '.' in path_arg else 'dat'
                if is_write:
                    fh = open(path_arg, 'w', encoding='utf-8')
                    fmode = 'w'
                elif is_append:
                    fh = open(path_arg, 'a+', encoding='utf-8')
                    fh.seek(0)
                    fmode = 'a+'
                else:
                    fh = open(path_arg, 'r', encoding='utf-8')
                    fmode = 'r'
                return {'_file': fh, '_path': path_arg,
                        '_ext': ext, '_mode': fmode, '_eof': False}
            except Exception as ex:
                raise AlgoRTError(f"Impossible d'ouvrir '{path_arg}': {ex}", line)
        if nl == 'pointer':
            # pointer(f, pos) — deplace la tete de L/E (acces direct Ch7)
            fh = args[0] if args else None
            pos = int(args[1]) if len(args) > 1 else 0
            if isinstance(fh, dict) and '_file' in fh:
                try: fh['_file'].seek(pos); fh['_eof'] = False
                except Exception as ex:
                    raise AlgoRTError(f'pointer: {ex}', line)
            return None
        if nl in ('fermer',):
            if args and isinstance(args[0], dict) and '_file' in args[0]:
                try: args[0]['_file'].close()
                except: pass
            return None
        # ── Piles / Files simulées (tableaux) ─────────────────────────
        if nl in ('empiler',):
            # Empiler(pile, valeur) — pile est une liste
            if isinstance(args[0], list): args[0].append(args[1])
            return None
        if nl in ('depiler',):
            if isinstance(args[0], list) and args[0]:
                return args[0].pop()
            raise AlgoRTError("Dépiler sur une pile vide", line)
        if nl in ('enfiler',):
            if isinstance(args[0], list): args[0].append(args[1])
            return None
        if nl in ('defiler',):
            if isinstance(args[0], list) and args[0]:
                return args[0].pop(0)
            raise AlgoRTError("Défiler sur une file vide", line)
        if nl in ('pilevide','pile_vide','estvide_pile'):
            return args[0] is None or args[0] == []
        if nl in ('filevide','file_vide','estvide_file'):
            return args[0] is None or args[0] == []
        if nl in ('sommet',):
            if isinstance(args[0], list) and args[0]: return args[0][-1]
            raise AlgoRTError("Sommet d'une pile vide", line)
        if nl in ('tete',):
            if isinstance(args[0], list) and args[0]: return args[0][0]
            raise AlgoRTError("Tête d'une file vide", line)


        # ── User-defined ───────────────────────
        if nl in self.funcs:
            f = self.funcs[nl]
            child = Env(name=f'func:{name}')
            # Pass-by-value (E/) ou by-reference (S/ ou E/S/)
            ref_backs = []  # [(param_name, arg_node)] pour les E/S/
            for param_info, av, an in zip(f.params, args, arg_nodes):
                pn = param_info[0]
                is_ref = param_info[2] if len(param_info) > 2 else False
                child.declare(pn.lower(), av)
                if is_ref:
                    ref_backs.append((pn.lower(), an))
            self._declare_vars(f.vars, child)
            old = self.current_env; self.current_env = child
            try:
                self._exec_stmts(f.body, child)
            except ReturnSig as rs:
                # Write back ref params before return
                for pn, an in ref_backs:
                    self._lval_set(an, child._vars.get(pn), env)
                return rs.val
            finally:
                self.current_env = old
            # Write back E/S/ parameters to caller
            for pn, an in ref_backs:
                try:
                    self._lval_set(an, child._vars.get(pn), env)
                except Exception:
                    pass
            return None

        raise AlgoRTError(f"Fonction inconnue: '{name}'", line)

    def _to_str(self, v):
        if v is True:  return 'Vrai'
        if v is False: return 'Faux'
        if v is None:  return 'NIL'
        if isinstance(v, float) and v==int(v): return str(int(v))
        if isinstance(v, list): return '[' + ', '.join(self._to_str(x) for x in v) + ']'
        return str(v)

    def _coerce(self, raw):
        s = raw.strip()
        try: return int(s)
        except ValueError: pass
        try: return float(s)
        except ValueError: pass
        if s.lower() in ('vrai','true','1'): return True
        if s.lower() in ('faux','false','0'): return False
        return s

# ══════════════════════════════════════════════════════════════════════
