# -*- coding: utf-8 -*-
"""Génération de code C et Python à partir de l'AST."""

from ast_nodes import *

#  CODE GENERATORS — Export vers C et Python
# ══════════════════════════════════════════════════════════════════════

class CodeGenC:
    """Génère du code C à partir d'un AST Programme."""

    def __init__(self):
        self._indent = 0
        self._lines  = []
        self._types  = {}   # type_defs enregistrements

    def _w(self, s=''):
        self._lines.append('    ' * self._indent + s)

    def _type_c(self, t):
        if t == 'entier':   return 'int'
        if t == 'reel':     return 'double'
        if t == 'booleen':  return 'int'
        if t == 'chaine':   return 'char*'
        if t == 'caractere':return 'char'
        if isinstance(t, tuple):
            if t[0] == 'tableau': return self._type_c(t[2]) + '*'
            if t[0] == 'pointeur': return self._type_c(t[1]) + '*'
        return str(t)

    def _decl_c(self, name, typ):
        if isinstance(typ, tuple) and typ[0] == 'tableau':
            sz = typ[1]
            size_str = ''.join(f'[{self._expr_c(s)}]' for s in sz) if sz else '[1024]'
            return f"{self._type_c(typ[2])} {name}{size_str}"
        return f"{self._type_c(typ)} {name}"

    def generate(self, prog):
        self._types = getattr(prog, 'types', {})
        self._w('#include <stdio.h>')
        self._w('#include <string.h>')
        self._w('#include <math.h>')
        self._w('#include <stdlib.h>')
        self._w()
        # Structs
        for tname, fields in self._types.items():
            self._w(f'typedef struct {{')
            self._indent += 1
            for fn, ft in fields:
                self._w(f'{self._decl_c(fn, ft)};')
            self._indent -= 1
            self._w(f'}} {tname.capitalize()};')
            self._w()
        # Fonctions
        for f in prog.funcs:
            self._gen_func(f)
        # main
        self._w('int main(void) {')
        self._indent += 1
        for d in prog.vars:
            for name in d.names:
                self._w(f'{self._decl_c(name, d.type)};')
        for s in prog.body:
            self._gen_stmt(s)
        self._w('return 0;')
        self._indent -= 1
        self._w('}')
        return '\n'.join(self._lines)

    def _gen_func(self, f):
        rt = self._type_c(f.ret_type) if f.ret_type else 'void'
        params = ', '.join(self._decl_c(pn, pt) for pn, pt in f.params)
        self._w(f'{rt} {f.name}({params}) {{')
        self._indent += 1
        for d in f.vars:
            for name in d.names:
                self._w(f'{self._decl_c(name, d.type)};')
        for s in f.body:
            self._gen_stmt(s)
        self._indent -= 1
        self._w('}')
        self._w()

    def _gen_stmt(self, node):
        if node is None: return
        t = type(node).__name__
        if t == 'Assign':
            self._w(f'{self._lval_c(node.target)} = {self._expr_c(node.value)};')
        elif t == 'Ecrire':
            args = node.args
            fmt_parts = []; vals = []
            for a in args:
                fmt_parts.append('%s'); vals.append(f'_to_str({self._expr_c(a)})')
            self._w(f'printf("{" ".join(fmt_parts)}\\n"{(", " + ", ".join(vals)) if vals else ""});')
        elif t == 'Lire':
            for tgt in node.targets:
                self._w(f'scanf("%s", &{self._lval_c(tgt)});')
        elif t == 'If':
            self._w(f'if ({self._expr_c(node.cond)}) {{')
            self._indent += 1
            for s in node.then: self._gen_stmt(s)
            self._indent -= 1
            if node.else_:
                self._w('} else {')
                self._indent += 1
                for s in node.else_: self._gen_stmt(s)
                self._indent -= 1
            self._w('}')
        elif t == 'While':
            self._w(f'while ({self._expr_c(node.cond)}) {{')
            self._indent += 1
            for s in node.body: self._gen_stmt(s)
            self._indent -= 1
            self._w('}')
        elif t == 'For':
            v = node.var; st = self._expr_c(node.start); en = self._expr_c(node.end)
            step = self._expr_c(node.step) if node.step else '1'
            cmp = '<=' if (not node.step) else '>=' if '-' in str(step) else '<='
            self._w(f'for (int {v} = {st}; {v} {cmp} {en}; {v} += {step}) {{')
            self._indent += 1
            for s in node.body: self._gen_stmt(s)
            self._indent -= 1
            self._w('}')
        elif t == 'Repeat':
            self._w('do {')
            self._indent += 1
            for s in node.body: self._gen_stmt(s)
            self._indent -= 1
            self._w(f'}} while (!({self._expr_c(node.cond)}));')
        elif t == 'Return':
            self._w(f'return {self._expr_c(node.value)};')
        elif t == 'Break':
            self._w('break;')
        elif t == 'Continue':
            self._w('continue;')
        elif t == 'FuncCall':
            self._w(f'{node.name}({", ".join(self._expr_c(a) for a in node.args)});')
        elif t == 'Switch':
            self._w(f'switch ({self._expr_c(node.expr)}) {{')
            self._indent += 1
            for cv, stmts in node.cases:
                self._w(f'case {self._expr_c(cv)}:')
                self._indent += 1
                for s in stmts: self._gen_stmt(s)
                self._w('break;')
                self._indent -= 1
            if node.default:
                self._w('default:')
                self._indent += 1
                for s in node.default: self._gen_stmt(s)
                self._indent -= 1
            self._indent -= 1
            self._w('}')

    def _lval_c(self, node):
        t = type(node).__name__
        if t == 'Var': return node.name
        if t == 'ArrayAccess': return f'{self._lval_c(node.name)}[{self._expr_c(node.index)}]'
        if t == 'FieldAccess': return f'{self._lval_c(node.obj)}.{node.field}'
        return str(node)

    def _expr_c(self, node):
        if node is None: return '0'
        t = type(node).__name__
        if t == 'Literal':
            v = node.value
            if v is True: return '1'
            if v is False: return '0'
            if v is None: return 'NULL'
            if isinstance(v, str): return f'"{v}"'
            return str(v)
        if t == 'Var': return node.name
        if t == 'ArrayAccess': return f'{self._expr_c(node.name)}[{self._expr_c(node.index)}]'
        if t == 'FieldAccess': return f'{self._expr_c(node.obj)}.{node.field}'
        if t == 'BinOp':
            op_map = {'div':'/', 'mod':'%', 'et':'&&', 'ou':'||', '=':'==', '<>':'!='}
            op = op_map.get(node.op, node.op)
            return f'({self._expr_c(node.left)} {op} {self._expr_c(node.right)})'
        if t == 'UnaryOp':
            if node.op == '-': return f'(-{self._expr_c(node.operand)})'
            if node.op == 'non': return f'(!{self._expr_c(node.operand)})'
        if t == 'FuncCall':
            return f'{node.name}({", ".join(self._expr_c(a) for a in node.args)})'
        return '0'


class CodeGenPython:
    """Génère du code Python à partir d'un AST Programme."""

    def __init__(self):
        self._indent = 0
        self._lines  = []

    def _w(self, s=''):
        self._lines.append('    ' * self._indent + s)

    def generate(self, prog):
        self._w('# Généré par AlgoStudio')
        self._w('import math, random')
        self._w()
        # Enregistrements → dataclasses
        types = getattr(prog, 'types', {})
        if types:
            self._w('from dataclasses import dataclass, field')
            for tname, fields in types.items():
                self._w(f'@dataclass')
                self._w(f'class {tname.capitalize()}:')
                self._indent += 1
                for fn, ft in fields:
                    self._w(f'{fn}: {self._type_py(ft)} = {self._default_py(ft)}')
                self._indent -= 1
                self._w()
        # Fonctions
        for f in prog.funcs:
            self._gen_func(f)
        # Corps principal
        self._w('def main():')
        self._indent += 1
        for d in prog.vars:
            for name in d.names:
                self._w(f'{name} = {self._default_py(d.type)}')
        for s in prog.body:
            self._gen_stmt(s)
        self._indent -= 1
        self._w()
        self._w("if __name__ == '__main__':")
        self._indent += 1
        self._w('main()')
        self._indent -= 1
        return '\n'.join(self._lines)

    def _type_py(self, t):
        if t == 'entier': return 'int'
        if t == 'reel': return 'float'
        if t == 'booleen': return 'bool'
        if t in ('chaine','caractere'): return 'str'
        if isinstance(t, tuple) and t[0] == 'tableau': return 'list'
        return 'object'

    def _default_py(self, t):
        if t == 'entier': return '0'
        if t == 'reel': return '0.0'
        if t == 'booleen': return 'False'
        if t in ('chaine','caractere'): return "''"
        if isinstance(t, tuple) and t[0] == 'tableau': return '[]'
        return 'None'

    def _gen_func(self, f):
        params = ', '.join(pn for pn, _ in f.params)
        self._w(f'def {f.name}({params}):')
        self._indent += 1
        for d in f.vars:
            for name in d.names:
                self._w(f'{name} = {self._default_py(d.type)}')
        for s in f.body:
            self._gen_stmt(s)
        if not f.body:
            self._w('pass')
        self._indent -= 1
        self._w()

    def _gen_stmt(self, node):
        if node is None: return
        t = type(node).__name__
        if t == 'Assign':
            self._w(f'{self._lval_py(node.target)} = {self._expr_py(node.value)}')
        elif t == 'Ecrire':
            args_py = ', '.join(f'str({self._expr_py(a)})' for a in node.args)
            self._w(f'print(" ".join([{args_py}]))')
        elif t == 'Lire':
            for tgt in node.targets:
                self._w(f'{self._lval_py(tgt)} = input()')
        elif t == 'If':
            self._w(f'if {self._expr_py(node.cond)}:')
            self._indent += 1
            for s in node.then: self._gen_stmt(s)
            if not node.then: self._w('pass')
            self._indent -= 1
            if node.else_:
                self._w('else:')
                self._indent += 1
                for s in node.else_: self._gen_stmt(s)
                self._indent -= 1
        elif t == 'While':
            self._w(f'while {self._expr_py(node.cond)}:')
            self._indent += 1
            for s in node.body: self._gen_stmt(s)
            if not node.body: self._w('pass')
            self._indent -= 1
        elif t == 'For':
            v = node.var; st = self._expr_py(node.start); en = self._expr_py(node.end)
            step = self._expr_py(node.step) if node.step else '1'
            self._w(f'for {v} in range({st}, {en}+1, {step}):')
            self._indent += 1
            for s in node.body: self._gen_stmt(s)
            if not node.body: self._w('pass')
            self._indent -= 1
        elif t == 'Repeat':
            self._w('while True:')
            self._indent += 1
            for s in node.body: self._gen_stmt(s)
            self._w(f'if {self._expr_py(node.cond)}: break')
            self._indent -= 1
        elif t == 'Return':
            self._w(f'return {self._expr_py(node.value)}')
        elif t == 'Break':
            self._w('break')
        elif t == 'Continue':
            self._w('continue')
        elif t == 'FuncCall':
            self._w(f'{node.name}({", ".join(self._expr_py(a) for a in node.args)})')
        elif t == 'Switch':
            first = True
            for cv, stmts in node.cases:
                kw = 'if' if first else 'elif'
                self._w(f'{kw} {self._expr_py(node.expr)} == {self._expr_py(cv)}:')
                self._indent += 1
                for s in stmts: self._gen_stmt(s)
                if not stmts: self._w('pass')
                self._indent -= 1
                first = False
            if node.default:
                self._w('else:')
                self._indent += 1
                for s in node.default: self._gen_stmt(s)
                self._indent -= 1

    def _lval_py(self, node):
        t = type(node).__name__
        if t == 'Var': return node.name
        if t == 'ArrayAccess': return f'{self._lval_py(node.name)}[{self._expr_py(node.index)}]'
        if t == 'FieldAccess': return f'{self._lval_py(node.obj)}.{node.field}'
        return str(node)

    def _expr_py(self, node):
        if node is None: return 'None'
        t = type(node).__name__
        if t == 'Literal':
            v = node.value
            if v is True: return 'True'
            if v is False: return 'False'
            if v is None: return 'None'
            if isinstance(v, str): return repr(v)
            return str(v)
        if t == 'Var': return node.name
        if t == 'ArrayAccess': return f'{self._expr_py(node.name)}[{self._expr_py(node.index)}]'
        if t == 'FieldAccess': return f'{self._expr_py(node.obj)}.{node.field}'
        if t == 'BinOp':
            op_map = {'div':'//', 'mod':'%', 'et':' and ', 'ou':' or ',
                    '=':'==', '<>':'!=', 'non':'not '}
            op = op_map.get(node.op, node.op)
            return f'({self._expr_py(node.left)}{op}{self._expr_py(node.right)})'
        if t == 'UnaryOp':
            if node.op == '-': return f'(-{self._expr_py(node.operand)})'
            if node.op == 'non': return f'(not {self._expr_py(node.operand)})'
        if t == 'FuncCall':
            fn = node.name.lower()
            fn_map = {'sqrt':'math.sqrt','abs':'abs','pow':'pow',
                    'longueur':'len','ecrire':'print','lire':'input'}
            fn_py = fn_map.get(fn, node.name)
            return f'{fn_py}({", ".join(self._expr_py(a) for a in node.args)})'
        return 'None'


# ══════════════════════════════════════════════════════════════════════
