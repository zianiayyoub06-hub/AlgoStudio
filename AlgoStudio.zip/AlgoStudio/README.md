# AlgoStudio 🖥️

![Python](https://img.shields.io/badge/Python-3.8+-blue?logo=python&logoColor=white)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20Mac-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)
![Size](https://img.shields.io/github/repo-size/ZIANIAyyoub/AlgoStudio)
![Stars](https://img.shields.io/github/stars/ZIANIAyyoub/AlgoStudio?style=social)

> **Compilateur et interpréteur de pseudocode algorithmique en français.**  
> Application bureau complète — Python 3 + Tkinter, sans aucune dépendance externe.

Développé par **ZIANI Ayyoub**

---

## 📸 Aperçu

> *(Ajoutez une capture d'écran ici après le premier lancement — faites `Win+Shift+S` et déposez l'image dans le repo)*

---

## ✨ Fonctionnalités

| Fonctionnalité | Description |
|----------------|-------------|
| ▶️ **Exécution directe** | Interprète et exécute le pseudocode en temps réel |
| 💡 **Auto-complétion** | Suggestions intelligentes : mots-clés + vos variables |
| 📊 **Variables en direct** | Visualiseur live de toutes les variables pendant l'exécution |
| ⬆️ **Export C / Python** | Génère du code C ou Python à partir de votre algorithme |
| 📄 **Onglets multiples** | Travaillez sur plusieurs fichiers simultanément |
| 🔍 **Recherche avancée** | Chercher et remplacer avec surlignage |
| 🎨 **Thèmes** | Dark / Light — sauvegardés automatiquement |
| 💾 **Session persistante** | Vos fichiers ouverts sont restaurés au prochain lancement |
| 📖 **Exemples intégrés** | Bibliothèque d'exemples organisée par chapitre (Ch.1 à Ch.8) |

---

## 🚀 Installation et lancement

### Prérequis
- Python **3.8 ou supérieur**
- Tkinter (inclus par défaut avec Python)

### Lancement
```bash
# Cloner le dépôt
git clone https://github.com/ZIANIAyyoub/AlgoStudio.git
cd AlgoStudio

# Lancer l'application
python main.py
```

> ✅ Aucune installation de bibliothèque requise.

---

## ⌨️ Raccourcis clavier

| Raccourci | Action |
|-----------|--------|
| `F5` | ▶ Exécuter l'algorithme |
| `F6` | ■ Arrêter l'exécution |
| `F7` | 📊 Visualiseur de variables (Live) |
| `Ctrl+T` | 📄 Nouvel onglet |
| `Ctrl+W` | ✕ Fermer l'onglet courant |
| `Ctrl+Espace` | 💡 Auto-complétion |
| `Ctrl+F` | 🔍 Chercher / Remplacer |
| `Ctrl+/` | 💬 Commenter / Décommenter la ligne |
| `Tab` | → Indenter / Valider une suggestion |
| `Échap` | ✕ Fermer la suggestion |

---

## 📝 Structure d'un algorithme

```
Algorithme <Nom>;

Type <NomType> = Enregistrement    // optionnel
    champ : Type;
Fin;

Var
    variable   : Entier;
    tab[N]     : Tableau De Entier;
    ptr        : ^Entier;          // pointeur

Debut
    <instructions>
Fin.
```

---

## 💡 Exemple rapide

```
Algorithme TableDeMultiplication;
Var
    n, i : Entier;
Debut
    Ecrire("Entrez un nombre :");
    Lire(n);
    Pour i <- 1 a 10 Faire
        Ecrire(n, "x", i, "=", n * i);
    FinPour;
Fin.
```

---

## 📁 Structure du projet

```
AlgoStudio/
├── main.py          ← Point d'entrée — lancer ici
├── app.py           ← Interface graphique (Tkinter)
├── lexer.py         ← Tokeniseur (Lexer)
├── ast_nodes.py     ← Nœuds AST
├── parser.py        ← Analyse syntaxique (Parser)
├── interpreter.py   ← Exécution (Interpréteur)
├── codegen.py       ← Export vers C et Python
├── themes.py        ← Thèmes de couleurs
└── examples.py      ← Exemples intégrés par chapitre
```

---

## 🗺️ Roadmap

- [ ] Mode débogage pas-à-pas
- [ ] Support des fichiers `.algo`
- [ ] Traduction de l'interface en arabe
- [ ] Version web (browser)

---

## 📄 Licence

Ce projet est sous licence **MIT** — voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

## 📬 Contact

**ZIANI Ayyoub** — zianiayyoub06@gmail.com

Si ce projet vous a été utile, laissez une ⭐ sur GitHub !
