# -*- coding: utf-8 -*-
"""Interface graphique principale — Tkinter."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import sys, os, json, threading, copy, re, math, time, string
from pathlib import Path
from datetime import datetime

from lexer import tokenize, LexerError, KEYWORDS
from parser import Parser, ParseError
from interpreter import Interpreter, AlgoRTError, BUILTIN_FUNCS, StopSig
from codegen import CodeGenC, CodeGenPython as CodeGenPy
from themes import THEMES
from examples import EXAMPLES, SYNTAX_HELP

CONFIG_PATH = Path.home() / '.algostudio_config.json'

class App:
    def __init__(self, root):
        self.root          = root
        # ── Charger le thème sauvegardé ──────────────────────────────
        saved_theme = 'dark'
        self._session_files = []
        try:
            cfg = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
            if cfg.get('theme') in THEMES:
                saved_theme = cfg['theme']
            self._session_files = cfg.get('session_files', [])
        except Exception:
            pass
        self.theme_name    = saved_theme
        self.T             = THEMES[saved_theme]
        self._pos_lbl = None      
        # ── Tabs system ──────────────────────────────────────────────
        # Each tab: {'editor':widget, 'ln':widget, 'cur_file':str|None,
        #            'modified':bool, 'title':str, 'btn':widget}
        self._tabs         = []
        self._active_tab   = 0
        # ── Shared state ─────────────────────────────────────────────
        self.is_running    = False
        self._interp       = None
        self._input_ev     = threading.Event()
        self._input_val    = None
        self._waiting      = False
        self._find_win     = None
        self._ac_win       = None
        self._ac_lb        = None
        self._ac_items     = []
        self._ac_prefix_len = 0
        self._ac_editor_binds = []
        self._live_win     = None
        self._setup_window()
        self._build_ui()
        self._apply_tags()
        self._load_welcome()
        self.root.after(120, self._update_line_numbers)
        # Splash screen au démarrage (après que la fenêtre soit visible)
        self.root.after(200, self.show_welcome_splash)
        # Restaurer la session précédente après splash
        self.root.after(400, self._restore_session)

    # ── Tab accessor properties ────────────────────────────────────────
    @property
    def editor(self):
        if self._tabs: return self._tabs[self._active_tab]['editor']
        return None

    @property
    def _ln(self):
        if self._tabs: return self._tabs[self._active_tab]['ln']
        return None

    @property
    def cur_file(self):
        if self._tabs: return self._tabs[self._active_tab]['cur_file']
        return None

    @cur_file.setter
    def cur_file(self, v):
        if self._tabs: self._tabs[self._active_tab]['cur_file'] = v

    @property
    def _modified(self):
        if self._tabs: return self._tabs[self._active_tab]['modified']
        return False

    @_modified.setter
    def _modified(self, v):
        if self._tabs: self._tabs[self._active_tab]['modified'] = v

    # ─────────────────────────────────────────────────────────────────
    #  WINDOW
    # ─────────────────────────────────────────────────────────────────
    def _setup_window(self):
        T = self.T
        self.root.title("AlgoStudio")
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        w, h   = min(1400, sw - 40), min(840, sh - 60)
        self.root.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")
        self.root.minsize(800, 540)
        self.root.configure(bg=T['bg'])
        # ── Drag & Drop via événement <<Drop>> (tkinterdnd2 optionnel) ──
        self.root.bind('<Button-1>', lambda e: None)   # absorb
        try:
            self.root.drop_target_register('DND_Files')
            self.root.dnd_bind('<<Drop>>', self._on_drop)
        except Exception:
            pass  # tkinterdnd2 non installé → pas de drag & drop

    # ─────────────────────────────────────────────────────────────────
    #  UI BUILD
    # ─────────────────────────────────────────────────────────────────
    def _build_ui(self):
        self._build_menu()
        self._build_toolbar()
        self._build_main()
        self._build_statusbar()

    # ── MENU ──────────────────────────────────────────────────────────
    def _build_menu(self):
        T = self.T
        mb = tk.Menu(self.root, bg=T['bg2'], fg=T['fg'],
                    activebackground=T['accent'], activeforeground='white',
                    relief='flat', bd=0)
        self.root.config(menu=mb)

        def M(label, *items):
            m = tk.Menu(mb, tearoff=0, bg=T['bg2'], fg=T['fg'],
                        activebackground=T['accent'], activeforeground='white',
                        relief='flat')
            mb.add_cascade(label=label, menu=m)
            for it in items:
                if it is None:
                    m.add_separator()
                elif len(it) == 2:
                    m.add_command(label=it[0], command=it[1])
                else:
                    m.add_command(label=it[0], command=it[1], accelerator=it[2])
            return m

        M("Fichier",
            ("Nouveau",            self.new_file,   "Ctrl+N"),
            ("Nouvel onglet",      self.new_tab,    "Ctrl+T"),
            ("Fermer l onglet",    lambda: self.close_tab(self._active_tab), "Ctrl+W"),
            None,
            ("Ouvrir...",          self.open_file,  "Ctrl+O"),
            ("Enregistrer",        self.save_file,  "Ctrl+S"),
            ("Enregistrer sous...",self.save_as),
            None,
            ("Quitter",            self.root.quit))

        M("Edition",
            ("Annuler",  lambda: self.editor.event_generate("<<Undo>>"),  "Ctrl+Z"),
            ("Refaire",  lambda: self.editor.event_generate("<<Redo>>"),  "Ctrl+Y"),
            None,
            ("Couper",   lambda: self.editor.event_generate("<<Cut>>"),   "Ctrl+X"),
            ("Copier",   lambda: self.editor.event_generate("<<Copy>>"),  "Ctrl+C"),
            ("Coller",   lambda: self.editor.event_generate("<<Paste>>"), "Ctrl+V"),
            None,
            ("Chercher / Remplacer", self.show_find, "Ctrl+F"),
            ("Tout selectionner", lambda: self.editor.event_generate("<<SelectAll>>")))

        M("Executer",
            ("Executer",       self.run_code,    "F5"),
            ("Arreter",        self.stop_code,   "F6"),
            None,
            ("Effacer console",self.clear_console))

        M("Outils",
            ("Exemples (navigateur)",   self.show_example_browser),
            ("Inspecteur variables",    self.open_vars_inspector),
            ("Live Variables  F7",      self.show_live_vars),
            None,
            ("Exporter vers C...",      self.export_c),
            ("Exporter vers Python...", self.export_python),
            None,
            ("Reference syntaxe",       self.show_syntax),
            ("Suggestions Ctrl+Espace", self._trigger_autocomplete))

        M("Affichage",
            ("Theme sombre", lambda: self.set_theme('dark')),
            ("Theme clair",  lambda: self.set_theme('light')))

        M("Aide",
            ("Reference syntaxe", self.show_syntax),
            ("A propos",          self.show_about))

        for k, v in [
            ('<Control-a>', lambda e: self._select_all(e)),
            ('<Control-c>', lambda e: self._copy(e)),
            ('<Control-x>', lambda e: self._cut(e)),
            ('<Control-v>', lambda e: self._paste(e)),
            ('<Control-n>', lambda e: self.new_file()),
            ('<Control-t>', lambda e: self.new_tab()),
            ('<Control-w>', lambda e: self.close_tab(self._active_tab)),
            ('<Control-o>', lambda e: self.open_file()),
            ('<Control-s>', lambda e: self.save_file()),
            ('<Control-f>', lambda e: self.show_find()),
            ('<F5>',        lambda e: self.run_code()),
            ('<F6>',        lambda e: self.stop_code()),
            ('<F7>',        lambda e: self.show_live_vars()),
            ('<Control-Tab>',      lambda e: self.switch_tab((self._active_tab+1) % max(1,len(self._tabs)))),
            ('<Control-Shift-Tab>',lambda e: self.switch_tab((self._active_tab-1) % max(1,len(self._tabs)))),
        ]:
            self.root.bind(k, v)

    # ── TOOLBAR ───────────────────────────────────────────────────────
    def _build_toolbar(self):
        T = self.T
        tb = tk.Frame(self.root, bg=T['bg2'], height=44)
        tb.pack(fill=tk.X, side=tk.TOP)
        tb.pack_propagate(False)

        # ── helper: coloured button ─────────────────────────────────
        def btn(text, cmd, color=None, width=None):
            fg    = color or T['fg']
            kw    = dict(width=width) if width else {}
            b = tk.Button(tb, text=text, command=cmd,
                bg=T['bg2'], fg=fg, relief='flat', bd=0,
                padx=10, pady=6, cursor='hand2',
                font=('Consolas', 9, 'bold' if color else 'normal'),
                activebackground=T['bg4'], activeforeground=fg, **kw)
            b.pack(side=tk.LEFT, padx=1)
            b.bind('<Enter>', lambda e, b=b: b.config(bg=T['bg4']))
            b.bind('<Leave>', lambda e, b=b: b.config(bg=T['bg2']))
            return b

        def sep():
            tk.Frame(tb, bg=T['border'], width=1).pack(
                side=tk.LEFT, fill=tk.Y, padx=3, pady=7)

        # ── GROUP 1: File ───────────────────────────────────────────
        btn("📄 Nouveau",     self.new_file)
        btn("📂 Ouvrir",      self.open_file)
        btn("💾 Enregistrer", self.save_file)
        btn("📖 Exemples",    self.show_example_browser, T['teal'])
        sep()
        # ── GROUP 2: Run ────────────────────────────────────────────
        self._run_btn  = btn("▶  Exécuter  F5", self.run_code,  T['green'])
        self._stop_btn = btn("■  Arrêter   F6", self.stop_code, T['red'])
        sep()
        # ── GROUP 3: Tools ──────────────────────────────────────────
        btn("🔍 Chercher",      self.show_find)
        btn("🗑 Console",       self.clear_console)
        btn("📊 Live Vars  F7", self.show_live_vars, T['blue'])
        sep()
        # ── GROUP 4: Export ─────────────────────────────────────────
        def show_export_menu():
            T2 = self.T
            m = tk.Menu(self.root, tearoff=0,
                bg=T2['bg3'], fg=T2['fg'],
                activebackground=T2['accent'], activeforeground='white',
                relief='flat')
            m.add_command(label="Exporter vers C  (.c)",      command=self.export_c)
            m.add_command(label="Exporter vers Python  (.py)", command=self.export_python)
            try:
                x = self._export_btn.winfo_rootx()
                y = self._export_btn.winfo_rooty() + self._export_btn.winfo_height()
                m.tk_popup(x, y)
            finally:
                m.grab_release()
        self._export_btn = btn("⬆ Exporter ▾", show_export_menu, T['orange'])
        sep()
        btn("💡 Ctrl+Espace", self._trigger_autocomplete, T['fg2'])

        # ── Right side ──────────────────────────────────────────────
        tk.Button(tb, text="☀", command=self.toggle_theme,
            bg=T['bg2'], fg=T['yellow'], relief='flat', bd=0,
            padx=6, font=('Consolas', 13), cursor='hand2').pack(side=tk.RIGHT, padx=4)

        self._file_lbl = tk.Label(tb, text="  Sans titre  ",
            bg=T['bg2'], fg=T['fg2'], font=('Consolas', 9))
        self._file_lbl.pack(side=tk.RIGHT)

        self._mod_lbl = tk.Label(tb, text="",
            bg=T['bg2'], fg=T['yellow'], font=('Consolas', 9))
        self._mod_lbl.pack(side=tk.RIGHT)

    # ── MAIN AREA ─────────────────────────────────────────────────────
    def _build_main(self):
        T = self.T
        main = tk.Frame(self.root, bg=T['bg'])
        main.pack(fill=tk.BOTH, expand=True)

        # ── TAB BAR ─────────────────────────────────────────────────
        self._tab_bar = tk.Frame(main, bg=T['tab_bg'], height=32)
        self._tab_bar.pack(fill=tk.X, side=tk.TOP)
        self._tab_bar.pack_propagate(False)

        # "+" button to add a tab
        self._new_tab_btn = tk.Button(self._tab_bar,
            text=" + ", command=self.new_tab,
            bg=T['tab_bg'], fg=T['fg2'],
            relief='flat', bd=0, padx=8, pady=4,
            font=('Consolas', 10, 'bold'), cursor='hand2',
            activebackground=T['bg4'], activeforeground=T['accent'])
        self._new_tab_btn.pack(side=tk.LEFT, padx=2, pady=2)

        # ── TAB CONTENT AREA ────────────────────────────────────────
        self._tab_content = tk.Frame(main, bg=T['bg'])
        self._tab_content.pack(fill=tk.BOTH, expand=True)

        # Build first tab
        self._add_tab("Sans titre 1")

    def _add_tab(self, title):
        """Create a new editor tab and return its index."""
        T  = self.T
        idx = len(self._tabs)

        # ── Tab button ───────────────────────────────────────────────
        btn_frame = tk.Frame(self._tab_bar, bg=T['tab_bg'])
        btn_frame.pack(side=tk.LEFT, padx=1, pady=2)

        btn = tk.Label(btn_frame,
            text=f"  {title}  ",
            bg=T['tab_bg'], fg=T['fg2'],
            font=('Consolas', 9), cursor='hand2', padx=4, pady=3)
        btn.pack(side=tk.LEFT)

        close_btn = tk.Label(btn_frame,
            text=" ✕ ", bg=T['tab_bg'], fg=T['fg3'],
            font=('Consolas', 8), cursor='hand2')
        close_btn.pack(side=tk.LEFT)

        # ── Editor pane (hidden until activated) ────────────────────
        pane = tk.Frame(self._tab_content, bg=T['bg'])

        vp = tk.PanedWindow(pane, orient=tk.VERTICAL,
            bg=T['bg'], sashwidth=5, sashrelief='flat', bd=0)
        vp.pack(fill=tk.BOTH, expand=True)

        # Editor area
        ef = tk.Frame(vp, bg=T['editor_bg'])
        vp.add(ef, minsize=200)

        eh = tk.Frame(ef, bg=T['bg3'], height=26)
        eh.pack(fill=tk.X); eh.pack_propagate(False)
        title_lbl = tk.Label(eh, text=f"  ✎  {title}",
            bg=T['bg3'], fg=T['fg2'], font=('Consolas', 8, 'bold'))
        title_lbl.pack(side=tk.LEFT, padx=8, pady=4)

        erow = tk.Frame(ef, bg=T['editor_bg'])
        erow.pack(fill=tk.BOTH, expand=True)

        ln = tk.Text(erow, width=4, state='disabled',
            bg=T['editor_bg'], fg=T['line_num'],
            borderwidth=0, highlightthickness=0,
            font=('Consolas', 11), padx=4, pady=4,
            selectbackground=T['editor_bg'])
        ln.pack(side=tk.LEFT, fill=tk.Y)
        tk.Frame(erow, bg=T['border'], width=1).pack(side=tk.LEFT, fill=tk.Y)

        editor = tk.Text(erow, wrap='none',
            bg=T['editor_bg'], fg=T['editor_fg'],
            insertbackground=T['accent'], insertwidth=2,
            selectbackground=T['sel_bg'],
            borderwidth=0, highlightthickness=0,
            font=('Consolas', 11), padx=10, pady=4,
            undo=True, maxundo=-1, relief='flat')
        editor.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        vs = tk.Scrollbar(erow, orient=tk.VERTICAL,
            command=lambda *a: (editor.yview(*a), ln.yview_moveto(editor.yview()[0])),
            bg=T['bg3'], troughcolor=T['editor_bg'], relief='flat', width=10)
        vs.pack(side=tk.RIGHT, fill=tk.Y)
        hs = tk.Scrollbar(ef, orient=tk.HORIZONTAL, command=editor.xview,
            bg=T['bg3'], troughcolor=T['editor_bg'], relief='flat', width=10)
        hs.pack(fill=tk.X)
        editor.config(
            yscrollcommand=lambda f, l: (vs.set(f, l), ln.yview_moveto(editor.yview()[0])),
            xscrollcommand=hs.set)

        # Console area
        cf = tk.Frame(vp, bg=T['bg2'])
        vp.add(cf, minsize=150)
        ch = tk.Frame(cf, bg=T['bg3'], height=26)
        ch.pack(fill=tk.X); ch.pack_propagate(False)
        tk.Label(ch, text="  ▶  CONSOLE", bg=T['bg3'], fg=T['fg2'],
            font=('Consolas', 8, 'bold')).pack(side=tk.LEFT, padx=8, pady=4)
        time_lbl = tk.Label(ch, text="", bg=T['bg3'], fg=T['fg2'], font=('Consolas', 8))
        time_lbl.pack(side=tk.RIGHT, padx=8)

        cvs = tk.Scrollbar(cf, orient=tk.VERTICAL, bg=T['bg3'], troughcolor=T['bg2'],
            relief='flat', width=10)
        console = tk.Text(cf, wrap='word', bg=T['bg2'], fg=T['fg'],
            insertbackground=T['yellow'], insertwidth=3,
            borderwidth=0, highlightthickness=0,
            font=('Consolas', 11), padx=12, pady=8,
            state='disabled', relief='flat', yscrollcommand=cvs.set)
        cvs.config(command=console.yview)
        cvs.pack(side=tk.RIGHT, fill=tk.Y)
        console.pack(fill=tk.BOTH, expand=True)

        # Console input state
        inp_start = [None]
        waiting   = [False]
        console.bind('<Key>',       self._term_key)
        console.bind('<Return>',    self._term_enter)
        console.bind('<BackSpace>', self._term_bs)

        # Hint bar
        hf = tk.Frame(cf, bg=T['bg3'], height=22)
        hf.pack(fill=tk.X); hf.pack_propagate(False)
        hint_lbl = tk.Label(hf,
            text="  ●  Prêt  —  F5 pour exécuter",
            bg=T['bg3'], fg=T['fg2'], font=('Consolas', 8), anchor='w')
        hint_lbl.pack(fill=tk.X, padx=8)

        # ── Store tab data ───────────────────────────────────────────
        tab = {
            'idx':       idx,
            'title':     title,
            'cur_file':  None,
            'modified':  False,
            'editor':    editor,
            'ln':        ln,
            'pane':      pane,
            'btn_frame': btn_frame,
            'btn':       btn,
            'close_btn': close_btn,
            'title_lbl': title_lbl,
            'console':   console,
            'time_lbl':  time_lbl,
            'hint_lbl':  hint_lbl,
            'vp':        vp,
        }
        self._tabs.append(tab)

        # ── Bind editor events ───────────────────────────────────────
        editor.bind('<KeyRelease>',    self._ed_changed)
        editor.bind('<ButtonRelease>', self._ed_clicked)
        editor.bind('<Tab>',           self._on_tab)
        editor.bind('<Return>',        self._on_enter)
        editor.bind('<Control-a>', self._select_all)
        editor.bind('<Control-c>', self._copy)
        editor.bind('<Control-x>', self._cut)
        editor.bind('<Control-v>', self._paste)
        editor.bind('<Control-slash>', self._toggle_comment)
        editor.bind('<Control-space>', self._trigger_autocomplete)
        editor.bind('<Escape>',        self._close_autocomplete)

        # Apply syntax tags to new editor
        self._apply_tags_to(editor, console)

        # ── Bind tab switching ───────────────────────────────────────
        btn.bind('<Button-1>',        lambda e, i=idx: self.switch_tab(i))
        btn_frame.bind('<Button-1>',  lambda e, i=idx: self.switch_tab(i))
        close_btn.bind('<Button-1>',  lambda e, i=idx: self.close_tab(i))
        close_btn.bind('<Enter>',     lambda e: close_btn.config(fg=T['red']))
        close_btn.bind('<Leave>',     lambda e: close_btn.config(fg=T['fg3']))

        # Activate this tab
        self.switch_tab(idx)
        return idx

    def switch_tab(self, idx):
        """Switch active tab."""
        if idx < 0 or idx >= len(self._tabs): return
        T = self.T

        # Save AC bindings before switching
        self._close_autocomplete()

        # Hide all panes
        for tab in self._tabs:
            tab['pane'].pack_forget()
            tab['btn'].config(bg=T['tab_bg'], fg=T['fg2'])
            tab['btn_frame'].config(bg=T['tab_bg'])
            tab['close_btn'].config(bg=T['tab_bg'])

        # Show selected pane
        self._active_tab = idx
        tab = self._tabs[idx]
        tab['pane'].pack(fill=tk.BOTH, expand=True)
        tab['btn'].config(bg=T['tab_sel'], fg=T['fg'])
        tab['btn_frame'].config(bg=T['tab_sel'])
        tab['close_btn'].config(bg=T['tab_sel'])

        # Update shared references for console/time/hint
        self.console   = tab['console']
        self._time_lbl = tab['time_lbl']
        self._hint_lbl = tab['hint_lbl']
        self._inp_start = None
        self._waiting   = False

        # Sync status bar
        fname = tab['cur_file']
        from pathlib import Path as _P
        self._file_lbl.config(text=f"  {_P(fname).name if fname else tab['title']}  ")
        self._mod_lbl.config(text="● modifié  " if tab['modified'] else "")

        tab['editor'].focus_set()
        self._update_line_numbers()
        self._update_pos()

    def new_tab(self, title=None):
        """Open a new empty tab."""
        n     = len(self._tabs) + 1
        title = title or f"Sans titre {n}"
        idx   = self._add_tab(title)
        self._load_welcome()
        self._update_line_numbers()
        return idx

    def close_tab(self, idx):
        """Close a tab (with save prompt if modified)."""
        if len(self._tabs) <= 1:
            # Never close last tab — just clear it
            self.new_file(); return
        tab = self._tabs[idx]
        if tab['modified']:
            from tkinter import messagebox as mb
            if not mb.askyesno("Fermer",
                    f"Abandonner les modifications de «{tab['title']}» ?"):
                return
        # Destroy widgets
        tab['btn_frame'].destroy()
        tab['pane'].destroy()
        self._tabs.pop(idx)

        # Renumber remaining tabs
        for i, t in enumerate(self._tabs):
            t['idx'] = i
            t['btn'].bind('<Button-1>',  lambda e, ii=i: self.switch_tab(ii))
            t['close_btn'].bind('<Button-1>', lambda e, ii=i: self.close_tab(ii))

        # Switch to adjacent tab
        new_idx = min(idx, len(self._tabs) - 1)
        self.switch_tab(new_idx)

    def _apply_tags_to(self, editor, console):
        """Apply theme color tags to an editor + console widget."""
        T = self.T
        editor.tag_config('kw',      foreground=T['kw'])
        editor.tag_config('string',  foreground=T['string'])
        editor.tag_config('number',  foreground=T['number'])
        editor.tag_config('comment', foreground=T['comment'],
            font=('Consolas', 11, 'italic'))
        editor.tag_config('func',    foreground=T['func'])
        editor.tag_config('type_',   foreground=T['type_'])
        editor.tag_config('bool_',   foreground=T['bool_'])
        editor.tag_config('err_',    background='#3a0010')
        editor.tag_config('curline', background=T['cur_line'])
        editor.tag_config('find_all', background=T['yellow'], foreground='#000000')
        editor.tag_config('find_cur', background=T['accent'],  foreground='#ffffff')
        console.tag_config('out',    foreground=T['fg'])
        console.tag_config('inp',    foreground=T['yellow'])
        console.tag_config('err',    foreground=T['red'])
        console.tag_config('ok',     foreground=T['green'])
        console.tag_config('inf',    foreground=T['fg2'])
        console.tag_config('prompt', foreground=T['accent'])
        console.tag_config('sep',    foreground=T['fg3'])
        console.tag_config('userin', foreground=T['yellow'],
            font=('Consolas', 11, 'bold'))


    # ── STATUS BAR ────────────────────────────────────────────────────
    def _build_statusbar(self):
        T = self.T
        sb = tk.Frame(self.root, bg=T['status_bg'], height=22)
        sb.pack(fill=tk.X, side=tk.BOTTOM)
        sb.pack_propagate(False)
        self._status = tk.Label(sb,
            text="  ● AlgoStudio  |  F5 Exécuter  |  Ctrl+T Nouvel onglet  |  Ctrl+Espace Suggestions  |  📖 Exemples",
            bg=T['status_bg'], fg=T['green'],
            font=('Consolas', 8, 'bold'))
        self._status.pack(side=tk.LEFT)
        self._pos_lbl = tk.Label(sb, text="L1 C1  ",
            bg=T['status_bg'], fg=T['fg2'],
            font=('Consolas', 8))
        self._pos_lbl.pack(side=tk.RIGHT)

    # ─────────────────────────────────────────────────────────────────
    #  SYNTAX HIGHLIGHT TAGS
    # ─────────────────────────────────────────────────────────────────
    def _apply_tags(self):
        """Apply tags to the current active tab (called at startup)."""
        if self._tabs:
            tab = self._tabs[self._active_tab]
            self._apply_tags_to(tab['editor'], tab['console'])

    # ─────────────────────────────────────────────────────────────────
    #  SYNTAX HIGHLIGHT
    # ─────────────────────────────────────────────────────────────────
    def _highlight(self):
        code = self.editor.get('1.0', 'end-1c')
        for tag in ('kw', 'string', 'number', 'comment', 'func', 'type_', 'bool_'):
            self.editor.tag_remove(tag, '1.0', 'end')

        def mark(pat, tag, flags=re.IGNORECASE | re.MULTILINE):
            for m in re.finditer(pat, code, flags):
                s = self._idx(code, m.start())
                e = self._idx(code, m.end())
                self.editor.tag_add(tag, s, e)

        # ── 1. Mots-clés, types, booléens, nombres, fonctions ────────
        kw_pat = r'\b(' + '|'.join(sorted(
            (re.escape(k) for k in KEYWORDS), key=len, reverse=True)) + r')\b'
        mark(kw_pat, 'kw')
        mark(r'\b(Entier|Reel|Booleen|Chaine|Caractere|Tableau|Pointeur|Fichier)\b', 'type_')
        mark(r'\b(Vrai|Faux|NIL|Nil|nil)\b', 'bool_')
        mark(r'\b\d+\.?\d*\b', 'number')
        mark(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*\(', 'func')

        # ── 2. Chaînes et commentaires en DERNIER pour surpasser tout ─
        mark(r'"(?:[^"\\]|\\.)*"', 'string')
        mark(r"'(?:[^'\\]|\\.)'",  'string')
        mark(r'/\*.*?\*/', 'comment', re.DOTALL)
        mark(r'//[^\n]*',  'comment')

        # ── 3. Monter les priorités : comment > string > tout le reste ─
        self.editor.tag_raise('comment')
        self.editor.tag_raise('string')

    def _idx(self, text, pos):
        lines = text[:pos].split('\n')
        return f'{len(lines)}.{len(lines[-1])}'

    # ─────────────────────────────────────────────────────────────────
    #  LINE NUMBERS
    # ─────────────────────────────────────────────────────────────────
    def _ed_yview(self, *args):
        self.editor.yview(*args)
        self._sync_ln()

    def _sync_ln(self):
        self._ln.yview_moveto(self.editor.yview()[0])

    def _update_line_numbers(self):
        total = int(self.editor.index('end-1c').split('.')[0])
        nums  = '\n'.join(str(i) for i in range(1, total + 1))
        self._ln.config(state='normal')
        self._ln.delete('1.0', 'end')
        self._ln.insert('1.0', nums)
        self._ln.config(state='disabled')
        self._sync_ln()

    # ─────────────────────────────────────────────────────────────────
    #  EDITOR EVENTS
    # ─────────────────────────────────────────────────────────────────
    _AC_STOP = set(' \t\n;:()[]{}=+-*/<>!@#$%^&|~`')

    _hl_pending = False

    def _ed_changed(self, e=None):
        # Utiliser after_idle pour éviter les re-colorations en cascade
        if not self._hl_pending:
            self._hl_pending = True
            self.root.after_idle(self._hl_idle)
        self._update_pos()
        self._mark_current_line()
        if e and hasattr(e, 'char') and e.char:
            if e.char in self._AC_STOP:
                self._close_autocomplete()
            elif e.char.isprintable():
                self.root.after(50, self._live_ac)

    def _hl_idle(self):
        self._hl_pending = False
        self._highlight()
        self._update_line_numbers()
        if not self._modified:
            self._modified = True
            self._sync_tab_label()

    def _live_ac(self):
        prefix = self._get_prefix()
        if len(prefix) < 2:
            self._close_autocomplete()
            return
        items = self._ac_matches(prefix)
        if not items:
            self._close_autocomplete()
            return
        if self._ac_win:
            try:
                lb = self._ac_lb
                lb.delete(0, 'end')
                for _, label, _, _ in items:
                    lb.insert('end', f'  {label}')
                lb.select_set(0)
                self._ac_items      = items
                self._ac_prefix_len = len(prefix)
                # الأديتور يبقى معه الـ focus دائماً
                self.editor.focus_set()
                return
            except Exception:
                self._close_autocomplete()
        self._show_ac(items, prefix)

    def _ed_clicked(self, e=None):
        self._update_pos()
        self._mark_current_line()

    def _mark_current_line(self):
        self.editor.tag_remove('curline', '1.0', 'end')
        line = self.editor.index(tk.INSERT).split('.')[0]
        self.editor.tag_add('curline', f'{line}.0', f'{line}.end+1c')
        self.editor.tag_lower('curline')

    def _update_pos(self, e=None):
        if self._pos_lbl is None:
            return
        pos = self.editor.index(tk.INSERT).split('.')
        self._pos_lbl.config(text=f"L{pos[0]} C{int(pos[1])+1}  ")

    def _on_tab(self, e):
        # Si la popup autocomplete est ouverte → insérer le snippet sélectionné
        if self._ac_win:
            try:
                lb  = self._ac_lb
                sel = lb.curselection()
                idx = sel[0] if sel else 0
                self._do_insert(self._ac_items[idx][2], self._ac_prefix_len)
            except Exception:
                pass
            self._close_autocomplete()
            return 'break'
        self.editor.insert(tk.INSERT, '    ')
        return 'break'

    def _on_enter(self, e):
        # Si la popup autocomplete est ouverte → insérer le snippet sélectionné
        if self._ac_win:
            try:
                lb  = self._ac_lb
                sel = lb.curselection()
                idx = sel[0] if sel else 0
                self._do_insert(self._ac_items[idx][2], self._ac_prefix_len)
            except Exception:
                pass
            self._close_autocomplete()
            return 'break'
        line   = self.editor.get('insert linestart', 'insert lineend')
        indent = len(line) - len(line.lstrip())
        openers = ('alors', 'faire', 'debut', 'sinon', 'repeter', 'autrement')
        if any(line.strip().lower().endswith(op) for op in openers):
            indent += 4
        self.editor.insert(tk.INSERT, '\n' + ' ' * indent)
        return 'break'

    def _toggle_comment(self, e):
        try:
            start = self.editor.index('sel.first linestart')
            end   = self.editor.index('sel.last lineend')
        except tk.TclError:
            start = self.editor.index('insert linestart')
            end   = self.editor.index('insert lineend')
        lines = self.editor.get(start, end).split('\n')
        all_c = all(l.lstrip().startswith('//') for l in lines if l.strip())
        new   = []
        for l in lines:
            if all_c:
                new.append(re.sub(r'^(\s*)// ?', r'\1', l, count=1))
            else:
                s = len(l) - len(l.lstrip())
                new.append(l[:s] + '// ' + l[s:])
        self.editor.delete(start, end)
        self.editor.insert(start, '\n'.join(new))
        return 'break'

    # ─────────────────────────────────────────────────────────────────
    #  FILE OPERATIONS
    # ─────────────────────────────────────────────────────────────────

    def _select_all(self,e=None):
        if self.editor: self.editor.tag_add('sel','1.0','end'); self.editor.mark_set('insert','end')
        return 'break'
    def _copy(self,e=None):
        if self.editor:
            try: self.editor.event_generate('<<Copy>>')
            except: pass
        return 'break'
    def _cut(self,e=None):
        if self.editor:
            try: self.editor.event_generate('<<Cut>>')
            except: pass
        return 'break'
    def _paste(self,e=None):
        if self.editor:
            try: self.editor.event_generate('<<Paste>>')
            except: pass
        return 'break'

    def _restore_session(self):
        """Rouvre les fichiers de la session précédente."""
        files = getattr(self, '_session_files', [])
        if not files: return
        for i, info in enumerate(files):
            path = info.get('path','')
            if not path or not Path(path).exists(): continue
            try:
                code = Path(path).read_text(encoding='utf-8')
                if i == 0:
                    # Premier fichier → onglet existant
                    self.editor.delete('1.0', 'end')
                    self.editor.insert('1.0', code)
                    self.cur_file = path
                    self._modified = False
                    self._tabs[self._active_tab]['title'] = Path(path).name
                    self._sync_tab_label()
                    self._highlight()
                    self._update_line_numbers()
                else:
                    # Fichiers suivants → nouveaux onglets
                    idx = self._add_tab(Path(path).name)
                    self._tabs[idx]['editor'].insert('1.0', code)
                    self._tabs[idx]['cur_file'] = path
                    self.switch_tab(idx)
                    self._highlight()
                    self._update_line_numbers()
            except Exception:
                pass
        self.set_status(f"Session restaurée ({len(files)} fichier(s))", 'ok')

    def _on_drop(self, event):
        """Gérer les fichiers déposés par drag & drop."""
        data = event.data if hasattr(event, 'data') else ''
        # Nettoyer le chemin (tkinterdnd2 peut ajouter des accolades)
        paths = data.strip('{}').split('} {')
        for p in paths:
            p = p.strip()
            if p and Path(p).exists():
                try:
                    code = Path(p).read_text(encoding='utf-8')
                    # Ouvrir dans un nouvel onglet
                    idx = self._add_tab(Path(p).name)
                    self._tabs[idx]['editor'].insert('1.0', code)
                    self._tabs[idx]['cur_file'] = p
                    self.switch_tab(idx)
                    self._highlight()
                    self._update_line_numbers()
                    self.set_status(f"Ouvert par glisser-déposer : {Path(p).name}", 'ok')
                except Exception as ex:
                    self.set_status(f"Erreur glisser-déposer : {ex}", 'err')

    def _sync_tab_label(self):
        """Update toolbar labels and tab button for the active tab."""
        tab = self._tabs[self._active_tab]
        fname = tab['cur_file']
        title = Path(fname).name if fname else tab['title']
        self._file_lbl.config(text=f"  {title}  ")
        self._mod_lbl.config(text="● modifié  " if tab['modified'] else "")
        tab['btn'].config(text=f"  {title}  ")
        tab['title_lbl'].config(text=f"  ✎  {title}")

    def new_file(self):
        if self._modified and not messagebox.askyesno(
                "Nouveau", "Abandonner les modifications non sauvegardées ?"):
            return
        tab = self._tabs[self._active_tab]
        self.editor.delete('1.0', 'end')
        self.cur_file  = None
        self._modified = False
        tab['title'] = f"Sans titre {self._active_tab + 1}"
        self._sync_tab_label()
        self._update_line_numbers()
        self.set_status("Nouveau fichier", 'ok')

    def open_file(self):
        p = filedialog.askopenfilename(title="Ouvrir",
            filetypes=[("Algo", "*.algo"), ("Tous", "*.*")])
        if not p:
            return
        try:
            code = Path(p).read_text(encoding='utf-8')
        except Exception as ex:
            messagebox.showerror("Erreur", str(ex)); return
        self.editor.delete('1.0', 'end')
        self.editor.insert('1.0', code)
        self.cur_file  = p
        self._modified = False
        self._tabs[self._active_tab]['title'] = Path(p).name
        self._sync_tab_label()
        self._highlight()
        self._update_line_numbers()
        self.set_status(f"Ouvert : {Path(p).name}", 'ok')

    def save_file(self):
        if not self.cur_file: self.save_as()
        else: self._do_save(self.cur_file)

    def save_as(self):
        p = filedialog.asksaveasfilename(title="Enregistrer sous",
            defaultextension=".algo",
            filetypes=[("Algo", "*.algo"), ("Tous", "*.*")])
        if p: self._do_save(p)

    def _do_save(self, p):
        try:
            Path(p).write_text(self.editor.get('1.0', 'end-1c'), encoding='utf-8')
            self.cur_file  = p
            self._modified = False
            self._tabs[self._active_tab]['title'] = Path(p).name
            self._sync_tab_label()
            self.set_status(f"Enregistré : {Path(p).name}", 'ok')
        except Exception as ex:
            messagebox.showerror("Erreur", str(ex))

    def load_example(self, name):
        code = EXAMPLES.get(name, '')
        self.editor.delete('1.0', 'end')
        self.editor.insert('1.0', code)
        self.cur_file  = None
        self._modified = False
        short = name.split('—')[-1].strip() if '—' in name else name
        self._tabs[self._active_tab]['title'] = short[:30]
        self._sync_tab_label()
        self._highlight()
        self._update_line_numbers()
        self.clear_console()
        self.set_status(f"Exemple : {short}", 'ok')

    # ─────────────────────────────────────────────────────────────────
    #  EXAMPLE BROWSER  —  2-level: chapter list → example list
    # ─────────────────────────────────────────────────────────────────
    def show_example_browser(self):
        T   = self.T
        win = tk.Toplevel(self.root)
        win.title("Bibliotheque d exemples")
        win.geometry("1200x600")
        win.resizable(True, True)
        win.configure(bg=T['bg2'])

        # ── Header ──────────────────────────────────────────────────
        hdr = tk.Frame(win, bg=T['bg3'], height=36)
        hdr.pack(fill=tk.X, side=tk.TOP)
        hdr.pack_propagate(False)
        tk.Label(hdr,
            text="  Bibliotheque d exemples  —  chapitre -> exemple -> Ouvrir",
            bg=T['bg3'], fg=T['accent'],
            font=('Consolas', 9, 'bold')).pack(side=tk.LEFT, padx=10, pady=8)

        # ── Footer (must be packed BEFORE body so it stays at bottom) ──
        foot = tk.Frame(win, bg=T['bg3'], height=44)
        foot.pack(fill=tk.X, side=tk.BOTTOM)
        foot.pack_propagate(False)

        # ── Body row: 3 side-by-side panels ─────────────────────────
        body = tk.Frame(win, bg=T['bg2'])
        body.pack(fill=tk.BOTH, expand=True, side=tk.TOP, padx=6, pady=4)

        # ── Panel 1 : Chapters (fixed width) ────────────────────────
        ch_panel = tk.Frame(body, bg=T['bg3'], width=300)
        ch_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 4))
        ch_panel.pack_propagate(False)

        tk.Label(ch_panel, text="  Chapitres",
            bg=T['bg3'], fg=T['accent'],
            font=('Consolas', 9, 'bold'), pady=7,
            anchor='w').pack(fill=tk.X)
        tk.Frame(ch_panel, bg=T['border'], height=1).pack(fill=tk.X)

        ch_sb = tk.Scrollbar(ch_panel, orient=tk.VERTICAL,
            bg=T['bg3'], troughcolor=T['bg3'],
            relief='flat', width=6)
        ch_lb = tk.Listbox(ch_panel, bg=T['bg3'], fg=T['fg'],
            selectbackground=T['accent'], selectforeground='white',
            borderwidth=0, highlightthickness=0,
            font=('Consolas', 10), relief='flat',
            activestyle='none', yscrollcommand=ch_sb.set,
            exportselection=False)
        ch_sb.config(command=ch_lb.yview)
        ch_sb.pack(side=tk.RIGHT, fill=tk.Y)
        ch_lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # ── Panel 2 : Examples in chapter (fixed width) ──────────────
        ex_panel = tk.Frame(body, bg=T['bg3'], width=280)
        ex_panel.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 4))
        ex_panel.pack_propagate(False)

        ex_title = tk.Label(ex_panel, text="  Exemples",
            bg=T['bg3'], fg=T['accent'],
            font=('Consolas', 9, 'bold'), pady=7,
            anchor='w')
        ex_title.pack(fill=tk.X)
        tk.Frame(ex_panel, bg=T['border'], height=1).pack(fill=tk.X)

        ex_sb = tk.Scrollbar(ex_panel, orient=tk.VERTICAL,
            bg=T['bg3'], troughcolor=T['bg3'],
            relief='flat', width=6)
        ex_lb = tk.Listbox(ex_panel, bg=T['bg3'], fg=T['fg'],
            selectbackground=T['accent'], selectforeground='white',
            borderwidth=0, highlightthickness=0,
            font=('Consolas', 9), relief='flat',
            activestyle='none', yscrollcommand=ex_sb.set,
            exportselection=False)
        ex_sb.config(command=ex_lb.yview)
        ex_sb.pack(side=tk.RIGHT, fill=tk.Y)
        ex_lb.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # ── Panel 3 : Code preview (expands) ─────────────────────────
        prev_panel = tk.Frame(body, bg=T['editor_bg'])
        prev_panel.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        prev_hdr = tk.Frame(prev_panel, bg=T['bg3'], height=28)
        prev_hdr.pack(fill=tk.X)
        prev_hdr.pack_propagate(False)
        prev_title_lbl = tk.Label(prev_hdr, text="  Apercu du code",
            bg=T['bg3'], fg=T['fg2'],
            font=('Consolas', 8, 'bold'), anchor='w')
        prev_title_lbl.pack(side=tk.LEFT, padx=8, pady=5)

        tk.Frame(prev_panel, bg=T['border'], height=1).pack(fill=tk.X)

        pr_row = tk.Frame(prev_panel, bg=T['editor_bg'])
        pr_row.pack(fill=tk.BOTH, expand=True)

        pr_sb = tk.Scrollbar(pr_row, orient=tk.VERTICAL,
            bg=T['bg3'], troughcolor=T['editor_bg'],
            relief='flat', width=8)
        prev_text = tk.Text(pr_row, bg=T['editor_bg'],
            fg=T['editor_fg'],
            font=('Consolas', 10), borderwidth=0,
            highlightthickness=0, padx=10, pady=6,
            state='normal', relief='flat', wrap='none',
            yscrollcommand=pr_sb.set)
        pr_sb.config(command=prev_text.yview)
        pr_sb.pack(side=tk.RIGHT, fill=tk.Y)
        prev_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # ── Footer buttons ───────────────────────────────────────────
        # Use a mutable list to avoid closure capture bug
        selected = [None]   # selected[0] = full example key

        def do_open():
            if selected[0] and selected[0] in EXAMPLES:
                self.load_example(selected[0])
                win.destroy()

        open_btn = tk.Button(foot,
            text="   Ouvrir dans l editeur   ",
            command=do_open,
            bg=T['green'], fg='#0d0d1a', relief='flat', bd=0,
            padx=18, pady=8,
            font=('Consolas', 10, 'bold'), cursor='hand2')
        open_btn.pack(side=tk.RIGHT, padx=10, pady=6)

        tk.Button(foot, text="Fermer",
            command=win.destroy,
            bg=T['bg3'], fg=T['fg2'], relief='flat', bd=0,
            padx=14, pady=8,
            font=('Consolas', 9), cursor='hand2').pack(
                side=tk.RIGHT, padx=4, pady=6)

        status_lbl = tk.Label(foot, text="  Selectionnez un chapitre",
            bg=T['bg3'], fg=T['fg2'],
            font=('Consolas', 8), anchor='w')
        status_lbl.pack(side=tk.LEFT, padx=10)

        # ── Build chapter list ────────────────────────────────────────
        seen_ch = []
        for nm in EXAMPLES:
            ch = nm.split('—')[0].strip() if '—' in nm else nm
            if ch not in seen_ch:
                seen_ch.append(ch)
        for ch in seen_ch:
            ch_lb.insert('end', f'  {ch}')

        # ── Callbacks ────────────────────────────────────────────────
        def show_preview(code, title):
            prev_text.config(state='normal')
            prev_text.delete('1.0', 'end')
            prev_text.insert('1.0', code)
            prev_title_lbl.config(text=f'  {title}')
            prev_text.see('1.0')

        def on_chapter_select(e=None):
            sel = ch_lb.curselection()
            if not sel:
                return
            ch = ch_lb.get(sel[0]).strip()
            ex_title.config(text=f'  {ch}')
            ex_lb.delete(0, 'end')
            for nm in EXAMPLES:
                ch_nm = nm.split('—')[0].strip() if '—' in nm else nm
                if ch_nm == ch:
                    short = nm.split('—')[1].strip() if '—' in nm else nm
                    ex_lb.insert('end', f'  {short}')
            selected[0] = None
            show_preview('', f'{ch} — selectionnez un exemple')
            status_lbl.config(text=f'  {ch}  —  {ex_lb.size()} exemple(s)')
            if ex_lb.size() > 0:
                ex_lb.select_set(0)
                ex_lb.event_generate('<<ListboxSelect>>')

        def on_example_select(e=None):
            sel_ch = ch_lb.curselection()
            sel_ex = ex_lb.curselection()
            if not sel_ch or not sel_ex:
                return
            ch    = ch_lb.get(sel_ch[0]).strip()
            short = ex_lb.get(sel_ex[0]).strip()
            full  = None
            for nm in EXAMPLES:
                ch_nm = nm.split('—')[0].strip() if '—' in nm else nm
                sh_nm = nm.split('—')[1].strip() if '—' in nm else nm
                if ch_nm == ch and sh_nm == short:
                    full = nm
                    break
            if full is None:
                return
            selected[0] = full
            show_preview(EXAMPLES[full], short)
            status_lbl.config(
                text=f'  {full}  —  double-clic ou Ouvrir pour charger')
            open_btn.config(bg=T['green'])

        def on_dclick(e=None):
            on_example_select()
            do_open()

        ch_lb.bind('<<ListboxSelect>>', on_chapter_select)
        ex_lb.bind('<<ListboxSelect>>', on_example_select)
        ex_lb.bind('<Double-Button-1>', on_dclick)
        ex_lb.bind('<Return>',          on_dclick)

        # Auto-select first chapter
        if seen_ch:
            ch_lb.select_set(0)
            on_chapter_select()

    # ─────────────────────────────────────────────────────────────────
    #  EXECUTION
    # ─────────────────────────────────────────────────────────────────
    def run_code(self):
        if self.is_running:
            self.cprint("[Programme déjà en cours]\n", 'inf')
            return
        code = self.editor.get('1.0', 'end-1c')
        if not code.strip():
            self.cprint("L'éditeur est vide.\n", 'err')
            return
        self.clear_console()
        self.editor.tag_remove('err_', '1.0', 'end')
        self.is_running = True
        self._interp    = None          # sera assigné dans le thread
        self._t0        = time.time()
        self.set_status("⚙  Exécution en cours…", 'ok')
        self._hint_lbl.config(text="  ⚙  Exécution…", fg=self.T['fg2'])
        self.cprint("━" * 54 + "\n", 'sep')
        self.cprint(f"▶  {datetime.now().strftime('%H:%M:%S')}\n", 'inf')
        self.cprint("━" * 54 + "\n", 'sep')
        threading.Thread(target=self._run_thread,
                        args=(code,), daemon=True).start()

    def _run_thread(self, code):
        try:
            toks   = tokenize(code)
            prog   = Parser(toks).parse()
            interp = Interpreter(
                output_cb=lambda s: self.root.after(0, self.cprint, s + '\n', 'out'),
                input_cb=self._req_input)
            self._interp = interp           # ← Fix 3 : permet à stop_code de l'arrêter
            interp.run(prog)
            elapsed = time.time() - self._t0
            self.root.after(0, self._run_ok, elapsed, interp.steps)
        except LexerError as e:
            self.root.after(0, self._run_err,
                f"Erreur lexicale  ligne {e.line} col {e.col}: {e}", e.line)
        except ParseError as e:
            self.root.after(0, self._run_err,
                f"Erreur syntaxique  ligne {e.line} col {e.col}: {e}", e.line)
        except AlgoRTError as e:
            self.root.after(0, self._run_err,
                f"Erreur d'exécution: {e}" +
                (f"  (ligne {e.line})" if e.line else ""),
                e.line)
        except StopSig:
            self.root.after(0, self._run_stopped)
        except Exception as e:
            self.root.after(0, self._run_err, f"Erreur interne: {e}")
        finally:
            self.root.after(0, self._run_finally)

    def _run_ok(self, elapsed, steps):
        self.cprint("━" * 54 + "\n", 'sep')
        self.cprint(f"✔  Terminé en {elapsed:.4f}s  ({steps:,} instructions)\n", 'ok')
        self._time_lbl.config(text=f"{elapsed:.4f}s  {steps:,} instr.")
        self._hint_lbl.config(
            text=f"  ✔  Terminé en {elapsed:.4f}s  —  {steps:,} instructions",
            fg=self.T['green'])
        self.set_status(f"✔  OK  —  {elapsed:.4f}s", 'ok')

    def _run_err(self, msg, line=None):
        self.cprint("━" * 54 + "\n", 'sep')
        self.cprint(f"✘  {msg}\n", 'err')
        self._hint_lbl.config(text=f"  ✘  {msg[:60]}", fg=self.T['red'])
        self.set_status("✘  Erreur", 'err')
        if line:
            self.editor.tag_add('err_', f'{line}.0', f'{line}.end')
            self.editor.see(f'{line}.0')

    def _run_stopped(self):
        self.cprint("\n■  Arrêté par l'utilisateur.\n", 'inf')
        self._hint_lbl.config(text="  ■  Arrêté", fg=self.T['red'])
        self.set_status("■  Arrêté", 'inf')

    def _run_finally(self):
        self.is_running = False
        self._waiting   = False
        self.console.config(state='disabled', cursor='')
        self._input_ev.set()

    def stop_code(self):
        if self.is_running:
            self.is_running = False
            # Arrête l'interpréteur (stoppe les boucles infinies)
            if self._interp is not None:
                self._interp.stop()
                self._interp = None
            self._input_ev.set()

    # ─────────────────────────────────────────────────────────────────
    #  TERMINAL I/O
    # ─────────────────────────────────────────────────────────────────
    def _req_input(self):
        self._input_val = None
        self._input_ev.clear()
        self.root.after(0, self._start_input_mode)
        self._input_ev.wait()
        if not self.is_running:
            raise StopSig()
        return self._input_val or ''

    def _start_input_mode(self):
        self._waiting = True
        self.console.config(state='normal', cursor='xterm')
        self._inp_start = self.console.index('end-1c')
        self.console.see('end')
        self.console.focus_set()
        self._hint_lbl.config(
            text="  ✏  Tapez votre réponse et appuyez sur  Entrée  ↵",
            fg=self.T['yellow'])
        self._flash_hint()

    def _flash_hint(self, n=6):
        if not self._waiting:
            return
        colors = [self.T['yellow'], self.T['fg2']]
        self._hint_lbl.config(fg=colors[n % 2])
        if n > 0:
            self.root.after(380, self._flash_hint, n - 1)

    def _term_key(self, event):
        if not self._waiting:
            return 'break'
        if event.keysym in ('Return', 'BackSpace', 'Delete',
                            'Left', 'Right', 'Up', 'Down', 'Home', 'End'):
            return
        if event.char and event.char.isprintable():
            self.console.config(state='normal')
            self.console.insert('end', event.char, 'userin')
            self.console.see('end')
        return 'break'

    def _term_enter(self, event):
        if not self._waiting:
            return 'break'
        start = self._inp_start
        end   = self.console.index('end-1c')
        try:
            typed = self.console.get(start, end).strip()
        except Exception:
            typed = ''
        self.console.config(state='normal')
        self.console.insert('end', '\n')
        self.console.see('end')
        self._waiting   = False
        self._input_val = typed
        self.console.config(state='disabled', cursor='')
        self._hint_lbl.config(
            text="  ⚙  Exécution en cours…",
            fg=self.T['green'])
        self._input_ev.set()
        return 'break'

    def _term_bs(self, event):
        if not self._waiting:
            return 'break'
        cur = self.console.index('insert')
        if self.console.compare(cur, '>', self._inp_start):
            self.console.config(state='normal')
            self.console.delete('insert-1c', 'insert')
        return 'break'

    # ─────────────────────────────────────────────────────────────────
    #  CONSOLE
    # ─────────────────────────────────────────────────────────────────
    def cprint(self, text, tag='out'):
        self.console.config(state='normal')
        self.console.insert('end', text, tag)
        self.console.see('end')
        if not self._waiting:
            self.console.config(state='disabled')

    def clear_console(self):
        self.console.config(state='normal')
        self.console.delete('1.0', 'end')
        if not self._waiting:
            self.console.config(state='disabled')
        self._time_lbl.config(text="")
        self._hint_lbl.config(
            text="  ●  Prêt  —  F5 pour exécuter",
            fg=self.T['fg2'])

    # ─────────────────────────────────────────────────────────────────
    #  STATUS
    # ─────────────────────────────────────────────────────────────────
    def set_status(self, msg, kind='ok'):
        colors = {'ok': self.T['green'], 'err': self.T['red'],
                'inf': self.T['fg2']}
        self._status.config(text=f"  {msg}",
                            fg=colors.get(kind, self.T['fg']))

    # ─────────────────────────────────────────────────────────────────
    #  AUTOCOMPLETE
    # ─────────────────────────────────────────────────────────────────
    _AC_DB = [
        # ╔══════════════════════════════╗
        # ║   STRUCTURE PRINCIPALE       ║
        # ╚══════════════════════════════╝
        ("algorithme", "Algorithme <Nom>;  ...  Fin.",
        "Algorithme <Nom>;\nVar\n    \nDebut\n    \nFin.",
        "Structure de base d un algorithme"),
        ("algorithme", "Algorithme avec Const + Type + Var",
        "Algorithme <Nom>;\nConst\n    N = 100;\nType <NomType> = Enregistrement\n    champ : <Type>;\nFin;\nVar\n    \nDebut\n    \nFin.",
        "Structure complète (Const, Type, Var)"),

        # ╔══════════════════════════════╗
        # ║   DÉCLARATIONS               ║
        # ╚══════════════════════════════╝
        ("var",        "Var <nom> : <Type>;",
        "Var\n    nom : Entier;",
        "Déclaration de variable"),
        ("const",      "Const <Nom> = <Valeur>;",
        "Const\n    N = 100;",
        "Déclaration de constante"),
        ("type",       "Type <Nom> = Enregistrement ... Fin;",
        "Type <NomType> = Enregistrement\n    champ1 : Entier;\n    champ2 : Chaine;\nFin;",
        "Déclaration d un enregistrement (struct)"),

        # ╔══════════════════════════════╗
        # ║   TYPES                      ║
        # ╚══════════════════════════════╝
        ("entier",    "Entier",          "Entier",    "Type entier (ex: 5, -3)"),
        ("reel",      "Reel",            "Reel",      "Type réel (ex: 3.14)"),
        ("booleen",   "Booleen",         "Booleen",   "Type booléen (Vrai / Faux)"),
        ("chaine",    "Chaine",          "Chaine",    "Type chaîne de caractères"),
        ("caractere", "Caractere",       "Caractere", "Type caractère unique"),
        ("fichier",   "Fichier",         "Fichier",   "Type fichier"),

        # ╔══════════════════════════════╗
        # ║   TABLEAUX                   ║
        # ╚══════════════════════════════╝
        ("tableau",   "T[N] : Tableau De Entier;",
        "T[100] : Tableau De Entier;",
        "Tableau 1D d entiers"),
        ("tableau",   "T[N] : Tableau De Reel;",
        "T[100] : Tableau De Reel;",
        "Tableau 1D de réels"),
        ("tableau",   "T[N] : Tableau De Chaine;",
        "T[100] : Tableau De Chaine;",
        "Tableau 1D de chaînes"),
        ("tableau",   "T[N] : Tableau De Booleen;",
        "T[100] : Tableau De Booleen;",
        "Tableau 1D de booléens"),
        ("tableau",   "T[N] : Tableau De Caractere;",
        "T[50] : Tableau De Caractere;",
        "Tableau de caractères (chaîne modifiable)"),
        ("tableau",   "M[N][M] : Tableau De Reel;  (2D)",
        "M[10][10] : Tableau De Reel;",
        "Matrice 2D"),
        ("tableau",   "T[N] : Tableau De <TypeEnreg>;",
        "T[50] : Tableau De <TypeEnreg>;",
        "Tableau d enregistrements"),

        # ╔══════════════════════════════╗
        # ║   POINTEURS                  ║
        # ╚══════════════════════════════╝
        ("pointeur",  "p : Pointeur Vers <Type>;",
        "p : Pointeur Vers <Type>;",
        "Déclaration pointeur (syntaxe classique)"),
        ("^",         "p : ^<Type>;  — pointeur",
        "p : ^<Type>;",
        "Déclaration pointeur  ex: p : ^Entier    p : ^MaStruct"),
        ("nouveau",   "Nouveau(p);",
        "Nouveau(p);",
        "Allouer un enregistrement en mémoire"),
        ("liberer",   "Liberer(p);",
        "Liberer(p);",
        "Libérer la mémoire  (p ← NIL)"),
        ("allouer",   "T <- allouer(n * taille(Type))",
         "allouer( * taille())",
        "Allocation dynamique de n éléments"),
        ("allouer",   "Allouer(p, n)  — forme statement",
        "Allouer(, );",
        "Allouer p ← liste de n cases"),
        ("taille",    "taille(x)  — taille en octets",
        "taille()",
        "Entier=4  Reel=8  Booleen=1  Caractere=1"),
        ("nil",       "NIL",
        "NIL",
        "Valeur nulle d un pointeur"),

        # ╔══════════════════════════════╗
        # ║   CONDITIONS                 ║
        # ╚══════════════════════════════╝
        ("si",        "Si ... Alors ... FinSi",
        "Si  Alors\n    \nFinSi;",
        "Condition simple"),
        ("si",        "Si ... Alors ... Sinon ... FinSi",
        "Si  Alors\n    \nSinon\n    \nFinSi;",
        "Condition avec branche Sinon"),
        ("si",        "Si imbriqués",
        "Si  Alors\n    \nSinon\n    Si  Alors\n        \n    Sinon\n        \n    FinSi;\nFinSi;",
        "Conditions imbriquées"),
        ("sinon",     "Sinon",
        "Sinon\n    ",
        "Branche alternative d un Si"),
        ("finsi",     "FinSi;",
        "FinSi;",
        "Fermeture de Si"),
        ("fsi",       "Fsi;  (alias FinSi)",
        "Fsi;",
        "Alias officiel de FinSi"),

        # ╔══════════════════════════════╗
        # ║   SELON / CAS                ║
        # ╚══════════════════════════════╝
        ("selon",     "Selon ... Faire ... FinSelon",
        "Selon  Faire\n    Cas :\n        \n    Cas :\n        \n    Autrement:\n        \nFinSelon;",
        "Switch — tester plusieurs valeurs"),
        ("cas",       "Cas <val>: ...",
        "Cas :\n    ",
        "Un cas dans un Selon"),
        ("autrement", "Autrement: ...",
        "Autrement:\n    ",
        "Cas par défaut dans un Selon"),
        ("finselon",  "FinSelon;",
        "FinSelon;",
        "Fermeture de Selon"),

        # ╔══════════════════════════════╗
        # ║   BOUCLES                    ║
        # ╚══════════════════════════════╝
        ("pour",      "Pour i <- 1 a n Faire ... FinPour",
        "Pour i <- 1 a n Faire\n    \nFinPour;",
        "Boucle Pour croissante"),
        ("pour",      "Pour i <- n a 1 Pas -1  (décroissant)",
        "Pour i <- n a 1 Pas -1 Faire\n    \nFinPour;",
        "Boucle Pour décroissante"),
        ("pour",      "Pour i <- 0 a n-1  (indices 0-based)",
        "Pour i <- 0 a n-1 Faire\n    \nFinPour;",
        "Boucle Pour indices zéro-based"),
        ("tantque",   "TantQue <cond> Faire ... FinTantQue",
        "TantQue  Faire\n    \nFinTantQue;",
        "Boucle TantQue (test AVANT)"),
        ("tant",      "Tant Que <cond> Faire ... FinTantQue",
        "Tant Que  Faire\n    \nFinTantQue;",
        "Boucle Tant Que (deux mots)"),
        ("repeter",   "Repeter ... JusquA <cond>",
        "Repeter\n    \nJusquA ;",
        "Boucle Repeter (exécutée au moins 1 fois)"),
        ("arreter",   "Arreter;",
        "Arreter;",
        "Quitter la boucle immédiatement (break)"),
        ("continuer", "Continuer;",
        "Continuer;",
        "Passer à l itération suivante (continue)"),
        ("finpour",   "FinPour;",
        "FinPour;",
        "Fermeture de Pour"),
        ("fintantque","FinTantQue;",
        "FinTantQue;",
        "Fermeture de TantQue"),
        ("jusqua",    "JusquA <condition>;",
        "JusquA ;",
        "Condition de fin de Repeter"),

        # ╔══════════════════════════════╗
        # ║   FONCTIONS & PROCÉDURES     ║
        # ╚══════════════════════════════╝
        ("fonction",  "Fonction <Nom>(<params>) : <TypeRetour>;",
        "Fonction <Nom>(<param> : <Type>) : <TypeRetour>;\nVar\n    \nDebut\n    Retourner();\nFin;",
        "Déclaration d une fonction (avant Algorithme)"),
        ("procedure", "Procedure <Nom>(<params>);",
        "Procedure <Nom>(<param> : <Type>);\nVar\n    \nDebut\n    \nFin;",
        "Déclaration d une procédure"),
        ("procedure", "Procedure avec Tableau en paramètre",
        "Procedure <Nom>(T : Tableau De Entier; n : Entier);\nVar\n    \nDebut\n    \nFin;",
        "Procédure qui reçoit un tableau"),
        ("retourner", "Retourner(<valeur>);",
        "Retourner();",
        "Retourner une valeur depuis une fonction"),

        # ╔══════════════════════════════╗
        # ║   ENTRÉE / SORTIE            ║
        # ╚══════════════════════════════╝
        ("ecrire",    "Ecrire(expr1, expr2, ...);",
        "Ecrire();",
        "Afficher des valeurs sur la console"),
        ("lire",      "Lire(var1, var2, ...);",
        "Lire();",
        "Lire des valeurs depuis l entrée"),

        # ╔══════════════════════════════╗
        # ║   VALEURS LITTÉRALES         ║
        # ╚══════════════════════════════╝
        ("vrai",      "Vrai",  "Vrai",  "Valeur booléenne vraie"),
        ("faux",      "Faux",  "Faux",  "Valeur booléenne fausse"),
        ("nil",       "NIL",   "NIL",   "Pointeur nul"),

        # ╔══════════════════════════════╗
        # ║   OPÉRATEURS                 ║
        # ╚══════════════════════════════╝
        ("div",       "Div  (division entière)",
        "Div",
        "Division entière — ex: 17 Div 5 = 3"),
        ("mod",       "Mod  (modulo / reste)",
        "Mod",
        "Reste de division — ex: 17 Mod 5 = 2"),
        ("et",        "Et  (ET logique)",
        "Et",
        "ET logique — ex: (a>0) Et (b>0)"),
        ("ou",        "Ou  (OU logique)",
        "Ou",
        "OU logique — ex: (a=0) Ou (b=0)"),
        ("non",       "Non  (NON logique)",
        "Non",
        "NON logique — ex: Non (a = b)"),

        # ╔══════════════════════════════╗
        # ║   FICHIERS                   ║
        # ╚══════════════════════════════╝
        ("ouvrir",    "Ouvrir(f, chemin, mode)",
        "Ouvrir(f, chemin, lecture);",
        "Ouvrir un fichier (lecture / ecriture / mise a jour)"),
        ("fermer",    "Fermer(f);",
        "Fermer(f);",
        "Fermer un fichier (obligatoire)"),
        ("finfichier","Non FinFichier(f)",
        "Non FinFichier()",
        "Vrai tant que la fin du fichier n est pas atteinte"),
        ("lire",      "Lire(f, variable);  — depuis fichier",
        "Lire(, );",
        "Lire depuis un fichier ouvert"),
        ("ecrire",    "Ecrire(f, variable);  — vers fichier",
        "Ecrire(, );",
        "Écrire dans un fichier ouvert"),

        # ╔══════════════════════════════╗
        # ║   PILES (Ch9)                ║
        # ╚══════════════════════════════╝
        ("empiler",   "Empiler(P, element);",
        "Empiler(, );",
        "Pile LIFO — ajouter au sommet"),
        ("depiler",   "Depiler(P, &element);",
        "Depiler(, );",
        "Pile LIFO — retirer du sommet"),
        ("sommet",    "Sommet(P)",
        "Sommet()",
        "Consulter le sommet sans le supprimer"),
        ("pilevide",  "PileVide(P)",
        "PileVide()",
        "Vrai si la pile est vide"),

        # ╔══════════════════════════════╗
        # ║   FILES (Ch10)               ║
        # ╚══════════════════════════════╝
        ("enfiler",   "Enfiler(F, element);",
        "Enfiler(, );",
        "File FIFO — ajouter en queue"),
        ("defiler",   "Defiler(F, &element);",
        "Defiler(, );",
        "File FIFO — retirer de la tête"),
        ("tete",      "Tete(F)",
        "Tete()",
        "Consulter la tête sans la supprimer"),
        ("filevide",  "FileVide(F)",
        "FileVide()",
        "Vrai si la file est vide"),

        # ╔══════════════════════════════╗
        # ║   FONCTIONS MATHÉMATIQUES    ║
        # ╚══════════════════════════════╝
        ("abs",       "abs(x)",       "abs()",      "Valeur absolue"),
        ("sqrt",      "sqrt(x)",      "sqrt()",     "Racine carrée"),
        ("pow",       "pow(x, n)",    "pow(, )",    "Puissance xⁿ"),
        ("arrondi",   "arrondi(x, n)","arrondi(, )","Arrondi à n décimales"),
        ("max",       "max(a, b)",    "max(, )",    "Maximum de deux valeurs"),
        ("min",       "min(a, b)",    "min(, )",    "Minimum de deux valeurs"),
        ("sin",       "sin(x)",       "sin()",      "Sinus (radians)"),
        ("cos",       "cos(x)",       "cos()",      "Cosinus (radians)"),
        ("tan",       "tan(x)",       "tan()",      "Tangente (radians)"),
        ("log",       "log(x)",       "log()",      "Logarithme naturel"),
        ("log2",      "log2(x)",      "log2()",     "Logarithme base 2"),
        ("log10",     "log10(x)",     "log10()",    "Logarithme base 10"),
        ("pi",        "pi  (3.14159…)","pi",        "Constante π"),

        # ╔══════════════════════════════╗
        # ║   CONVERSION DE TYPES        ║
        # ╚══════════════════════════════╝
        ("entier",    "entier(x)  — convertir en Entier",
        "entier()",
        "Convertir une valeur en entier  ex: entier(3.7)=3"),
        ("reel",      "reel(x)  — convertir en Reel",
        "reel()",
        "Convertir en réel  ex: reel(5)=5.0"),
        ("chaine",    "chaine(x)  — convertir en Chaine",
        "chaine()",
        "Convertir en chaîne"),
        ("ord",       "ord(c)  — code ASCII",
        "ord()",
        "Code ASCII d un caractère  ex: ord(A)=65"),
        ("chr",       "chr(n)  — caractère ASCII",
        "chr()",
        "Caractère depuis code ASCII  ex: chr(65)=A"),

        # ╔══════════════════════════════╗
        # ║   CHAÎNES DE CARACTÈRES      ║
        # ╚══════════════════════════════╝
        ("longueur",     "longueur(ch)",
        "longueur()",
        "Longueur d une chaîne"),
        ("concat",       "concat(ch1, ch2)",
        "concat(, )",
        "Concaténer deux chaînes"),
        ("sous_chaine",  "sous_chaine(ch, debut, fin)",
        "sous_chaine(, , )",
        "Extraire une sous-chaîne (indices 0-based)"),
        ("trouve",       "trouve(ch, motif)",
        "trouve(, )",
        "Chercher un motif  (-1 si absent)"),
        ("remplace",     "remplace(ch, ancien, nouveau)",
        "remplace(, , )",
        "Remplacer toutes les occurrences"),
        ("majuscule",    "majuscule(ch)",
        "majuscule()",
        "Convertir en MAJUSCULES"),
        ("minuscule",    "minuscule(ch)",
        "minuscule()",
        "Convertir en minuscules"),
        ("trim",         "trim(ch)",
        "trim()",
        "Supprimer espaces début/fin"),
        ("chaine_vers_tableau", "chaine_vers_tableau(s)",
        "chaine_vers_tableau()",
        "Chaine → Tableau De Caractere"),
        ("tableau_vers_chaine", "tableau_vers_chaine(tab)",
        "tableau_vers_chaine()",
        "Tableau De Caractere → Chaine"),

        # ╔══════════════════════════════╗
        # ║   ALÉATOIRE                  ║
        # ╚══════════════════════════════╝
        ("aleatoire",        "aleatoire()  — Reel 0..1",
        "aleatoire()",
        "Nombre aléatoire réel entre 0 et 1"),
        ("aleatoire_entier", "aleatoire_entier(a, b)",
        "aleatoire_entier(, )",
        "Entier aléatoire entre a et b inclus"),

        # ╔══════════════════════════════╗
        # ║   COMMENTAIRES               ║
        # ╚══════════════════════════════╝
        ("//",  "// commentaire ligne",
        "// ",
        "Commentaire sur une ligne"),
        ("/*",  "/* commentaire bloc */",
        "/* \n*/",
        "Commentaire sur plusieurs lignes"),

        # ╔══════════════════════════════════════════════╗
        # ║   PILES  (Chapitre 9)                        ║
        # ╚══════════════════════════════════════════════╝
        ("pile",         "Type Pile = Enregistrement",
        "type Pile = Enregistrement\ndebut\n    info : entier;\n    suivant : ^Pile;\nfin;",
        "Declaration du type noeud pour une pile"),

        ("initialiser",  "InitialiserPile(E/S/ tete : ↑Pile)",
        "Procedure InitialiserPile(E/S/ tete : ^Pile)\ndebut\n    tete := NIL;\nfin;",
        "Initialiser une pile a vide"),

        ("pilevide",     "PileVide(E/ tete : ↑Pile) : Booleen",
        "Fonction PileVide(E/ tete : ^Pile) : booleen\ndebut\n    si(tete=NIL) alors\n        retourner vrai;\n    sinon\n        retourner faux;\n    finsi;\nfin;",
        "Tester si une pile est vide"),

        ("empiler",      "Empiler(E/S/ tete, E/ val) — ajouter au sommet",
        "Procedure Empiler(E/S/ tete : ^Pile; E/ val : entier)\nvar p : ^Pile;\ndebut\n    p := allouer(taille(Pile));\n    p->info := val;\n    p->suivant := tete;\n    tete := p;\nfin;",
        "Empiler un element — ajouter au sommet de la pile"),

        ("depiler",      "Depiler(E/S/ tete, E/S/ var) — retirer du sommet",
        "Procedure Depiler(E/S/ tete : ^Pile; E/S/ val : entier)\nvar p : ^Pile;\ndebut\n    val := tete->info;\n    p := tete;\n    tete := tete->suivant;\n    liberer(p);\nfin;",
        "Depiler un element — retirer du sommet"),

        ("sommet",       "SommetPile(E/ tete) — consulter sans supprimer",
        "Fonction SommetPile(E/ tete : ^Pile) : entier\ndebut\n    retourner (tete->info);\nfin;",
        "Consulter le sommet de la pile sans le retirer"),

        # ╔══════════════════════════════════════════════╗
        # ║   FILES  (Chapitre 10)                       ║
        # ╚══════════════════════════════════════════════╝
        ("file",         "Type ElementFile + File",
        "type ElementFile = Enregistrement\ndebut\n    info : entier;\n    suivant : ^ElementFile;\nfin;\ntype File = Enregistrement\ndebut\n    tete : ^ElementFile;\n    queue : ^ElementFile;\nfin;",
        "Declaration des types pour une file (FIFO)"),

        ("initialiser",  "InitialiserFile(E/S/ F : File)",
        "Procedure InitialiserFile(E/S/ F : File)\ndebut\n    F.tete := NIL;\n    F.queue := NIL;\nfin;",
        "Initialiser une file a vide"),

        ("filevide",     "FileVide(E/ F : File) : Booleen",
        "Fonction FileVide(E/ F : File) : booleen\ndebut\n    si(F.tete=NIL) alors\n        retourner vrai;\n    sinon\n        retourner faux;\n    finsi;\nfin;",
        "Tester si une file est vide"),

        ("enfiler",      "Enfiler(E/S/ F, E/ val) — ajouter en queue",
        "Procedure Enfiler(E/S/ F : File; E/ val : entier)\nvar p : ^ElementFile;\ndebut\n    p := allouer(taille(ElementFile));\n    p->info := val;\n    p->suivant := NIL;\n    si(F.tete=NIL) alors\n        F.tete := p;\n    sinon\n        F.queue->suivant := p;\n    finsi;\n    F.queue := p;\nfin;",
        "Enfiler un element — ajouter en queue"),

        ("defiler",      "Defiler(E/S/ F, E/S/ var) — retirer de la tete",
        "Procedure Defiler(E/S/ F : File; E/S/ val : entier)\nvar p : ^ElementFile;\ndebut\n    val := F.tete->info;\n    p := F.tete;\n    si(F.tete=F.queue) alors\n        F.tete := NIL; F.queue := NIL;\n    sinon\n        F.tete := F.tete->suivant;\n    finsi;\n    liberer(p);\nfin;",
        "Defiler un element — retirer de la tete"),

        ("tete",         "TeteFile(E/ F) — consulter sans supprimer",
        "Fonction TeteFile(E/ F : File) : entier\ndebut\n    retourner (F.tete->info);\nfin;",
        "Consulter la tete de la file sans la retirer"),

        # ╔══════════════════════════════════════════════╗
        # ║   LISTES CHAINEES  (Chapitre 8)              ║
        # ╚══════════════════════════════════════════════╝
        ("liste",        "Type element (liste chainee)",
        "type element = Enregistrement\ndebut\n    info : entier;\n    suivant : ^element;\nfin;",
        "Declaration du type noeud pour une liste chainee"),

        ("allouer",      "allouer(taille(element)) — creer noeud",
        "p := allouer(taille(element));",
        "Allouer un nouveau noeud dans la liste"),

        ("liste",        "Creation liste FIFO",
        "tete := allouer(taille(element));\nlire(tete->info);\ntete->suivant := NIL;\np := tete;\npour i := 1 a N-1 faire\n    p->suivant := allouer(taille(element));\n    p := p->suivant;\n    lire(p->info);\nfin;\np->suivant := NIL;",
        "Creer une liste simplement chainee (methode FIFO)"),

        ("liste",        "Parcours liste chainee",
        "p := tete;\ntant que (p <> NIL) faire\n    ecrire(p->info);\n    p := p->suivant;\nfin;",
        "Parcourir et afficher une liste chainee"),

        # ╔══════════════════════════════════════════════╗
        # ║   FICHIER: ACCES DIRECT  (Chapitre 7)        ║
        # ╚══════════════════════════════════════════════╝
        ("pointer",      "pointer(f, i*taille(T)) — acces direct",
         "pointer(f, i * taille(element));",
        "Deplacer la tete de L/E sur l element i (acces direct)"),

        ("fin",          "fin(f) — tester fin de fichier",
        "tant que (fin(f) = faux) faire\n    lire(f, );\n    traiter;\nfin;",
        "Tester la fin d un fichier (synonyme de finfichier)"),

        ("fichier",      "Parcours complet fichier (lecture 1er + boucle)",
        "lire(f, val);\ntant que (fin(f) = faux) faire\n    ecrire(val);\n    lire(f, val);\nfin;",
        "Parcours correct: lire 1er element puis boucler (cours p24)"),

        ("fichier",      "Mode mettre a jour (ajout en fin)",
        'f := ouvrir("", "mettre a jour");',
        "Ouvrir en mise a jour: ajoute a la fin, cree si inexistant"),

    ]


    def _get_prefix(self):
        line = self.editor.get('insert linestart', 'insert')
        m    = re.search(r'[A-Za-zÀ-ÿ_/][A-Za-zÀ-ÿ0-9_]*$', line)
        return m.group() if m else ''

    def _get_user_vars(self):
        """Extrait les noms de variables déclarés dans l'éditeur."""
        try:
            code = self.editor.get('1.0', 'end-1c')
            toks = tokenize(code)
            prog = Parser(toks).parse()
            names = []
            # Variables globales
            for d in prog.vars:
                for n in d.names:
                    names.append((n, d.type))
            # Variables des fonctions
            for f in prog.funcs:
                for d in f.vars:
                    for n in d.names:
                        names.append((n, d.type))
                for pn, pt in f.params:
                    names.append((pn, pt))
            return names
        except Exception:
            return []

    def _type_label(self, t):
        if isinstance(t, str): return t.capitalize()
        if isinstance(t, tuple):
            if t[0] == 'tableau':
                return f"Tableau De {self._type_label(t[2])}"
            if t[0] == 'pointeur':
                return f"*{self._type_label(t[1])}"
        return str(t)

    def _ac_matches(self, prefix):
        pl   = prefix.lower()
        seen = set()
        out  = []
        # ── 1. Variables utilisateur (priorité haute) ─────────────────
        for vname, vtype in self._get_user_vars():
            if vname.lower().startswith(pl) and vname not in seen:
                seen.add(vname)
                tlabel = self._type_label(vtype)
                out.append((vname.lower(), f'{vname}  [{tlabel}]',
                            vname, f'Variable déclarée — {tlabel}'))
        # ── 2. Mots-clés et fonctions built-in ───────────────────────
        for kw, label, snippet, desc in self._AC_DB:
            if kw.startswith(pl) or label.lower().startswith(pl):
                if label not in seen:
                    seen.add(label)
                    out.append((kw, label, snippet, desc))
        return out

    def _trigger_autocomplete(self, event=None):
        prefix = self._get_prefix()
        items  = self._ac_matches(prefix) if prefix else list(self._AC_DB)
        self._close_autocomplete()
        if not items:
            return 'break'
        if len(items) == 1:
            self._do_insert(items[0][2], len(prefix))
            return 'break'
        self._show_ac(items, prefix)
        return 'break'

    def _show_ac(self, items, prefix):
        self._close_autocomplete()
        T = self.T
        try:
            bbox = self.editor.bbox('insert')
            if not bbox:
                return
            rx = self.editor.winfo_rootx() + bbox[0]
            ry = self.editor.winfo_rooty() + bbox[1] + bbox[3] + 2
        except Exception:
            return

        win = tk.Toplevel(self.root)
        win.wm_overrideredirect(True)
        win.configure(bg=T['border'])
        self._ac_win        = win
        self._ac_items      = items
        self._ac_prefix_len = len(prefix)

        main = tk.Frame(win, bg=T['bg3'])
        main.pack(padx=1, pady=1)

        n_show = min(12, len(items))
        lb = tk.Listbox(main, bg=T['bg3'], fg=T['fg'],
            selectbackground=T['accent'], selectforeground='white',
            borderwidth=0, highlightthickness=0,
            font=('Consolas', 10, 'bold'), height=n_show, width=28,
            relief='flat', activestyle='none', exportselection=False,
            takefocus=False)       # ← لا تسرق الـ focus أبداً
        lb.grid(row=0, column=0, sticky='ns', padx=(4, 0), pady=4)
        self._ac_lb = lb

        tk.Frame(main, bg=T['border'], width=1).grid(
            row=0, column=1, sticky='ns', padx=4, pady=4)

        rp = tk.Frame(main, bg=T['bg2'], width=260)
        rp.grid(row=0, column=2, sticky='nsew', padx=(0, 4), pady=4)
        rp.pack_propagate(False)

        lbl_name = tk.Label(rp, text="", bg=T['bg2'], fg=T['accent'],
            font=('Consolas', 10, 'bold'), anchor='w', padx=8, pady=4)
        lbl_name.pack(fill=tk.X)
        lbl_desc = tk.Label(rp, text="", bg=T['bg2'], fg=T['fg2'],
            font=('Consolas', 8), anchor='w', padx=8, wraplength=240, justify='left')
        lbl_desc.pack(fill=tk.X)
        tk.Frame(rp, bg=T['border'], height=1).pack(fill=tk.X, padx=8, pady=2)
        lbl_snip = tk.Text(rp, bg=T['editor_bg'], fg=T['string'],
            font=('Consolas', 9), borderwidth=0, highlightthickness=0,
            state='disabled', height=6, width=30, padx=6, pady=4,
            relief='flat', wrap='none')
        lbl_snip.pack(fill=tk.BOTH, expand=True, padx=4, pady=(0, 4))
        tk.Label(rp, text="↑↓ Naviguer   ↵ / Tab → Insérer   Échap → Fermer",
            bg=T['bg3'], fg=T['fg2'],
            font=('Consolas', 7), anchor='center', pady=3).pack(fill=tk.X)

        for _, label, _, _ in items:
            lb.insert('end', f'  {label}')
        lb.select_set(0)

        def upd(idx=0):
            try:
                lb.select_clear(0, 'end')
                lb.select_set(idx)
                lb.see(idx)
                _, label, snippet, desc = items[idx]
                lbl_name.config(text=f"  {label}")
                lbl_desc.config(text=desc)
                lbl_snip.config(state='normal')
                lbl_snip.delete('1.0', 'end')
                lbl_snip.insert('1.0', snippet)
                lbl_snip.config(state='disabled')
            except Exception:
                pass

        def current_idx():
            sel = lb.curselection()
            return sel[0] if sel else 0

        def pick(e=None):
            if not self._ac_win:
                return 'break'
            idx = current_idx()
            self._do_insert(items[idx][2], self._ac_prefix_len)
            self._close_autocomplete()
            return 'break'

        def nav_up(e=None):
            if not self._ac_win:
                return
            idx = max(0, current_idx() - 1)
            upd(idx)
            return 'break'

        def nav_down(e=None):
            if not self._ac_win:
                return
            idx = min(len(items) - 1, current_idx() + 1)
            upd(idx)
            return 'break'

        def close_ac(e=None):
            self._close_autocomplete()
            return 'break'

        # ── كل التحكم يتم من الأديتور مباشرة (بدون سرقة الـ focus) ──
        # ملاحظة: Tab و Return تُعالَجان مباشرة في _on_tab / _on_enter
        self._ac_editor_binds = []
        def bind_ed(seq, fn):
            self.editor.bind(seq, fn, add=True)
            self._ac_editor_binds.append(seq)

        bind_ed('<Up>',     nav_up)
        bind_ed('<Down>',   nav_down)
        bind_ed('<Escape>', close_ac)

        # النقر بالماوس على الـ listbox
        lb.bind('<<ListboxSelect>>', lambda e: upd(current_idx()))
        lb.bind('<Double-Button-1>', pick)
        lb.bind('<Button-1>',        lambda e: lb.after(10, lambda: pick()))

        win.update_idletasks()
        wh = win.winfo_reqheight()
        sh = self.root.winfo_screenheight()
        if ry + wh > sh - 40:
            ry = (self.editor.winfo_rooty() +
                (bbox[1] if bbox else 0) - wh - 2)
        win.wm_geometry(f"+{rx}+{ry}")
        # ← الأديتور يبقى معه الـ focus دائماً
        self.editor.focus_set()
        upd(0)

    def _chk_ac(self):
        if self._ac_win:
            try:
                fw = self.root.focus_get()
                if fw and str(fw).startswith(str(self._ac_win)):
                    return
            except Exception:
                pass
            self._close_autocomplete()

    def _do_insert(self, snippet, prefix_len):
        if prefix_len > 0:
            self.editor.delete(f'insert-{prefix_len}c', 'insert')
        self.editor.insert('insert', snippet)
        self._ed_changed()

    def _close_autocomplete(self, e=None):
        if self._ac_win:
            try:
                self._ac_win.destroy()
            except Exception:
                pass
            self._ac_win = None
        # إزالة الـ bindings المؤقتة من الأديتور
        for seq in getattr(self, '_ac_editor_binds', []):
            try:
                self.editor.unbind(seq)
            except Exception:
                pass
        self._ac_editor_binds = []

    # ─────────────────────────────────────────────────────────────────
    #  FIND / REPLACE
    # ─────────────────────────────────────────────────────────────────
    def show_find(self):
        if self._find_win and self._find_win.winfo_exists():
            self._find_win.lift()
            self._find_win.focus_set()
            return
        T   = self.T
        win = tk.Toplevel(self.root)
        self._find_win = win
        win.title("Chercher / Remplacer")
        win.geometry("520x200")
        win.configure(bg=T['bg2'])
        win.resizable(False, False)
        # Toujours au-dessus
        win.attributes('-topmost', True)

        # ── Tag pour surligner toutes les occurrences ─────────────────
        self.editor.tag_config('find_all',
            background=T['yellow'], foreground='#000000')
        self.editor.tag_config('find_cur',
            background=T['accent'], foreground='#ffffff')

        def row(lbl, r):
            tk.Label(win, text=lbl, bg=T['bg2'], fg=T['fg'],
                font=('Consolas', 10), width=12, anchor='e').grid(
                row=r, column=0, padx=8, pady=5)
            e = tk.Entry(win, bg=T['editor_bg'], fg=T['editor_fg'],
                insertbackground=T['fg'], borderwidth=0,
                highlightthickness=1, highlightcolor=T['accent'],
                font=('Consolas', 10), relief='flat')
            e.grid(row=r, column=1, columnspan=3, sticky='ew', padx=4, pady=5)
            return e

        win.columnconfigure(1, weight=1)
        f_e = row("Chercher :", 0)
        r_e = row("Remplacer :", 1)

        # Compteur  "N / total"
        cnt_lbl = tk.Label(win, text="", bg=T['bg2'], fg=T['fg2'],
            font=('Consolas', 9))
        cnt_lbl.grid(row=0, column=4, padx=8)

        # ── État interne de navigation ────────────────────────────────
        _matches   = []   # liste d'indices tk  "L.C"
        _cur_idx   = [-1] # index courant dans _matches

        def _clear_tags():
            self.editor.tag_remove('find_all', '1.0', 'end')
            self.editor.tag_remove('find_cur', '1.0', 'end')

        def _build_matches(pat):
            """Calcule toutes les occurrences et surligne en jaune."""
            _matches.clear()
            _cur_idx[0] = -1
            _clear_tags()
            if not pat:
                cnt_lbl.config(text="")
                return
            code  = self.editor.get('1.0', 'end-1c')
            plen  = len(pat)
            start = '1.0'
            while True:
                idx = self.editor.search(pat, start,
                                        nocase=True, stopindex='end')
                if not idx:
                    break
                end_i = f"{idx}+{plen}c"
                self.editor.tag_add('find_all', idx, end_i)
                _matches.append(idx)
                start = end_i
            total = len(_matches)
            cnt_lbl.config(text=f"0 / {total}" if total else "introuvable")

        def _go_to(idx):
            """Aller à l'occurrence idx (0-based)."""
            if not _matches:
                return
            n = len(_matches)
            idx = idx % n          # wrap-around
            _cur_idx[0] = idx
            pos   = _matches[idx]
            plen  = len(f_e.get())
            end_i = f"{pos}+{plen}c"
            # Surligner en violet la courante
            _clear_tags()
            for i, m in enumerate(_matches):
                ei = f"{m}+{plen}c"
                tag = 'find_cur' if i == idx else 'find_all'
                self.editor.tag_add(tag, m, ei)
            # Déplacer le curseur et scroller
            self.editor.mark_set(tk.INSERT, end_i)
            self.editor.see(pos)
            cnt_lbl.config(text=f"{idx+1} / {n}")

        def on_pat_change(e=None):
            pat = f_e.get()
            _build_matches(pat)
            if _matches:
                # Aller à l'occurrence la plus proche du curseur
                cur = self.editor.index(tk.INSERT)
                for i, m in enumerate(_matches):
                    if self.editor.compare(m, '>=', cur):
                        _go_to(i); return
                _go_to(0)

        def find_next(e=None):
            pat = f_e.get()
            if not pat:
                return
            if not _matches:
                _build_matches(pat)
            if not _matches:
                cnt_lbl.config(text="introuvable")
                messagebox.showinfo("Chercher", f"«{pat}» introuvable.", parent=win)
                return
            _go_to(_cur_idx[0] + 1)

        def find_prev(e=None):
            pat = f_e.get()
            if not pat:
                return
            if not _matches:
                _build_matches(pat)
            if not _matches:
                cnt_lbl.config(text="introuvable")
                return
            _go_to(_cur_idx[0] - 1)

        def replace(e=None):
            pat = f_e.get()
            rep = r_e.get()
            if not pat or not _matches:
                find_next(); return
            idx = _cur_idx[0]
            if idx < 0 or idx >= len(_matches):
                find_next(); return
            pos   = _matches[idx]
            end_i = f"{pos}+{len(pat)}c"
            self.editor.delete(pos, end_i)
            self.editor.insert(pos, rep)
            self._highlight()
            # Reconstruire les occurrences après modification
            _build_matches(pat)
            if _matches:
                next_i = min(idx, len(_matches) - 1)
                _go_to(next_i)

        def replace_all():
            pat = f_e.get()
            rep = r_e.get()
            if not pat:
                return
            code  = self.editor.get('1.0', 'end-1c')
            count = len(re.findall(re.escape(pat), code, flags=re.IGNORECASE))
            if not count:
                messagebox.showinfo("Tout remplacer",
                    f"«{pat}» introuvable.", parent=win)
                return
            new = re.sub(re.escape(pat), rep, code, flags=re.IGNORECASE)
            self.editor.delete('1.0', 'end')
            self.editor.insert('1.0', new)
            self.editor.mark_set(tk.INSERT, '1.0')
            self.editor.see('1.0')
            self._highlight()
            _build_matches(pat)
            messagebox.showinfo("Tout remplacer",
                f"{count} occurrence(s) remplacée(s).", parent=win)

        # ── Boutons ───────────────────────────────────────────────────
        bf = tk.Frame(win, bg=T['bg2'])
        bf.grid(row=2, column=0, columnspan=5, pady=8)
        for txt, cmd in [("◀ Précédent", find_prev),
                        ("Suivant ▶",   find_next),
                        ("Remplacer",   replace),
                        ("Tout remplacer", replace_all)]:
            tk.Button(bf, text=txt, command=cmd,
                bg=T['accent'], fg='white', relief='flat', bd=0,
                padx=10, pady=5, font=('Consolas', 9),
                cursor='hand2').pack(side=tk.LEFT, padx=3)

        # ── Raccourcis clavier ────────────────────────────────────────
        f_e.bind('<Return>',  find_next)
        f_e.bind('<KeyRelease>', on_pat_change)
        win.bind('<F3>',      find_next)
        win.bind('<Shift-F3>', find_prev)
        win.bind('<Escape>',  lambda e: self._find_close(win))

        # Nettoyer les tags à la fermeture
        win.protocol('WM_DELETE_WINDOW', lambda: self._find_close(win))

        f_e.focus_set()

    def _find_close(self, win):
        """Ferme la fenêtre Find et efface les surbrillances."""
        try:
            self.editor.tag_remove('find_all', '1.0', 'end')
            self.editor.tag_remove('find_cur', '1.0', 'end')
        except Exception:
            pass
        try:
            win.destroy()
        except Exception:
            pass
        self._find_win = None

    # ─────────────────────────────────────────────────────────────────
    #  QUIZ
    # ─────────────────────────────────────────────────────────────────
    def open_vars_inspector(self):
        T   = self.T
        win = tk.Toplevel(self.root)
        win.title("Inspecteur de variables")
        win.geometry("600x480")
        win.configure(bg=T['bg2'])
        cols = ('Variable', 'Type', 'Valeur')
        tv   = ttk.Treeview(win, columns=cols, show='headings', height=14)
        for c in cols:
            tv.heading(c, text=c)
            tv.column(c, width=140)
        tv.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        style = ttk.Style()
        style.theme_use('default')
        style.configure('Treeview',
            background=T['editor_bg'], foreground=T['editor_fg'],
            fieldbackground=T['editor_bg'], rowheight=22,
            font=('Consolas', 9))
        style.configure('Treeview.Heading',
            background=T['bg3'], foreground=T['fg'],
            font=('Consolas', 9, 'bold'))
        style.map('Treeview', background=[('selected', T['accent'])])

        def refresh():
            for row in tv.get_children():
                tv.delete(row)
            code = self.editor.get('1.0', 'end-1c')
            try:
                toks = tokenize(code)
                prog = Parser(toks).parse()
                for d in prog.vars:
                    for name in d.names:
                        tv.insert('', 'end',
                                    values=(name, str(d.type), '—'))
            except Exception as ex:
                tv.insert('', 'end', values=('Erreur parsing', str(ex), ''))
            win.after(2000, refresh)

        refresh()
        tk.Button(win, text="Actualiser", command=refresh,
            bg=T['accent'], fg='white', relief='flat', bd=0,
            padx=12, pady=4, font=('Consolas', 9),
            cursor='hand2').pack(pady=6)

    # ─────────────────────────────────────────────────────────────────
    #  EXPORT — vers C et Python
    # ─────────────────────────────────────────────────────────────────
    def _parse_current(self):
        """Parse le code courant, retourne (prog, None) ou (None, err_msg)."""
        code = self.editor.get('1.0', 'end-1c')
        try:
            toks = tokenize(code)
            prog = Parser(toks).parse()
            return prog, None
        except (LexerError, ParseError) as e:
            return None, str(e)
        except Exception as e:
            return None, str(e)

    def export_c(self):
        prog, err = self._parse_current()
        if err:
            messagebox.showerror("Export C", f"Erreur de parsing :\n{err}")
            return
        code_c = CodeGenC().generate(prog)
        p = filedialog.asksaveasfilename(
            title="Exporter vers C",
            defaultextension=".c",
            filetypes=[("C source", "*.c"), ("Tous", "*.*")])
        if not p:
            return
        try:
            from pathlib import Path as _P
            _P(p).write_text(code_c, encoding='utf-8')
            messagebox.showinfo("Export C", f"Fichier C généré :\n{p}")
        except Exception as ex:
            messagebox.showerror("Export C", str(ex))

    def export_python(self):
        prog, err = self._parse_current()
        if err:
            messagebox.showerror("Export Python", f"Erreur de parsing :\n{err}")
            return
        code_py = CodeGenPy().generate(prog)
        p = filedialog.asksaveasfilename(
            title="Exporter vers Python",
            defaultextension=".py",
            filetypes=[("Python", "*.py"), ("Tous", "*.*")])
        if not p:
            return
        try:
            from pathlib import Path as _P
            _P(p).write_text(code_py, encoding='utf-8')
            messagebox.showinfo("Export Python", f"Fichier Python généré :\n{p}")
        except Exception as ex:
            messagebox.showerror("Export Python", str(ex))

    # ─────────────────────────────────────────────────────────────────
    #  LIVE VARIABLES PREVIEW  (F7)
    # ─────────────────────────────────────────────────────────────────
    def show_live_vars(self):
        T = self.T
        if hasattr(self, '_live_win') and self._live_win and self._live_win.winfo_exists():
            self._live_win.lift(); return

        win = tk.Toplevel(self.root)
        win.title("Live Variables")
        win.geometry("400x420")
        win.configure(bg=T['bg2'])
        win.attributes('-topmost', True)
        self._live_win = win

        # ── Header ──
        hdr = tk.Frame(win, bg=T['bg3'], height=30)
        hdr.pack(fill=tk.X); hdr.pack_propagate(False)
        tk.Label(hdr, text="  📊  Variables en temps réel  (F7)",
            bg=T['bg3'], fg=T['accent'],
            font=('Consolas', 9, 'bold')).pack(side=tk.LEFT, padx=8, pady=6)
        self._live_status = tk.Label(hdr, text="En attente…",
            bg=T['bg3'], fg=T['fg2'], font=('Consolas', 8))
        self._live_status.pack(side=tk.RIGHT, padx=8)

        # ── Treeview ──
        cols = ('Variable', 'Valeur', 'Type')
        tv = ttk.Treeview(win, columns=cols, show='headings', height=16)
        tv.heading('Variable', text='Variable')
        tv.heading('Valeur',   text='Valeur')
        tv.heading('Type',     text='Type')
        tv.column('Variable', width=120, anchor='w')
        tv.column('Valeur',   width=180, anchor='w')
        tv.column('Type',     width=80,  anchor='center')

        style = ttk.Style()
        style.theme_use('default')
        style.configure('Treeview',
            background=T['editor_bg'], foreground=T['editor_fg'],
            fieldbackground=T['editor_bg'], rowheight=22,
            font=('Consolas', 9))
        style.configure('Treeview.Heading',
            background=T['bg3'], foreground=T['fg'],
            font=('Consolas', 9, 'bold'))
        style.map('Treeview', background=[('selected', T['accent'])])

        sb = tk.Scrollbar(win, orient=tk.VERTICAL, command=tv.yview,
            bg=T['bg3'], troughcolor=T['bg2'], relief='flat', width=8)
        tv.configure(yscrollcommand=sb.set)
        sb.pack(side=tk.RIGHT, fill=tk.Y)
        tv.pack(fill=tk.BOTH, expand=True, padx=4, pady=4)
        self._live_tv = tv

        def _type_name(v):
            if isinstance(v, bool):   return 'Booleen'
            if isinstance(v, int):    return 'Entier'
            if isinstance(v, float):  return 'Reel'
            if isinstance(v, str):    return 'Chaine'
            if isinstance(v, list):   return 'Tableau'
            if isinstance(v, dict):   return 'Enreg.'
            if v is None:             return 'NIL'
            return type(v).__name__

        def _val_str(v):
            if isinstance(v, bool):  return 'Vrai' if v else 'Faux'
            if v is None:            return 'NIL'
            if isinstance(v, list):
                if len(v) > 6:
                    return '[' + ', '.join(str(x) for x in v[:6]) + '…]'
                return '[' + ', '.join(str(x) for x in v) + ']'
            if isinstance(v, dict):
                items = list(v.items())[:3]
                s = '{' + ', '.join(f'{k}:{_val_str(vv)}' for k, vv in items) + '}'
                return s
            return str(v)

        def refresh():
            for row in tv.get_children():
                tv.delete(row)
            # Essayer de lire l'environnement courant de l'interpréteur actif
            interp = getattr(self, '_interp', None)
            if interp and interp.current_env:
                snap = interp.current_env.snapshot()
                for vname, val in sorted(snap.items()):
                    tv.insert('', 'end', values=(
                        vname, _val_str(val), _type_name(val)))
                self._live_status.config(
                    text=f"⚙ En cours  ({len(snap)} var.)", fg=T['green'])
            else:
                # Pas d'exec active : parser le code pour montrer les déclarations
                try:
                    code = self.editor.get('1.0', 'end-1c')
                    toks = tokenize(code)
                    prog = Parser(toks).parse()
                    for d in prog.vars:
                        for name in d.names:
                            tv.insert('', 'end', values=(
                                name, '—', str(d.type).replace('(','').replace(')','')[:20]))
                    self._live_status.config(
                        text=f"● Statique  ({len(prog.vars)} décl.)", fg=T['fg2'])
                except Exception:
                    self._live_status.config(text="● En attente…", fg=T['fg2'])
            if self._live_win and self._live_win.winfo_exists():
                self._live_win.after(350, refresh)

        refresh()

    # ─────────────────────────────────────────────────────────────────
    #  SYNTAX HELP
    # ─────────────────────────────────────────────────────────────────
    def show_syntax(self):
        T   = self.T
        win = tk.Toplevel(self.root)
        win.title("Référence de syntaxe")
        win.geometry("800x800")
        win.configure(bg=T['bg2'])
        txt = scrolledtext.ScrolledText(win,
            bg=T['editor_bg'], fg=T['editor_fg'],
            font=('Consolas', 10), borderwidth=0,
            highlightthickness=0, padx=16, pady=14)
        txt.pack(fill=tk.BOTH, expand=True, padx=8, pady=8)
        txt.insert('1.0', SYNTAX_HELP)
        txt.config(state='disabled')

    def show_about(self):
        messagebox.showinfo("AlgoStudio by ziani ayyoub 👨🏻‍💻  ",
            "AlgoStudio  for Pc \n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            " INGENIEUR MATH && info  \n  ZIANI Ayyoub 👨🏻‍💻   \n   ---Gladiator---     \n "
            "DEV BY PYTHON 100 % \n "
            "CONTACT : zianiayyoub06@gmail.com \n"
            "insta: ziani_000     \n "
            "contacter moi pour les probleme \n "
            "ou bien pour dev votre Idies \n"
            "J'espère que ça vous aimes 😁 \n"
            "merci pour votre utilisation 👍\n")

    # ─────────────────────────────────────────────────────────────────
    #  THEME
    # ─────────────────────────────────────────────────────────────────
    def toggle_theme(self):
        self.set_theme('light' if self.theme_name == 'dark' else 'dark')

    def set_theme(self, name):
        if name not in THEMES:
            return
        self.theme_name = name
        self.T          = THEMES[name]
        # ── Sauvegarder dans le fichier de configuration ─────────────
        try:
            cfg = {}
            if CONFIG_PATH.exists():
                cfg = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
            cfg['theme'] = name
            CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2),
                                    encoding='utf-8')
        except Exception:
            pass
        # ── Appliquer immédiatement (reconfigurer tous les widgets) ──
        T = self.T
        self.root.configure(bg=T['bg'])
        self._apply_tags()
        self._highlight()
        messagebox.showinfo("Thème",
            f"Thème «{name}» activé et sauvegardé.\n"
            "Redémarrez pour appliquer à tous les panneaux.")

    # ─────────────────────────────────────────────────────────────────
    #  WELCOME
    # ─────────────────────────────────────────────────────────────────
    def _load_welcome(self):
        self.editor.insert('1.0', """\
// ╔══════════════════════════════════════════════════════════════════╗
// ║          AlgoStudio  —  by ZIANI Ayyoub 👨🏻‍💻                 ║
// ║          Compilateur / Interpréteur de pseudocode algorithmique  ║
// ╚══════════════════════════════════════════════════════════════════╝
//
//  RACCOURCIS CLAVIER
//  ══════════════════════════════════════════════════════════════════
//  F5              ▶  Exécuter l algorithme
//  F6              ■  Arrêter l exécution
//  F7              📊 Live Variables (variables en temps réel)
//  Ctrl+T          📄 Nouvel onglet (nouveau fichier)
//  Ctrl+W          ✕  Fermer l onglet courant
//  Ctrl+Espace     💡 Suggestions (mots-clés + vos variables)
//  Ctrl+F          🔍 Chercher / Remplacer
//  Ctrl+/          💬 Commenter / Décommenter
//  Tab             →  Indentation  /  Valider suggestion
//  Échap           ✕  Fermer la suggestion
//
//  STRUCTURE D UN ALGORITHME
//  ══════════════════════════════════════════════════════════════════
//  Algorithme <Nom>;
//  Type <NomType> = Enregistrement        // facultatif
//      champ : Type;
//  Fin;
//  Var
//      variable : Type;
//      tableau[N] : Tableau De Type;
//      pointeur   : ^Type;                // ^ = pointeur
//  Debut
//      <instructions>
//  Fin.
//
//  NOUVEAUTÉS
//  ══════════════════════════════════════════════════════════════════
//  ^Type            Pointeur (ex: p : ^Entier   p : ^MaStruct)
//  Arreter;         Sortir d une boucle (break)
//  Continuer;       Itération suivante (continue)
//  Selon x Faire    Switch / Case
//  allouer(n * taille(entier))   Allocation dynamique
//  Export vers C et Python  (Menu Outils)
//  Onglets multiples  (Ctrl+T pour ouvrir un nouveau)
//
//  📖 Exemples  →  Bouton "Exemples" dans la barre d outils
//  ✉  Contact   →  zianiayyoub06@gmail.com

Algorithme Bienvenue;
Var
    prenom : Chaine;
    n, i   : Entier;
Debut
    Ecrire("╔══════════════════════════════╗");
    Ecrire("║  Bienvenue dans AlgoStudio   ║");
    Ecrire("╚══════════════════════════════╝");
    Ecrire("Quel est votre prenom ?");
    Lire(prenom);
    Ecrire("Bonjour,", prenom, "! Prêt à coder  🚀");
    Ecrire("Entrez un nombre pour voir sa table de multiplication :");
    Lire(n);
    Ecrire("--- Table de", n, "---");
    Pour i <- 1 a 10 Faire
        Ecrire(n, "x", i, "=", n * i);
    FinPour;
    Ecrire("Appuyez sur F5 pour exécuter, F6 pour arrêter.");
Fin.
""")
        self._highlight()
        self._update_line_numbers()

    # ─────────────────────────────────────────────────────────────────
    #  SPLASH SCREEN — page de bienvenue temporaire
    # ─────────────────────────────────────────────────────────────────
    def show_welcome_splash(self):
        """Splash screen affiché au démarrage — se ferme automatiquement."""
        T    = self.T
        win  = tk.Toplevel(self.root)
        win.overrideredirect(True)
        win.configure(bg=T['bg2'])

        # Centre sur l écran
        win.update_idletasks()
        sw = win.winfo_screenwidth()
        sh = win.winfo_screenheight()
        w, h = 750, 450
        win.geometry(f"{w}x{h}+{(sw-w)//2}+{(sh-h)//2}")

        # ── Bordure colorée ──────────────────────────────────────────
        bd = tk.Frame(win, bg=T['accent'], padx=3, pady=3)
        bd.pack(fill=tk.BOTH, expand=True)
        inner = tk.Frame(bd, bg=T['bg2'])
        inner.pack(fill=tk.BOTH, expand=True)

        # ── Logo / Titre ─────────────────────────────────────────────
        tk.Label(inner, text="AlgoStudio",
            bg=T['bg2'], fg=T['accent'],
            font=('Consolas', 32, 'bold')).pack(pady=(30, 4))

        tk.Label(inner, text="Compilateur · Interpréteur · Pseudocode Algorithmique",
            bg=T['bg2'], fg=T['fg2'],
            font=('Consolas', 10)).pack()

        tk.Frame(inner, bg=T['border'], height=1).pack(
            fill=tk.X, padx=40, pady=14)

        # ── Features ────────────────────────────────────────────────
        feats = [
            ("▶",  "Exécution directe                F5 / F6"),
            ("💡", "Auto-complétion intelligente      Ctrl+Espace"),
            ("📊", "Variables en temps réel           F7"),
            ("⬆",  "Export vers C et Python          Menu Outils"),
            ("📄", "Onglets multiples                Ctrl+T"),
            ("🔍", "Recherche avec surlignage        Ctrl+F"),
        ]
        feat_frame = tk.Frame(inner, bg=T['bg2'])
        feat_frame.pack(padx=40, fill=tk.X)
        for icon, text in feats:
            row = tk.Frame(feat_frame, bg=T['bg2'])
            row.pack(fill=tk.X, pady=2)
            tk.Label(row, text=f"  {icon}  ", bg=T['bg2'],
                fg=T['accent'], font=('Consolas', 11), width=4).pack(side=tk.LEFT)
            tk.Label(row, text=text, bg=T['bg2'],
                fg=T['fg'], font=('Consolas', 9), anchor='w').pack(side=tk.LEFT)

        tk.Frame(inner, bg=T['border'], height=1).pack(
            fill=tk.X, padx=40, pady=14)

        # ── Version + auteur ─────────────────────────────────────────
        tk.Label(inner,
            text="ZIANI Ayyoub  ·  zianiayyoub06@gmail.com",
            bg=T['bg2'], fg=T['fg3'],
            font=('Consolas', 8)).pack()

        # ── Barre de progression (fermeture auto 3s) ─────────────────
        bar_frame = tk.Frame(inner, bg=T['bg3'], height=6)
        bar_frame.pack(fill=tk.X, padx=40, pady=(12, 6))
        bar_frame.pack_propagate(False)
        bar = tk.Frame(bar_frame, bg=T['accent'], height=6, width=0)
        bar.place(x=0, y=0, relheight=1.0, width=0)

        btn = tk.Button(inner, text="Commencer  →",
            command=win.destroy,
            bg=T['accent'], fg='white', relief='flat', bd=0,
            padx=20, pady=8, font=('Consolas', 10, 'bold'),
            cursor='hand2')
        btn.pack(pady=4)

        # Animation barre de progression
        total_ms = 5000
        steps    = 60
        step_ms  = total_ms // steps
        bar_frame.update_idletasks()
        total_w  = bar_frame.winfo_width() or 540

        def animate(step=0):
            if not win.winfo_exists(): return
            w_now = int(total_w * step / steps)
            bar.place(x=0, y=0, relheight=1.0, width=w_now)
            if step < steps:
                win.after(step_ms, animate, step + 1)
            else:
                win.destroy()

        win.after(100, animate)
        win.focus_set()
        win.bind('<Return>', lambda e: win.destroy())
        win.bind('<space>',  lambda e: win.destroy())
        win.bind('<Escape>', lambda e: win.destroy())


# ══════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════


