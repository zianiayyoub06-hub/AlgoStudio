# -*- coding: utf-8 -*-
"""Parser — Analyse syntaxique du pseudocode algorithmique."""

from lexer import Token
from ast_nodes import *

# ══════════════════════════════════════════════════════════════════════
#  PARSER
# ══════════════════════════════════════════════════════════════════════

class ParseError(Exception):
    def __init__(self, msg, line, col):
        super().__init__(msg); self.line=line; self.col=col

class Parser:
    def __init__(self, tokens):
        self.tokens=tokens; self.pos=0

    @property
    def cur(self): return self.tokens[self.pos]

    def eat(self, *types):
        t = self.cur
        if t.type not in types:
            exp = ' ou '.join(types)
            raise ParseError(f"Attendu {exp}, trouvé {t.type!r} «{t.value}»", t.line, t.col)
        self.pos += 1; return t

    def match(self, *types):
        if self.cur.type in types: return self.eat(*types)
        return None

    def kw(self, *words):
        return self.cur.type in {f'KW_{w.upper()}' for w in words}

    def eat_kw(self, w): return self.eat(f'KW_{w.upper()}')

    # ── Top ──────────────────────────────────
    def parse(self):
        # Syntaxe cours: type et fonctions/procedures peuvent apparaitre
        # dans n'importe quel ordre AVANT algorithme
        funcs = []
        global_types = {}
        while not self.kw('algorithme') and self.cur.type != 'EOF':
            if self.kw('fonction', 'procedure'):
                funcs.append(self.parse_func())
            elif self.kw('type'):
                global_types.update(self.parse_type_decls())
            else:
                self.pos += 1  # skip unknown tokens
        self.eat_kw('algorithme')
        name = self.eat('ID').value
        self.match('SEMICOLON')
        # Bloc Const optionnel
        # Bloc Const: const N = 100; PI = 3.14; ...
        consts = {}
        if self.kw('const'):
            self.pos += 1
            stop_const = {'KW_VAR','KW_DEBUT','KW_FIN','KW_TYPE','EOF'}
            while self.cur.type not in stop_const:
                # Lire: <nom> = <valeur> ;
                if self._is_varname_token():
                    cname = self._eat_varname()
                    if self.match('EQ'):
                        cval = self.parse_expr()
                        self.match('SEMICOLON')
                        consts[cname.lower()] = cval
                    else:
                        self.pos += 1
                else:
                    self.pos += 1
        local_types = self.parse_type_decls()
        global_types.update(local_types)
        vars_ = self.parse_vars()
        self.eat_kw('debut')
        body  = self.parse_stmts()
        self.eat_kw('fin')
        self.match('DOT')
        return Program(name, vars_, body, funcs, global_types, consts)


    def parse_type_decls(self):
        """Parse zero or more: Type <n> = Enregistrement [debut] ... Fin;"""
        defs = {}
        while self.kw('type'):
            self.eat_kw('type')
            rec_name = self.eat('ID').value
            self.eat('EQ')
            self.eat_kw('enregistrement')
            # Syntaxe cours: Type X = Enregistrement debut ... fin;
            if self.kw('debut'): self.eat_kw('debut')
            fields = []
            stop = {'KW_FIN','KW_FINREC','EOF'}
            while self.cur.type not in stop:
                if not self._is_varname_token():
                    self.pos += 1; continue
                # Plusieurs noms du meme type: nom1, nom2 : type
                fnames = [self._eat_varname()]
                while self.match('COMMA'):
                    fnames.append(self._eat_varname())
                self.eat('COLON')
                ftype = self.parse_type()
                self.match('SEMICOLON')
                for fn in fnames:
                    fields.append((fn, ftype))
            # eat Fin or FinRec
            if self.cur.type == 'KW_FIN': self.eat_kw('fin')
            elif self.cur.type == 'KW_FINREC': self.pos += 1
            self.match('SEMICOLON')
            defs[rec_name.lower()] = fields
        return defs

    def parse_vars(self):
        decls = []
        if not self.kw('var'): return decls
        self.eat_kw('var')
        stop = {'KW_DEBUT','KW_FIN','EOF'}
        while self.cur.type not in stop:
            d = self.parse_var_decl()
            if d: decls.append(d)
        return decls

    # Keywords that users commonly use as variable names
    _VAR_KWS = {
        'KW_A','KW_E',                          # single chars
        'KW_PILE','KW_FILE','KW_TETE','KW_QUEUE',
        'KW_SOMMET','KW_TAILLE','KW_NOM',
        'KW_DE',                                 # sometimes used
        # Procédures système appelables comme des fonctions
        'KW_NOUVEAU','KW_LIBERER','KW_ALLOUER',
        'KW_OUVRIR','KW_FERMER',
        'KW_EMPILER','KW_DEPILER',
        'KW_ENFILER','KW_DEFILER',
        'KW_FINFICHIER',
    }

    def _is_varname_token(self):
        t = self.cur
        return (t.type == 'ID' or
                (t.type.startswith('KW_') and len(t.value) == 1) or
                t.type in self._VAR_KWS)

    def _eat_varname(self):
        """Eat an identifier (including keywords used as variable names)."""
        t = self.cur
        if t.type == 'ID':
            self.pos += 1; return t.value
        if (t.type.startswith('KW_') and len(t.value) == 1) or t.type in self._VAR_KWS:
            self.pos += 1; return t.value
        raise ParseError(f"Nom de variable attendu, trouvé «{t.value}»", t.line, t.col)

    def parse_var_decl(self):
        line = self.cur.line
        # Skip non-variable tokens
        if not self._is_varname_token():
            self.pos += 1; return None
        names = [self._eat_varname()]
        # Official syntax: T[50] : Tableau De Entier  or  M[3][3] : Tableau De Reel
        # Sizes come AFTER the variable name (before the colon)
        pre_sizes = []
        while self.cur.type == 'LBRACKET':
            self.eat('LBRACKET')
            pre_sizes.append(self.parse_expr())
            self.eat('RBRACKET')
        while self.match('COMMA'):
            names.append(self._eat_varname())
        self.eat('COLON')
        # If pre_sizes collected: T[50] : Tableau De Entier
        # Skip "Tableau" keyword if present (sizes already known)
        if pre_sizes and self.kw('tableau'):
            self.eat_kw('tableau')
            # skip De or d
            if self.kw('de'): self.eat_kw('de')
            elif self.cur.type=='ID' and self.cur.value.lower() in ('d','de'):
                self.pos += 1
            base = self.parse_type()
            # Build type: for T[50] -> ('tableau',[50],base)
            # For M[3][3] -> ('tableau',[3],('tableau',[3],base))
            type_ = base
            for sz in reversed(pre_sizes):
                type_ = ('tableau', [sz], type_)
        else:
            type_ = self.parse_type()
            if pre_sizes and not (isinstance(type_, tuple) and type_[0]=='tableau'):
                type_ = ('tableau', pre_sizes, type_)
        self.match('SEMICOLON')
        return VarDecl(names, type_, line)

    def parse_type(self):
        kw_map = {
            'KW_ENTIER':'entier','KW_REEL':'reel','KW_BOOLEEN':'booleen',
            'KW_CHAINE':'chaine','KW_CARACTERE':'caractere',
            'KW_FICHIER':'fichier',
        }
        if self.cur.type in kw_map:
            k = kw_map[self.cur.type]; self.pos+=1
            # 'chaine de caractere' est synonyme de 'chaine'
            if k == 'chaine' and self.kw('de'):
                self.eat_kw('de')
                if self.kw('caractere'): self.pos += 1
            return k
        if self.kw('tableau'):
            self.eat_kw('tableau')
            sizes = []
            if self.cur.type == 'LBRACKET':
                self.eat('LBRACKET')
                sizes.append(self.parse_expr())
                while self.match('COMMA'):
                    sizes.append(self.parse_expr())
                self.eat('RBRACKET')
            # Accept: De  OR  d (apostrophe stripped)
            # Accept: De  OR  d (apostrophe stripped)
            if self.kw('de'): self.eat_kw('de')
            elif self.cur.type=='ID' and self.cur.value.lower() in ('d','de'): self.pos+=1
            base = self.parse_type()
            return ('tableau', sizes, base)
        # Accepter aussi les noms de types qui sont des keywords (ex: 'E', 'A', noms users)
        if self.cur.type == 'ID':
            return self.eat('ID').value
        # Single-char keywords used as type names (ex: type E = Enregistrement)
        if (self.cur.type.startswith('KW_') and len(self.cur.value) == 1) or \
           self.cur.type in self._VAR_KWS:
            v = self.cur.value; self.pos += 1; return v
        if self.kw('pointeur'):
            self.eat_kw('pointeur')
            if self.kw('vers'): self.eat_kw('vers')
            return ('pointeur', self.parse_type())
        # Syntaxe ^ : ^Type  (ex: p : ^entier  p : ^MaStruct)
        if self.cur.type == 'CARET':
            self.pos += 1
            return ('pointeur', self.parse_type())
        if self.cur.type == 'ID':
            return self.eat('ID').value
        raise ParseError(f"Type attendu, trouve {self.cur.value!r}", self.cur.line, self.cur.col)


    def parse_func(self):
        line = self.cur.line
        is_func = self.kw('fonction')
        self.pos += 1
        name = self.eat('ID').value
        # Procedure sans parentheses: Procedure Bonjour debut...
        if self.cur.type != 'LPAREN':
            self.match('SEMICOLON')
            vars_ = self.parse_vars()
            self.eat_kw('debut')
            body = self.parse_stmts()
            self.eat_kw('fin')
            self.match('SEMICOLON')
            return FuncDef(name, [], None, vars_, body, line)
        self.eat('LPAREN')
        params = []
        while self.cur.type != 'RPAREN' and self.cur.type != 'EOF':
            # Capturer le mode de transmission: E/ S/ E/S/
            mode = 'E'  # defaut: entree
            def read_mode():
                nonlocal mode
                if (self.cur.type == 'ID' and
                    self.cur.value.upper() in ('E','S') and
                    self.pos+1 < len(self.tokens) and
                    self.tokens[self.pos+1].type == 'DIV'):
                    m = self.cur.value.upper(); self.pos += 2
                    if (self.cur.type == 'ID' and
                        self.cur.value.upper() == 'S' and
                        self.pos+1 < len(self.tokens) and
                        self.tokens[self.pos+1].type == 'DIV'):
                        m = 'ES'; self.pos += 2
                    mode = m
            read_mode()
            cur_mode = mode
            pnames = [self._eat_varname()]
            while self.cur.type == 'COMMA':
                self.pos += 1
                mode = cur_mode
                read_mode()
                if self._is_varname_token():
                    pnames.append(self._eat_varname())
                else:
                    break
            self.eat('COLON')
            ptype = self.parse_type()
            # mode ES ou S = pass-by-ref
            is_ref = cur_mode in ('S','ES')
            for pn in pnames:
                params.append((pn, ptype, is_ref))
            if self.cur.type not in ('RPAREN','EOF'): self.match('SEMICOLON')
        self.eat('RPAREN')
        ret_type = None
        if is_func:
            self.eat('COLON'); ret_type = self.parse_type()
        self.match('SEMICOLON')
        vars_ = self.parse_vars()
        self.eat_kw('debut')
        body = self.parse_stmts()
        self.eat_kw('fin')
        self.match('SEMICOLON')
        return FuncDef(name, params, ret_type, vars_, body, line)





    # ── Statements ───────────────────────────
    STOP = {'KW_FIN','KW_FINSI','KW_FSI','KW_FINTANTQUE','KW_FINPOUR','KW_FINREPETER',
            'KW_JUSQUA','KW_SINON','KW_AUTREMENT','KW_CAS','KW_FINSELON','EOF'}

    def parse_stmts(self):
        stmts = []
        while self.cur.type not in self.STOP:
            s = self.parse_stmt()
            if s is not None: stmts.append(s)
        return stmts

    def parse_stmt(self):
        tok = self.cur
        if self.kw('ecrire'):   return self.p_ecrire()
        if self.kw('lire'):     return self.p_lire()
        if self.kw('si'):       return self.p_if()
        if self.kw('tantque'):  return self.p_while()
        if self.kw('tant'):     return self.p_while()   # 'Tant Que' two words
        if self.kw('pour'):     return self.p_for()
        if self.kw('repeter'):  return self.p_repeat()
        if self.kw('selon'):    return self.p_selon()
        if self.kw('arreter'):
            line = self.cur.line; self.pos += 1; self.match('SEMICOLON')
            return Break(line)
        if self.kw('continuer'):
            line = self.cur.line; self.pos += 1; self.match('SEMICOLON')
            return Continue(line)
        if self.kw('retourner','retourne'): return self.p_return()
        # Allow keywords used as variable names as assignment targets
        if tok.type == 'ID' or (tok.type.startswith('KW_') and len(tok.value) == 1) or tok.type in self._VAR_KWS:
            return self.p_assign_or_call()
        self.pos += 1; return None

    def p_selon(self):
        """Selon <expr> Faire  Cas v: stmts  Cas a..b: stmts  Autrement: stmts  FinSelon"""
        line = self.cur.line
        self.eat_kw('selon')
        expr = self.parse_expr()
        self.eat_kw('faire')
        cases = []
        default = []
        while self.cur.type not in {'KW_FINSELON','KW_FIN','EOF'}:
            if self.kw('autrement'):
                self.eat_kw('autrement')
                self.match('COLON')
                default = self.parse_stmts()
            elif self.kw('cas'):
                self.eat_kw('cas')
                val = self.parse_expr()
                # Vérifier si c'est une plage : Cas 1..5:
                if self.cur.type == 'DOT' and self.pos+1 < len(self.tokens) and                         self.tokens[self.pos+1].type == 'DOT':
                    self.pos += 2  # skip ..
                    high = self.parse_expr()
                    val  = RangeVal(val, high)
                elif self.cur.type == 'ID' and self.cur.value == '..':
                    self.pos += 1
                    high = self.parse_expr()
                    val  = RangeVal(val, high)
                self.match('COLON')
                stmts = self.parse_stmts()
                cases.append((val, stmts))
            else:
                self.pos += 1
        if self.kw('finselon'): self.eat_kw('finselon')
        elif self.kw('fin'):    self.eat_kw('fin')
        self.match('SEMICOLON')
        return Switch(expr, cases, default, line)

    def p_ecrire(self):
        line = self.cur.line; self.eat_kw('ecrire')
        self.eat('LPAREN')
        args = [self.parse_expr()]
        while self.match('COMMA'): args.append(self.parse_expr())
        self.eat('RPAREN'); self.match('SEMICOLON')
        return Ecrire(args, line)

    def p_lire(self):
        line = self.cur.line; self.eat_kw('lire')
        self.eat('LPAREN')
        targets = [self.parse_lval()]
        while self.match('COMMA'): targets.append(self.parse_lval())
        self.eat('RPAREN'); self.match('SEMICOLON')
        return Lire(targets, line)

    def p_if(self):
        line = self.cur.line; self.eat_kw('si')
        cond = self.parse_expr(); self.eat_kw('alors')
        then = self.parse_stmts()
        else_ = []
        if self.kw('sinon'): self.eat_kw('sinon'); else_ = self.parse_stmts()
        if   self.kw('fsi'):   self.eat_kw('fsi')
        elif self.kw('finsi'): self.eat_kw('finsi')
        else: self.eat('KW_FINSI')
        return If(cond, then, else_, line)

    def p_while(self):
        line = self.cur.line
        if   self.kw('tantque'): self.eat_kw('tantque')
        elif self.kw('tant'):
            self.eat_kw('tant')
            # 'que' est maintenant un mot-clé (KW_QUE) ou un ID selon le contexte
            if self.kw('que') or (self.cur.type == 'ID' and self.cur.value.lower() == 'que'):
                self.pos += 1
        cond = self.parse_expr(); self.eat_kw('faire')
        if self.kw('debut'): self.eat_kw('debut')
        body = self.parse_stmts()
        if   self.kw('fintantque'): self.eat_kw('fintantque')
        elif self.kw('fin'):        self.eat_kw('fin')
        return While(cond, body, line)

    def p_for(self):
        line = self.cur.line; self.eat_kw('pour')
        var = self._eat_varname()
        # Official: Pour i <- 1 a n  OR  Pour i := 1 a n  OR  Pour i De 1 a n
        if self.cur.type == 'ASSIGN':   self.pos += 1
        elif self.kw('de'):             self.eat_kw('de')
        start = self.parse_expr(); self.eat_kw('a')
        end = self.parse_expr()
        step = None
        if self.kw('pas'): self.eat_kw('pas'); step = self.parse_expr()
        self.eat_kw('faire')
        if self.kw('debut'): self.eat_kw('debut')
        body = self.parse_stmts()
        if   self.kw('finpour'): self.eat_kw('finpour')
        elif self.kw('fin'):     self.eat_kw('fin')
        return For(var, start, end, step, body, line)

    def p_repeat(self):
        line = self.cur.line; self.eat_kw('repeter')
        body = self.parse_stmts()
        # After apostrophe removal: "jusqu'a" => ID('jusqu') + KW_A
        if   self.kw('jusqua'):  self.eat_kw('jusqua')
        elif self.cur.type=='ID' and self.cur.value.lower().startswith('jusqu'):
            self.pos += 1
            if self.cur.type=='KW_A' or (self.cur.type=='ID' and self.cur.value.lower()=='a'):
                self.pos += 1
        cond = self.parse_expr(); self.match('SEMICOLON')
        return Repeat(body, cond, line)

    def p_return(self):
        line = self.cur.line; self.pos += 1
        val = self.parse_expr(); self.match('SEMICOLON')
        return Return(val, line)

    def p_assign_or_call(self):
        line = self.cur.line
        name = self._eat_varname()
        if self.cur.type == 'LPAREN':
            self.eat('LPAREN')
            args = []
            if self.cur.type != 'RPAREN':
                args.append(self.parse_expr())
                while self.match('COMMA'): args.append(self.parse_expr())
            self.eat('RPAREN'); self.match('SEMICOLON')
            return FuncCall(name, args, line)
        # Procedure sans parentheses: Bonjour;  ou  Bonjour
        if self.cur.type in ('SEMICOLON','NEWLINE') or self.cur.type in self.STOP:
            self.match('SEMICOLON')
            return FuncCall(name, [], line)
        # Verification supplementaire: si prochain token n'est pas := ni [ ni . ni ->
        if self.cur.type not in ('ASSIGN','LBRACKET','DOT','ARROW','CARET'):
            # Probablement un appel de procedure sans parentheses
            self.match('SEMICOLON')
            return FuncCall(name, [], line)
        lval = self.parse_lval_from(name, line)
        self.eat('ASSIGN')
        val = self.parse_expr(); self.match('SEMICOLON')
        return Assign(lval, val, line)

    def parse_lval(self):
        line = self.cur.line
        name = self._eat_varname()
        return self.parse_lval_from(name, line)

    def parse_lval_from(self, name, line):
        # Start with bare name; first bracket makes ArrayAccess(name, idx)
        # Second bracket chains: ArrayAccess(ArrayAccess(name,i), j)
        current = name   # str for first level, ArrayAccess for deeper
        result  = Var(name, line)
        while True:
            if self.cur.type == 'LBRACKET':
                self.eat('LBRACKET')
                idx = self.parse_expr()
                self.eat('RBRACKET')
                result  = ArrayAccess(current, idx, line)
                current = result          # chain: next [j] wraps this node
            elif self.cur.type == 'DOT':
                self.eat('DOT')
                field  = self.eat('ID').value
                result = FieldAccess(result, field, line)
                current = result
            elif self.cur.type == 'ARROW':
                # Notation flèche : p->champ
                self.eat('ARROW')
                field  = self.eat('ID').value
                result = FieldAccess(result, field, line)
                current = result
            elif self.cur.type == 'CARET':
                # p^ := val  (deref postfix, notation Pascal)
                self.eat('CARET')
                result  = Deref(result, line)
                current = result
            else:
                break
        return result

    # ── Expressions ──────────────────────────
    def parse_expr(self): return self.p_or()
    def p_or(self):
        l = self.p_and()
        while self.kw('ou'): self.pos+=1; r=self.p_and(); l=BinOp(l,'ou',r)
        return l
    def p_and(self):
        l = self.p_not()
        while self.kw('et'): self.pos+=1; r=self.p_not(); l=BinOp(l,'et',r)
        return l
    def p_not(self):
        if self.kw('non'): self.pos+=1; return UnaryOp('non',self.p_not())
        return self.p_cmp()
    def p_cmp(self):
        l = self.p_add()
        ops = {'EQ':'=','NEQ':'<>','LT':'<','GT':'>','LEQ':'<=','GEQ':'>='}
        while self.cur.type in ops:
            op=ops[self.cur.type]; self.pos+=1; r=self.p_add(); l=BinOp(l,op,r)
        return l
    def p_add(self):
        l = self.p_mul()
        while self.cur.type in ('PLUS','MINUS'):
            op=self.cur.value; self.pos+=1; r=self.p_mul(); l=BinOp(l,op,r)
        return l
    def p_mul(self):
        l = self.p_unary()
        while (self.cur.type in ('MUL','DIV','MOD') or
            self.kw('div') or self.kw('mod')):
            op = self.cur.value.lower() if self.cur.type.startswith('KW_') else self.cur.value
            self.pos += 1; r = self.p_unary(); l = BinOp(l, op, r)
        return l
    def p_unary(self):
        if self.cur.type == 'MINUS': self.pos+=1; return UnaryOp('-',self.p_primary())
        return self.p_primary()
    def p_primary(self):
        t = self.cur
        if t.type == 'INT':    self.pos+=1; return Literal(int(t.value))
        if t.type == 'FLOAT':  self.pos+=1; return Literal(float(t.value))
        if t.type == 'STRING':
            self.pos+=1
            v = t.value
            if v.startswith('"""'): return Literal(v[3:-3])  # triple-quoted
            return Literal(v[1:-1])
        if t.type == 'CHAR':   self.pos+=1; return Literal(t.value[1])
        if self.kw('vrai'):    self.pos+=1; return Literal(True)
        if self.kw('faux'):    self.pos+=1; return Literal(False)
        if self.kw('nil'):     self.pos+=1; return Literal(None)
        # Built-in functions whose names are also keywords (taille, estvide, etc.)
        # Also allow single-char keywords used as variable names (a, e, de -> but 'de' is 2 chars)
        _bkw = {'KW_TAILLE','KW_ESTVIDE','KW_SOMMET','KW_TETE','KW_QUEUE',
                'KW_EMPILER','KW_DEPILER','KW_ENFILER','KW_DEFILER',
                'KW_REEL','KW_ENTIER','KW_CHAINE','KW_CARACTERE','KW_BOOLEEN',
                'KW_FICHIER','KW_POINTEUR',
                'KW_ALLOUER','KW_NOUVEAU'}
        # Quand un type-keyword est utilisé comme argument (ex: taille(entier))
        # → retourner son nom en minuscule comme Literal string
        _type_kws = {'KW_ENTIER':'entier','KW_REEL':'reel','KW_BOOLEEN':'booleen',
                    'KW_CHAINE':'chaine','KW_CARACTERE':'caractere',
                    'KW_FICHIER':'fichier','KW_POINTEUR':'pointeur'}
        if t.type in _type_kws and self.tokens[self.pos+1].type in ('COMMA','RPAREN'):
            self.pos += 1
            return Literal(_type_kws[t.type])
        _single_kw = t.type.startswith('KW_') and len(t.value) == 1
        if t.type in _bkw or t.type in self._VAR_KWS or t.type == 'ID' or _single_kw:
            self.pos+=1; name=t.value
            if self.cur.type == 'LPAREN':
                self.eat('LPAREN')
                args=[]
                if self.cur.type != 'RPAREN':
                    args.append(self.parse_expr())
                    while self.match('COMMA'): args.append(self.parse_expr())
                self.eat('RPAREN')
                return FuncCall(name, args, t.line)
            if self.cur.type == 'LBRACKET':
                self.eat('LBRACKET'); idx=self.parse_expr(); self.eat('RBRACKET')
                node = ArrayAccess(name, idx, t.line)
                # Handle M[i][j] — chain of bracket accesses
                while self.cur.type == 'LBRACKET':
                    self.eat('LBRACKET'); idx2=self.parse_expr(); self.eat('RBRACKET')
                    node = ArrayAccess(node, idx2, t.line)
                # Handle T[i].champ ou T[i]->champ après les crochets
                if self.cur.type == 'DOT':
                    self.eat('DOT'); field=self.eat('ID').value
                    node = FieldAccess(node, field, t.line)
                elif self.cur.type == 'ARROW':
                    self.eat('ARROW'); field=self.eat('ID').value
                    node = FieldAccess(node, field, t.line)
                return node
            # Chaîner . et -> et ^. : p->champ, e.nom, p^.champ
            base_node = Var(name, t.line)
            while self.cur.type in ('DOT', 'ARROW'):
                self.pos += 1
                field = self.eat('ID').value
                base_node = FieldAccess(base_node, field, t.line)
            # Notation ^.champ (déréférencement explicite)
            if self.cur.type == 'CARET' and self.tokens[self.pos+1].type == 'DOT':
                self.pos += 2  # skip ^ and .
                field = self.eat('ID').value
                base_node = FieldAccess(base_node, field, t.line)
            # Postfix ^ ou ^. apres un identifiant
            if self.cur.type == 'CARET':
                if self.pos+1 < len(self.tokens) and self.tokens[self.pos+1].type == 'DOT':
                    self.pos += 2
                    field = self.eat('ID').value
                    base_node = FieldAccess(base_node, field, t.line)
                else:
                    self.pos += 1
                    base_node = Deref(base_node, t.line)
            return base_node
        # &x = adresse de x (Ch4) — simulé: retourne la valeur de x
        if t.type == 'AMPERSAND':
            self.pos += 1
            return self.p_primary()
        # Postfix ^ ou ↑ dans (p+i)^ — gere apres parse_expr via p_primary
        # fin(f) : KW_FIN suivi de LPAREN → appel de fonction fin()
        if t.type == 'KW_FIN' and self.pos+1 < len(self.tokens) and \
        self.tokens[self.pos+1].type == 'LPAREN':
            self.pos += 1  # skip KW_FIN
            self.eat('LPAREN')
            fargs=[]
            if self.cur.type != 'RPAREN':
                fargs.append(self.parse_expr())
                while self.match('COMMA'): fargs.append(self.parse_expr())
            self.eat('RPAREN')
            return FuncCall('fin', fargs, t.line)
        if t.type == 'LPAREN':
            self.eat('LPAREN'); e=self.parse_expr(); self.eat('RPAREN'); return e
        raise ParseError(f"Expression attendue, trouvé «{t.value}»", t.line, t.col)

