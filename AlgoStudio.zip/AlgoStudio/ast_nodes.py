# -*- coding: utf-8 -*-
"""Nœuds AST (Abstract Syntax Tree) du compilateur."""

# ══════════════════════════════════════════════════════════════════════
#  AST
# ══════════════════════════════════════════════════════════════════════

class N: pass  # Node base

class Program(N):
    def __init__(self, name, vars_, body, funcs=None, types=None, consts=None):
        self.name=name; self.vars=vars_; self.body=body
        self.funcs=funcs or []; self.types=types or {}; self.consts=consts or {}
class RecordDef(N):
    """Type Name = Enregistrement field:type; ... Fin;"""
    def __init__(self, name, fields, line):
        self.name=name; self.fields=fields; self.line=line  # fields = [(fname, ftype)]

class VarDecl(N):
    def __init__(self, names, type_, line):
        self.names=names; self.type=type_; self.line=line

class Assign(N):
    def __init__(self, target, value, line):
        self.target=target; self.value=value; self.line=line

class BinOp(N):
    def __init__(self, left, op, right):
        self.left=left; self.op=op; self.right=right

class UnaryOp(N):
    def __init__(self, op, operand):
        self.op=op; self.operand=operand

class Literal(N):
    def __init__(self, value): self.value=value

class Var(N):
    def __init__(self, name, line): self.name=name; self.line=line

class ArrayAccess(N):
    def __init__(self, name, index, line): self.name=name; self.index=index; self.line=line

class FieldAccess(N):
    def __init__(self, obj, field, line): self.obj=obj; self.field=field; self.line=line

class Deref(N):
    def __init__(self, expr, line): self.expr=expr; self.line=line

class Ecrire(N):
    def __init__(self, args, line, newline=True):
        self.args=args; self.line=line; self.newline=newline

class Lire(N):
    def __init__(self, targets, line): self.targets=targets; self.line=line

class If(N):
    def __init__(self, cond, then, else_, line):
        self.cond=cond; self.then=then; self.else_=else_; self.line=line

class While(N):
    def __init__(self, cond, body, line):
        self.cond=cond; self.body=body; self.line=line

class For(N):
    def __init__(self, var, start, end, step, body, line):
        self.var=var; self.start=start; self.end=end
        self.step=step; self.body=body; self.line=line

class Repeat(N):
    def __init__(self, body, cond, line): self.body=body; self.cond=cond; self.line=line

class RangeVal(N):
    """Valeur de plage pour Cas :  Cas 1..5  ou  Cas 'a'..'z'"""
    def __init__(self, low, high): self.low=low; self.high=high

class Switch(N):
    """Selon <expr> Faire  Cas v: stmts  ...  Autrement: stmts  FinSelon"""
    def __init__(self, expr, cases, default, line):
        self.expr=expr; self.cases=cases; self.default=default; self.line=line
        # cases = list of (value_expr, stmts)

class FuncCall(N):
    def __init__(self, name, args, line): self.name=name; self.args=args; self.line=line

class Break(N):
    def __init__(self, line): self.line=line

class Continue(N):
    def __init__(self, line): self.line=line

class Return(N):
    def __init__(self, value, line): self.value=value; self.line=line

class FuncDef(N):
    def __init__(self, name, params, ret_type, vars_, body, line):
        self.name=name; self.params=params; self.ret_type=ret_type
        self.vars=vars_; self.body=body; self.line=line

