# -*- coding: utf-8 -*-
"""Exemples d'algorithmes intégrés (par chapitre)."""


EXAMPLES = {}

# ═══════════════════════════════════════════════════════════════════
#  Chapitre 1 — Le langage algorithmique
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 1 Le langage algorithmique — Structure generale"] = """\
algorithme StructureGenerale;
var
    x, y  : entier;
    r     : reel;
    b     : booleen;
debut
    ecrire("=== Structure generale d un algorithme ===");
    x := 10;
    y := 3;
    r := 3.14;
    b := vrai;
    ecrire("x =", x, "  y =", y);
    ecrire("r =", r);
    ecrire("b =", b);
    ecrire("x + y =", x + y);
    ecrire("x div y =", x div y);
    ecrire("x mod y =", x mod y);
    ecrire("x > y  :", x > y);
    ecrire("x <> y :", x <> y);
fin.
"""



EXAMPLES["Chapitre 1 Le langage algorithmique — Affectation et operateurs"] = """\
algorithme Operateurs;
var
    a, b, q, reste : entier;
    x              : reel;
debut
    ecrire("=== Affectation := et operateurs ===");
    a := 17;
    b := 5;
    ecrire("a =", a, "  b =", b);
    ecrire("a + b  =", a + b);
    ecrire("a - b  =", a - b);
    ecrire("a * b  =", a * b);
    ecrire("a / b  =", a / b);
    q     := a div b;
    reste := a mod b;
    ecrire("a div b =", q);
    ecrire("a mod b =", reste);
    ecrire("a = b  :", a = b);
    ecrire("a <> b :", a <> b);
    ecrire("a < b  :", a < b);
    ecrire("a > b  :", a > b);
fin.
"""

EXAMPLES["Chapitre 1 Le langage algorithmique — Conditions Si FinSi"] = """\
algorithme Conditions;
var
    note : reel;
    x    : entier;
debut
    ecrire("=== Si ... Alors ... Sinon ... FinSi ===");
    ecrire("Entrez votre note /20 :");
    lire(note);
    si (note >= 16) alors
        ecrire("Mention : Tres Bien");
    sinon
        si (note >= 14) alors
            ecrire("Mention : Bien");
        sinon
            si (note >= 12) alors
                ecrire("Mention : Assez Bien");
            sinon
                si (note >= 10) alors
                    ecrire("Mention : Passable");
                sinon
                    ecrire("Mention : Insuffisant");
                finsi;
            finsi;
        finsi;
    finsi;
    ecrire("Entrez un entier :");
    lire(x);
    si (x mod 2 = 0) alors
        ecrire(x, "est PAIR");
    sinon
        ecrire(x, "est IMPAIR");
    finsi;
fin.
"""

EXAMPLES["Chapitre 1 Le langage algorithmique — Boucle Pour"] = """\
algorithme BouclePour;
var
    i, somme : entier;
debut
    ecrire("=== Pour i := 0 a N-1 Faire ===");
    somme := 0;
    pour i := 0 a 9 faire
        somme := somme + (i + 1);
        ecrire("i =", i, "  somme partielle =", somme);
    fin;
    ecrire("Somme 1..10 =", somme);
    ecrire("--- Indices pairs de 0 a 9 ---");
    pour i := 0 a 9 faire
        si (i mod 2 = 0) alors ecrire(i); finsi;
    fin;
fin.
"""

EXAMPLES["Chapitre 1 Le langage algorithmique — Boucle TantQue"] = """\
algorithme BoucleTantQue;
var
    i, n, somme : entier;
debut
    ecrire("=== Tant que ... faire ... fin ===");
    ecrire("Entrez n > 0 :");
    lire(n);
    i     := 0;
    somme := 0;
    tant que (i < n) faire
        somme := somme + (i + 1);
        ecrire("i =", i, "  i^2 =", i * i);
        i := i + 1;
    fin;
    ecrire("Somme 1..", n, "=", somme);
fin.
"""

EXAMPLES["Chapitre 1 Le langage algorithmique — Boucle Repeter JusquA"] = """\
algorithme BoucleRepeter;
var
    x    : reel;
    i, s : entier;
debut
    ecrire("=== Repeter ... JusquA ... ===");
    repeter
        ecrire("Entrez un nombre > 0 :");
        lire(x);
        si (x <= 0) alors ecrire("Invalide !"); finsi;
    jusqua (x > 0);
    ecrire("Valeur valide :", x);
    s := 0;
    i := 0;
    repeter
        s := s + i;
        i := i + 1;
    jusqua (s > 20);
    ecrire("Somme > 20 atteinte: s =", s, "  i =", i);
fin.
"""

EXAMPLES["Chapitre 1 Le langage algorithmique — Factorielle"] = """\
algorithme Factorielle;
var
    n, res, i : entier;
debut
    ecrire("=== Calcul de n! ===");
    ecrire("Entrez n >= 0 :");
    lire(n);
    si (n < 0) alors
        ecrire("Erreur : n doit etre >= 0");
    sinon
        res := 1;
        pour i := 2 a n faire
            res := res * i;
        fin;
        ecrire(n, "! =", res);
    finsi;
fin.
"""

EXAMPLES["Chapitre 1 Le langage algorithmique — Nombre Premier"] = """\
algorithme NombrePremier;
var
    n, i    : entier;
    premier : booleen;
debut
    ecrire("=== Test de primalite ===");
    ecrire("Entrez un nombre :");
    lire(n);
    si (n < 2) alors
        premier := faux;
    sinon
        premier := vrai;
        i := 2;
        tant que (i * i <= n) faire
            si (n mod i = 0) alors
                premier := faux;
            finsi;
            i := i + 1;
        fin;
    finsi;
    si (premier) alors
        ecrire(n, "est PREMIER");
    sinon
        ecrire(n, "n est PAS premier");
    finsi;
fin.
"""

# ═══════════════════════════════════════════════════════════════════
#  Chapitre 2 — Les tableaux et les matrices
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 2 Les tableaux et les matrices — Tableau 1D"] = """\
algorithme Tableau1D;
var
    T[50]       : tableau d'entier;
    i, n, somme : entier;
    moy         : reel;
debut
    ecrire("=== Tableau 1D  indices 0 a N-1 ===");
    ecrire("Entrez la taille n (1 <= n <= 50) :");
    lire(n);
    pour i := 0 a n-1 faire
        ecrire("T[", i, "] =");
        lire(T[i]);
    fin;
    somme := 0;
    pour i := 0 a n-1 faire
        somme := somme + T[i];
    fin;
    moy := somme / n;
    ecrire("Somme   =", somme);
    ecrire("Moyenne =", moy);
fin.
"""

EXAMPLES["Chapitre 2 Les tableaux et les matrices — Tri par selection"] = """\
algorithme TriSelection;
var
    T[50]     : tableau d'entier;
    n, i, j   : entier;
    imin, tmp : entier;
debut
    ecrire("=== Tri par selection ===");
    n := 7;
    T[0] := 64; T[1] := 25; T[2] := 12;
    T[3] := 22; T[4] := 11; T[5] := 90; T[6] := 45;
    ecrire("Avant :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
    pour i := 0 a n-2 faire
        imin := i;
        pour j := i+1 a n-1 faire
            si (T[j] < T[imin]) alors imin := j; finsi;
        fin;
        si (imin <> i) alors
            tmp := T[i]; T[i] := T[imin]; T[imin] := tmp;
        finsi;
    fin;
    ecrire("Apres tri :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
fin.
"""

EXAMPLES["Chapitre 2 Les tableaux et les matrices — Tri a bulles"] = """\
algorithme TriBulles;
var
    T[50]   : tableau d'entier;
    n, i, j : entier;
    tmp     : entier;
    echange : booleen;
debut
    ecrire("=== Tri a bulles ===");
    n := 8;
    T[0] := 64; T[1] := 34; T[2] := 25; T[3] := 12;
    T[4] := 22; T[5] := 11; T[6] := 90; T[7] := 33;
    ecrire("Avant :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
    pour i := 0 a n-2 faire
        echange := faux;
        pour j := 0 a n-2-i faire
            si (T[j] > T[j+1]) alors
                tmp := T[j]; T[j] := T[j+1]; T[j+1] := tmp;
                echange := vrai;
            finsi;
        fin;
        si (non echange) alors i := n; finsi;
    fin;
    ecrire("Apres tri :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
fin.
"""

EXAMPLES["Chapitre 2 Les tableaux et les matrices — Tri par insertion"] = """\
algorithme TriInsertion;
var
    T[50]        : tableau d'entier;
    n, i, j, cle : entier;
debut
    ecrire("=== Tri par insertion ===");
    n := 7;
    T[0] := 5; T[1] := 2; T[2] := 8; T[3] := 1;
    T[4] := 9; T[5] := 3; T[6] := 7;
    ecrire("Avant :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
    pour i := 1 a n-1 faire
        cle := T[i];
        j   := i - 1;
        tant que (j >= 0 et T[j] > cle) faire
            T[j+1] := T[j];
            j      := j - 1;
        fin;
        T[j+1] := cle;
    fin;
    ecrire("Apres tri :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
fin.
"""

EXAMPLES["Chapitre 2 Les tableaux et les matrices — Recherche sequentielle"] = """\
algorithme RechercheSeq;
var
    T[50]   : tableau d'entier;
    n, x, i : entier;
    trouve  : booleen;
debut
    ecrire("=== Recherche sequentielle ===");
    n := 6;
    T[0] := 10; T[1] := 25; T[2] := 8;
    T[3] := 42; T[4] := 3;  T[5] := 17;
    ecrire("Tableau : 10 25 8 42 3 17");
    ecrire("Valeur a chercher :");
    lire(x);
    i      := 0;
    trouve := faux;
    tant que (i < n et non trouve) faire
        si (T[i] = x) alors
            trouve := vrai;
        sinon
            i := i + 1;
        finsi;
    fin;
    si (trouve) alors
        ecrire("Trouve a l indice", i);
    sinon
        ecrire("Non trouve.");
    finsi;
fin.
"""

EXAMPLES["Chapitre 2 Les tableaux et les matrices — Matrice 2D"] = """\
algorithme Matrice2D;
var
    M[5][5]          : tableau de reel;
    lignes, cols     : entier;
    i, j             : entier;
    somme            : reel;
debut
    ecrire("=== Matrice 2D  indices de 0 a N-1 ===");
    lignes := 2;
    cols   := 3;
    M[0][0] := 1; M[0][1] := 2; M[0][2] := 3;
    M[1][0] := 4; M[1][1] := 5; M[1][2] := 6;
    somme := 0;
    pour i := 0 a lignes-1 faire
        pour j := 0 a cols-1 faire
            ecrire("M[", i, "][", j, "] =", M[i][j]);
            somme := somme + M[i][j];
        fin;
    fin;
    ecrire("Somme =", somme);
fin.
"""



# ═══════════════════════════════════════════════════════════════════
#  Chapitre 3 — Les chaines de caracteres
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 3 Les chaines de caracteres — Fonctions chaines"] = """\
algorithme Chaines;
var
    s, t : chaine;
    n    : entier;
debut
    ecrire("=== Fonctions sur les chaines ===");
    ecrire("Entrez une chaine :");
    lire(s);
    n := longueur(s);
    ecrire("Chaine    :", s);
    ecrire("Longueur  :", n);
    ecrire("Majuscule :", majuscule(s));
    ecrire("Minuscule :", minuscule(s));
    t := concat(">> ", s);
    t := concat(t, " <<");
    ecrire("Encadre   :", t);
fin.
"""


EXAMPLES["Chapitre 3 Les chaines de caracteres — Comptage voyelles"] = """\
algorithme CompterVoyelles;
var
    ch     : chaine;
    i, n   : entier;
    nb_voy : entier;
    c      : chaine;
debut
    ecrire("=== Compter les voyelles ===");
    ecrire("Entrez une chaine :");
    lire(ch);
    n      := longueur(ch);
    nb_voy := 0;
    pour i := 0 a n-1 faire
        c := minuscule(sous_chaine(ch, i, i+1));
        si (c = "a" ou c = "e" ou c = "i" ou c = "o" ou c = "u") alors
            nb_voy := nb_voy + 1;
        finsi;
    fin;
    ecrire("Voyelles :", nb_voy);
    ecrire("Consonnes:", n - nb_voy);
fin.
"""


EXAMPLES["Chapitre 3 Les chaines de caracteres — Palindrome"] = """\
algorithme Palindrome;
var
    ch     : chaine;
    n, i   : entier;
    palin  : booleen;
    c1, c2 : chaine;
debut
    ecrire("=== Test palindrome ===");
    ecrire("Entrez un mot (ex: radar, elle, bonjour) :");
    lire(ch);
    n     := longueur(ch);
    palin := vrai;
    i     := 0;
    tant que (i < n div 2 et palin) faire
        c1 := sous_chaine(ch, i, i+1);
        c2 := sous_chaine(ch, n-1-i, n-i);
        si (c1 <> c2) alors palin := faux; finsi;
        i := i + 1;
    fin;
    si (palin) alors
        ecrire(ch, "est un palindrome.");
    sinon
        ecrire(ch, "n est pas un palindrome.");
    finsi;
fin.
"""


# ═══════════════════════════════════════════════════════════════════
#  Chapitre 4 — Pointeurs et allocation dynamique
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 4 Pointeurs et allocation dynamique — Pointeurs de base"] = """\
algorithme PointeursBase;
var
    x : entier;
    p : ^entier;
debut
    ecrire("=== Pointeurs  p : ^entier ===");
    x := 10;
    p := NIL;
    ecrire("x =", x);
    ecrire("p = NIL :", p = NIL);
    ecrire("taille(entier)    =", taille(entier));
    ecrire("taille(reel)      =", taille(reel));
    ecrire("taille(caractere) =", taille(caractere));
    ecrire("taille(booleen)   =", taille(booleen));
fin.
"""

EXAMPLES["Chapitre 4 Pointeurs et allocation dynamique — Allocation dynamique"] = """\
algorithme AllocDynamique;
var
    p    : ^entier;
    i, n : entier;
debut
    ecrire("=== Allocation dynamique  p := allouer(N*taille(entier)) ===");
    ecrire("Entrez la taille n :");
    lire(n);
    p := allouer(n * taille(entier));
    si (p <> NIL) alors
        ecrire("Allocation reussie pour", n, "elements.");
        pour i := 0 a n-1 faire
            p[i] := i * 10;
        fin;
        pour i := 0 a n-1 faire
            ecrire("p[", i, "] =", p[i]);
        fin;
        liberer(p);
        ecrire("Memoire liberee.");
    sinon
        ecrire("Echec d allocation memoire.");
    finsi;
fin.
"""

# ═══════════════════════════════════════════════════════════════════
#  Chapitre 5 — Fonctions et Procedures
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 5 Fonctions et procedures — Fonction PGCD"] = """\
Fonction PGCD(E/ a, b : entier) : entier
debut
    tant que (a <> b) faire
        si (a > b) alors
            a := a - b;
        sinon
            b := b - a;
        finsi;
    fin;
    retourner a;
fin;
algorithme TestPGCD;
var
    x, y, r : entier;
debut
    ecrire("=== PGCD de deux entiers ===");
    ecrire("Entrez x :");
    lire(x);
    ecrire("Entrez y :");
    lire(y);
    r := PGCD(x, y);
    ecrire("PGCD(", x, ",", y, ") =", r);
    ecrire("PPCM =", (x * y) div r);
fin.
"""

EXAMPLES["Chapitre 5 Fonctions et procedures — Procedure Tri tableau"] = """\
Procedure TriSel(E/S/ T : tableau d'entier; E/ n : entier)
var
    i, j, imin, tmp : entier;
debut
    pour i := 0 a n-2 faire
        imin := i;
        pour j := i+1 a n-1 faire
            si (T[j] < T[imin]) alors imin := j; finsi;
        fin;
        si (imin <> i) alors
            tmp := T[i]; T[i] := T[imin]; T[imin] := tmp;
        finsi;
    fin;
fin;
algorithme TestProcedure;
var
    T[20] : tableau d'entier;
    i, n  : entier;
debut
    ecrire("=== Procedure avec parametre tableau ===");
    n := 5;
    T[0] := 30; T[1] := 10; T[2] := 50; T[3] := 20; T[4] := 40;
    ecrire("Avant :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
    TriSel(T, n);
    ecrire("Apres tri :");
    pour i := 0 a n-1 faire ecrire(T[i]); fin;
fin.
"""

EXAMPLES["Chapitre 5 Fonctions et procedures — Factorielle recursive"] = """\
Fonction Fact(E/ n : entier) : entier
debut
    si (n <= 1) alors
        retourner 1;
    sinon
        retourner n * Fact(n - 1);
    finsi;
fin;
algorithme TestRecursif;
var n : entier;
debut
    ecrire("=== Factorielle recursive ===");
    ecrire("Entrez n :");
    lire(n);
    ecrire(n, "! =", Fact(n));
fin.
"""

# ═══════════════════════════════════════════════════════════════════
#  Chapitre 6 — Les enregistrements
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 6 Les enregistrements — Enregistrement Date"] = """\
algorithme EnregistrementDate;
type Date = Enregistrement
debut
    jour, mois, annee : entier;
fin;
var
    d1, d2 : Date;
debut
    ecrire("=== Type enregistrement ===");
    ecrire("Entrez jour :");   lire(d1.jour);
    ecrire("Entrez mois :");   lire(d1.mois);
    ecrire("Entrez annee :"); lire(d1.annee);
    d2 := d1;
    ecrire("Date 1 :", d1.jour, "/", d1.mois, "/", d1.annee);
    ecrire("Date 2 (copie) :", d2.jour, "/", d2.mois, "/", d2.annee);
fin.
"""

EXAMPLES["Chapitre 6 Les enregistrements — Tableau d'enregistrements"] = """\
algorithme TableauEnreg;
type Etudiant = Enregistrement
debut
    matricule : entier;
    nom       : chaine;
    note      : reel;
fin;
var
    T[50] : tableau d'Etudiant;
    i, n  : entier;
    moy   : reel;
debut
    ecrire("=== Tableau d'enregistrements ===");
    ecrire("Nombre d etudiants :");
    lire(n);
    pour i := 0 a n-1 faire
        ecrire("Matricule[", i, "] :"); lire(T[i].matricule);
        ecrire("Nom[", i, "] :");       lire(T[i].nom);
        ecrire("Note[", i, "] :");      lire(T[i].note);
    fin;
    moy := 0;
    pour i := 0 a n-1 faire
        moy := moy + T[i].note;
    fin;
    moy := moy / n;
    ecrire("Moyenne de la classe =", moy);
    ecrire("--- Admis (note >= 10) ---");
    pour i := 0 a n-1 faire
        si (T[i].note >= 10) alors
            ecrire(T[i].nom, ":", T[i].note);
        finsi;
    fin;
fin.
"""

EXAMPLES["Chapitre 6 Les enregistrements — Enregistrement imbrique"] = """\
algorithme EnregImbrique;
type Date = Enregistrement
debut
    jour, mois, annee : entier;
fin;
type Personne = Enregistrement
debut
    nom, prenom    : chaine;
    date_naissance : Date;
    age            : entier;
fin;
var
    p : Personne;
debut
    ecrire("=== Enregistrement imbrique ===");
    ecrire("Nom :");    lire(p.nom);
    ecrire("Prenom :"); lire(p.prenom);
    ecrire("Jour :"); lire(p.date_naissance.jour);
    ecrire("Mois :"); lire(p.date_naissance.mois);
    ecrire("Annee :"); lire(p.date_naissance.annee);
    ecrire("Age :"); lire(p.age);
    ecrire(p.nom, p.prenom, "  age:", p.age, "ans");
    ecrire("Ne(e) le", p.date_naissance.jour, "/",
            p.date_naissance.mois, "/", p.date_naissance.annee);
fin.
"""

# ═══════════════════════════════════════════════════════════════════
#  Chapitre 7 — Les fichiers
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 7 Les fichiers — Ecriture fichier"] = """\
algorithme EcritureFichier;
var
    f      : fichier;
    chemin : chaine;
    val, i, n : entier;
debut
    ecrire("=== Ecriture dans un fichier binaire ===");
    ecrire("Chemin (ex: donnees.dat) :");
    lire(chemin);
    f := ouvrir(chemin, "ecriture");
    si (f <> NIL) alors
        ecrire("Nombre de valeurs :");
        lire(n);
        pour i := 0 a n-1 faire
            ecrire("Valeur", i, ":");
            lire(val);
            ecrire(f, val);
        fin;
        fermer(f);
        ecrire("Fichier ferme — ecriture terminee.");
    sinon
        ecrire("Erreur: impossible d ouvrir", chemin);
    finsi;
fin.
"""

EXAMPLES["Chapitre 7 Les fichiers — Lecture fichier"] = """\
algorithme LectureFichier;
var
    f      : fichier;
    chemin : chaine;
    val    : entier;
debut
    ecrire("=== Lecture d'un fichier binaire ===");
    ecrire("Chemin du fichier :");
    lire(chemin);
    f := ouvrir(chemin, "lecture");
    si (f <> NIL) alors
        tant que (non finfichier(f)) faire
            lire(f, val);
            ecrire("Lu :", val);
        fin;
        fermer(f);
        ecrire("Lecture terminee.");
    sinon
        ecrire("Erreur: fichier introuvable.");
    finsi;
fin.
"""

# ═══════════════════════════════════════════════════════════════════
#  Chapitre 8 — Les listes chainees
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 8 Les Listes chainees — Creation liste FIFO"] = """\
type Element = Enregistrement
debut
    info    : entier;
    suivant : ^Element;
fin;
algorithme ListeChainee;
var
    tete, p, q : ^Element;
    i, n       : entier;
debut
    ecrire("=== Liste chainee FIFO ===");
    repeter
        ecrire("Taille n > 0 :");
        lire(n);
    jusqua (n > 0);
    nouveau(tete);
    ecrire("info[0] :");
    lire(tete->info);
    tete->suivant := NIL;
    p := tete;
    pour i := 1 a n-1 faire
        nouveau(q);
        ecrire("info[", i, "] :");
        lire(q->info);
        q->suivant := NIL;
        p->suivant := q;
        p := q;
    fin;
    ecrire("--- Affichage ---");
    p := tete;
    tant que (p <> NIL) faire
        ecrire(p->info);
        p := p->suivant;
    fin;
fin.
"""


# ═══════════════════════════════════════════════════════════════════
#  Chapitre 9 — Les piles
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 9 les Piles — Pile LIFO"] = """\
type ElemPile = Enregistrement
debut
    info    : entier;
    suivant : ^ElemPile;
fin;
Fonction PileVide(E/ tete : ^ElemPile) : booleen
debut
    si (tete = NIL) alors
        retourner vrai;
    sinon
        retourner faux;
    finsi;
fin;
Procedure Empiler(E/S/ tete : ^ElemPile; E/ val : entier)
var p : ^ElemPile;
debut
    nouveau(p);
    p->info    := val;
    p->suivant := tete;
    tete       := p;
fin;
algorithme TestPile;
var
    sommet : ^ElemPile;
debut
    ecrire("=== Pile LIFO ===");
    sommet := NIL;
    ecrire("Empiler 10, 20, 30...");
    Empiler(sommet, 10);
    Empiler(sommet, 20);
    Empiler(sommet, 30);
    ecrire("PileVide :", PileVide(sommet));
    si (non PileVide(sommet)) alors
        ecrire("Sommet :", sommet->info);
    finsi;
fin.
"""


# ═══════════════════════════════════════════════════════════════════
#  Chapitre 10 — Les files
# ═══════════════════════════════════════════════════════════════════

EXAMPLES["Chapitre 10 les Files — File FIFO"] = """\
type ElemFile = Enregistrement
debut
    info    : entier;
    suivant : ^ElemFile;
fin;
type File = Enregistrement
debut
    tete  : ^ElemFile;
    queue : ^ElemFile;
fin;
Procedure InitialiserFile(E/S/ F : File)
debut
    F.tete  := NIL;
    F.queue := NIL;
fin;
Fonction FileVide(E/ F : File) : booleen
debut
    si (F.tete = NIL) alors
        retourner vrai;
    sinon
        retourner faux;
    finsi;
fin;
algorithme TestFile;
var
    F : File;
debut
    ecrire("=== File FIFO ===");
    InitialiserFile(F);
    ecrire("FileVide :", FileVide(F));
    ecrire("tete = NIL :", F.tete = NIL);
fin.
"""



SYNTAX_HELP = """╔══════════════════════════════════════════════════════════════════╗
║  RÉFÉRENCE OFFICIELLE — AlgoStudio                         ║
║  ZIANI AYYOUB  —  PYTHON —  ENSEIGNEMENT                         ║
╚══════════════════════════════════════════════════════════════════╝

▶ 1. STRUCTURE GÉNÉRALE
══════════════════════════════════════════════════════════════════
Algorithme <Nom>;
    Const
        <Nom> = <Valeur>;
    Var
        <Nom> : <Type>;
    Debut
        <Instructions>;
    Fin.

▶ 2. TYPES DE DONNÉES
══════════════════════════════════════════════════════════════════
    Entier       Nombre entier            ex: 5, -3, 100
    Reel         Nombre réel              ex: 3.14, -2.5
    Caractere    Un caractère             ex: 'a', 'Z'
    Chaine       Chaîne de caractères     ex: "bonjour"
    Booleen      Booléen                  Vrai  ou  Faux

▶ 3. TABLEAUX
══════════════════════════════════════════════════════════════════
  // 1D  (syntaxe officielle : taille avant les deux-points)
    T[100] : Tableau De Entier;
    C[50]  : Tableau De Caractere;    // tableau de caractères

  // 2D (matrice)
    M[10][10] : Tableau De Reel;

  // Tableau d'enregistrements
    etuds[30] : Tableau De Etudiant;

  // Paramètre de fonction (sans taille)
    Procedure Tri(T : Tableau De Entier; n : Entier);

  // Accès
    T[i] <- valeur;       M[i][j] <- valeur;
    etuds[1].nom <- "Ali";

▶ 4. AFFECTATION
══════════════════════════════════════════════════════════════════
  variable <- <expression>;       // opérateur officiel
  variable := <expression>;       // accepté aussi

▶ 5. OPÉRATEURS
══════════════════════════════════════════════════════════════════
  Arithmétiques :  +  -  *  /  Div  Mod
    Comparaison   :  =  <>  <  >  <=  >=
    Logiques      :  Et  Ou  Non  (priorité : Non > Et > Ou)

▶ 6. ENTRÉE / SORTIE
══════════════════════════════════════════════════════════════════
    Lire(var1, var2, ...);
    Ecrire(expr1, expr2, ...);

▶ 7. CONDITIONS
══════════════════════════════════════════════════════════════════
    Si <condition> Alors
        <instructions>;
    FinSi;

    Si <condition> Alors ... Sinon ... FinSi;

▶ 8. BOUCLES
══════════════════════════════════════════════════════════════════
  // Pour — fermeture : FinPour
    Pour <compteur> <- <debut> a <fin> [Pas <pas>] Faire
        <instructions>;
    FinPour;

  // TantQue — fermeture : FinTantQue
    TantQue <condition> Faire
        <instructions>;
    FinTantQue;

  // Répéter — s'exécute au moins 1 fois
    Repeter
        <instructions>;
    JusquA <condition>;

  // Contrôle de boucle  ★ NOUVEAU
  Arreter;      // sortir immédiatement de la boucle (break)
  Continuer;    // passer à l'itération suivante (continue)

▶ 9. SELON / CAS  (Switch)
══════════════════════════════════════════════════════════════════
    Selon <expression> Faire
        Cas <valeur1>: <instructions>;
        Cas <valeur2>: <instructions>;
        Autrement: <instructions>;
    FinSelon;

▶ 10. FONCTIONS ET PROCÉDURES
══════════════════════════════════════════════════════════════════
  // Déclarées AVANT l'algorithme principal

    Fonction <Nom>(<Params>) : <TypeRetour>;
    Var <locales>;
    Debut
        ...
        Retourner(<expression>);
    Fin;

    Procedure <Nom>(<Params>);
    Var <locales>;
    Debut  ...  Fin;

  // Passage tableau en paramètre (sans taille)
    Procedure Remplir(T : Tableau De Entier; n : Entier);

▶ 11. ENREGISTREMENTS
══════════════════════════════════════════════════════════════════
  // Déclaré APRÈS l_en-tête Algorithme, AVANT Var
    Type NomType = Enregistrement
        champ1 : Type1;
        champ2 : Type2;
    Fin;

    Var e : NomType;
    e.champ1 <- valeur;
    Ecrire(e.champ2);

▶ 12. POINTEURS  ★ DEUX SYNTAXES ACCEPTÉES
══════════════════════════════════════════════════════════════════
  // Syntaxe classique
    p : Pointeur Vers <Type>;

  // Syntaxe C-like  (nouveau)
  p : ^<Type>;           // ex:  p : ^Ville    p : ^Entier

  // Allocation / Libération
  Nouveau(p);            // alloue un enregistrement
  Liberer(p);            // libère

  // Accès
  p^.champ <- val;       // notation ^ (caret)
  p->champ <- val;       // notation -> (flèche, la plus utilisée)

  // Valeur nulle
    p <- NIL;

▶ 13. FICHIERS
══════════════════════════════════════════════════════════════════
    Var f : Fichier;

    Ouvrir(f, "chemin/nom.dat", "lecture");
    Ouvrir(f, "chemin/nom.dat", "ecriture");
    Ouvrir(f, "chemin/nom.dat", "mise a jour");

    TantQue Non FinFichier(f) Faire
        Lire(f, enreg);
    FinTantQue;

    Ecrire(f, variable);
    Fermer(f);

▶ 14. PILES  (Ch9)
══════════════════════════════════════════════════════════════════
  Empiler(P, element);       // ajouter au sommet
  Depiler(P, &element);      // retirer du sommet
  x <- Sommet(P);            // consulter sans supprimer
  b <- PileVide(P);          // Vrai si vide

▶ 15. FILES  (Ch10)
══════════════════════════════════════════════════════════════════
  Enfiler(F, element);       // ajouter en queue
  Defiler(F, &element);      // retirer de la tête
  x <- Tete(F);              // consulter sans supprimer
  b <- FileVide(F);          // Vrai si vide

▶ 16. FONCTIONS PRÉDÉFINIES
══════════════════════════════════════════════════════════════════
  // Chaînes
    longueur(ch)                    → Entier
    concat(ch1, ch2)                → Chaine
    sous_chaine(ch, debut, fin)     → Chaine
    trouve(ch, motif)               → Entier  (-1 si absent)
    remplace(ch, ancien, nouveau)   → Chaine
    majuscule(ch) / minuscule(ch)   → Chaine
    trim(ch)                        → Chaine

  // Tableau De Caractere
    chaine_vers_tableau(s)          → Tableau De Caractere
    tableau_vers_chaine(tab)        → Chaine

  // Mathématiques
    abs(x)   sqrt(x)   pow(x,n)   arrondi(x,n)
    sin(x)   cos(x)    tan(x)     log(x)   log2(x)   log10(x)
    max(a,b) min(a,b)  entier(x)  reel(x)

  // Divers
    aleatoire()          → Reel   (0..1)
    aleatoire_entier(a,b)→ Entier
    ord(c) / chr(n)      → Entier / Caractere

▶ 17. EXPORT  ★ NOUVEAU
══════════════════════════════════════════════════════════════════
    Menu Outils → Exporter vers C        (.c)
    Menu Outils → Exporter vers Python   (.py)
    L'algorithme est converti en code exécutable.

▶ 18. RACCOURCIS CLAVIER
══════════════════════════════════════════════════════════════════
    F5              ▶  Exécuter
    F6              ■  Arrêter
    F7              📊 Live Variables (variables en temps réel)
    Ctrl+Espace     💡 Suggestions (mots-clés + vos variables)
    Ctrl+F          🔍 Chercher / Remplacer
    Ctrl+/          Commenter / Décommenter
    Tab             Indentation automatique / Valider suggestion
    Échap           Fermer la suggestion
"""



