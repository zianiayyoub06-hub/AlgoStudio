# -*- coding: utf-8 -*-
"""Lexer — Tokeniseur du pseudocode algorithmique."""
import re
from pathlib import Path


# ══════════════════════════════════════════════════════════════════════
#  LEXER
# ══════════════════════════════════════════════════════════════════════

KEYWORDS = {
    # Programme
    'algorithme','var','const','type','debut','fin',
    # Conditions  (fsi = fin si officiel)
    'si','alors','sinon','fsi','finsi',
    # Pour  (syntaxe: Pour i <- 1 a n Faire ... FinPour)
    'pour','a','pas','faire','finpour',
    # TantQue  (deux mots: Tant Que ... Faire ... FinTantQue)
    'tant','que','tantque','fintantque',
    # Répéter (Repeter ... JusquA cond;)
    'repeter','jusqua','finrepeter',
    # Fonctions/Procédures
    'fonction','procedure','retourner','retourne',
    # Enregistrements
    'enregistrement','finrec',
    # I/O
    'ecrire','lire',
    # Logique
    'et','ou','non','vrai','faux',
    # Types
    'entier','reel','booleen','chaine','caractere',
    'tableau','de','pointeur','vers','fichier',
    # Allocation (Nouveau / Liberer)
    'nouveau','liberer','nil','allouer',
    # Fichiers
    'ouvrir','fermer',
    # Opérateurs mot-clé
    'div','mod',
    # Divers
    'selon','cas','autrement','finselon',
    # Contrôle de boucle
    'arreter','continuer',
    # Fichiers
    'finfichier',
}

TOKEN_RE = re.compile(r"""
  (?P<MLCOMMENT> /\*.*?\*/)
| (?P<COMMENT>   //[^\n]*)
| (?P<MLSTRING>  "{3}[\s\S]*?"{3})
| (?P<STRING>    "(?:[^"\\]|\\.)*")
| (?P<CHAR>      '(?:[^'\\]|\\.)')
| (?P<FLOAT>     \d+\.\d+)
| (?P<INT>       \d+)
| (?P<ASSIGN>    :=)
| (?P<ASSIGN2>   <-)
| (?P<ARROW>     ->)
| (?P<NEQ>       <>)
| (?P<LEQ>       <=)
| (?P<GEQ>       >=)
| (?P<LT>        <)
| (?P<GT>        >)
| (?P<EQ>        =)
| (?P<PLUS>      \+)
| (?P<MINUS>     -)
| (?P<MUL>       \*)
| (?P<DIV>       /)
| (?P<MOD>       %)
| (?P<LPAREN>    \()
| (?P<RPAREN>    \))
| (?P<LBRACKET>  \[)
| (?P<RBRACKET>  \])
| (?P<COMMA>     ,)
| (?P<SEMICOLON> ;)
| (?P<COLON>     :)
| (?P<DOT>       \.)
| (?P<CARET>     \^)
| (?P<AMPERSAND> &)
| (?P<ID>        [A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ0-9_]*)
| (?P<NEWLINE>   \n)
| (?P<WS>        [ \t\r]+)
| (?P<APOST>    ')
| (?P<BAD>       .)
""", re.VERBOSE | re.DOTALL)

class Token:
    __slots__ = ('type','value','line','col')
    def __init__(self, t, v, l, c):
        self.type=t; self.value=v; self.line=l; self.col=c
    def __repr__(self):
        return f'Token({self.type},{self.value!r},L{self.line}:{self.col})'

class LexerError(Exception):
    def __init__(self, msg, line, col):
        super().__init__(msg); self.line=line; self.col=col

def preprocess(source: str) -> str:
    """
    Pré-traitement avant le lexer :
    - Remplace ↑ (U+2191) par ^ (pointeur), ← par <-
    - Convertit jusqu'a / jusqu'à → jusqua
    - Convertit d'<type> → de <type>  (ex: tableau d'entier → tableau de entier)
    - Remplace UNIQUEMENT les apostrophes HORS chaînes littérales
    - Protège les chaînes entre guillemets doubles
    """
    # Remplacer les flèches Unicode avant tout traitement
    source = source.replace('\u2191', '^')   # ↑ → ^  (pointeur)
    source = source.replace('\u2190', '<-')  # ← → <- (affectation)
    source = source.replace('\u2192', '->')  # → → -> (accès pointeur)

    _APOSTROPHE_WORDS = {
        "jusqu'a":      "jusqua",
        "jusqu'à":      "jusqua",
        "d'entier":     "de entier",
        "d'reel":       "de reel",
        "d'booleen":    "de booleen",
        "d'caractere":  "de caractere",
        "d'chaine":     "de chaine",
        "d'un":         "de un",
        "l'algorithme": "l_algorithme",
        "j'ai":         "j_ai",
    }
    result = []
    i = 0
    while i < len(source):
        # Protéger les chaînes entre guillemets doubles
        if source[i] == '"':
            j = i + 1
            while j < len(source) and source[j] != '"':
                if source[j] == '\\': j += 2
                else: j += 1
            result.append(source[i:j+1])
            i = j + 1
            continue
        # Détecter mots avec apostrophe
        matched = False
        for word, replacement in _APOSTROPHE_WORDS.items():
            wl = len(word)
            if source[i:i+wl].lower() == word:
                result.append(replacement)
                i += wl
                matched = True
                break
        if not matched:
            # Apostrophe générique hors chaîne : ignorer silencieusement
            if source[i] == "'" :
                # Vérifier si c'est un char littéral valide ('a', 'Z', etc.)
                # Sinon on l'ignore (cas jusqu'a non reconnu, etc.)
                if (i+2 < len(source) and source[i+2] == "'") or \
                (i+1 < len(source) and source[i+1] == "\\"):
                    result.append(source[i])  # char littéral → garder
                else:
                    pass  # apostrophe seule → ignorer
            else:
                result.append(source[i])
            i += 1
    # Remplacer fin( par finfichier( quand c'est un appel de fonction
    import re as _re
    source_out = ''.join(result)
    # fin(x) -> finfichier(x)  seulement hors chaines
    def _replace_fin(m):
        return 'finfichier('
    # Remplace fin( qui n'est pas dans une chaine
    parts2 = _re.split(r'("[^"]*")', source_out)
    for k,p2 in enumerate(parts2):
        if k % 2 == 0:  # hors chaine
            parts2[k] = _re.sub(r'\bfin\s*\(', 'finfichier(', p2)
    return ''.join(parts2)


def tokenize(source):
    source = preprocess(source)  # ← pré-traitement apostrophes
    tokens = []
    line = 1
    line_start = 0
    for m in TOKEN_RE.finditer(source):
        kind  = m.lastgroup
        value = m.group()
        col   = m.start() - line_start + 1
        if kind == 'WS':
            continue
        elif kind == 'NEWLINE':
            line += 1; line_start = m.end(); continue
        elif kind in ('COMMENT','MLCOMMENT'):
            line += value.count('\n'); continue
        elif kind == 'MLSTRING': kind = 'STRING'  # traiter comme string simple
        elif kind in ('ASSIGN2',): kind = 'ASSIGN'
        elif kind == 'APOST': continue  # handled by preprocess()
        elif kind == 'BAD':
            raise LexerError(f"Caractère inconnu: {value!r}", line, col)
        elif kind == 'ID' and value.lower() in KEYWORDS:
            kind = 'KW_' + value.upper()
        tokens.append(Token(kind, value, line, col))
    tokens.append(Token('EOF','',line,0))
    return tokens
