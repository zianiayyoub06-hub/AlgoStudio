#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AlgoStudio
Compilateur / Interpréteur de pseudocode algorithmique en français.
Lancez ce fichier pour démarrer l'application.
python main.py
"""
import tkinter as tk
import json
import os
from pathlib import Path
from app import App, CONFIG_PATH


def main():
    root = tk.Tk()
    app  = App(root)

    def on_closing():
        try:
            session_files = []
            for tab in app._tabs:
                if tab.get('cur_file'):
                    session_files.append({
                        'path': tab['cur_file'],
                    })
            cfg = {}
            try:
                cfg = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
            except Exception:
                pass
            cfg['theme']         = app.theme_name
            cfg['session_files'] = session_files
            CONFIG_PATH.write_text(
                json.dumps(cfg, ensure_ascii=False, indent=2),
                encoding='utf-8')
        except Exception:
            pass
        root.destroy()

    root.protocol('WM_DELETE_WINDOW', on_closing)

    # أيقونة التطبيق
    BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
    icon_path = os.path.join(BASE_DIR, "logo.ico")
    root.iconbitmap(default=icon_path)

    root.mainloop()


if __name__ == '__main__':
    main()